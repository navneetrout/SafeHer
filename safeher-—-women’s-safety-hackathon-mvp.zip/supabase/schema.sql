-- SafeHer Supabase Schema & Row Level Security (RLS) Policies
-- Run this entire script in Supabase Dashboard -> SQL Editor

create extension if not exists pgcrypto;

-- 1. Trusted Contacts (Strictly Private per Authenticated User)
create table if not exists public.trusted_contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 80),
  phone text not null check (char_length(trim(phone)) between 3 and 24),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.trusted_contacts enable row level security;

drop policy if exists "Users can view own contacts" on public.trusted_contacts;
create policy "Users can view own contacts"
  on public.trusted_contacts for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own contacts" on public.trusted_contacts;
create policy "Users can insert own contacts"
  on public.trusted_contacts for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own contacts" on public.trusted_contacts;
create policy "Users can update own contacts"
  on public.trusted_contacts for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own contacts" on public.trusted_contacts;
create policy "Users can delete own contacts"
  on public.trusted_contacts for delete
  using (auth.uid() = user_id);

-- 2. User Settings (Emergency Numbers & Privacy Consents — Strictly Private per Authenticated User)
create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  police_number text not null default '',
  ambulance_number text not null default '',
  save_activity_consent boolean not null default false,
  save_location_history_consent boolean not null default false,
  save_profile_consent boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.user_settings add column if not exists save_activity_consent boolean not null default false;
alter table public.user_settings add column if not exists save_location_history_consent boolean not null default false;
alter table public.user_settings add column if not exists save_profile_consent boolean not null default false;

alter table public.user_settings enable row level security;

drop policy if exists "Users can view own settings" on public.user_settings;
create policy "Users can view own settings"
  on public.user_settings for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own settings" on public.user_settings;
create policy "Users can insert own settings"
  on public.user_settings for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own settings" on public.user_settings;
create policy "Users can update own settings"
  on public.user_settings for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own settings" on public.user_settings;
create policy "Users can delete own settings"
  on public.user_settings for delete
  using (auth.uid() = user_id);

-- 3. Community Crowd Reports (Publicly Readable, Zero PII / Phone Numbers Stored)
create table if not exists public.crowd_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  level text not null check (level in ('Low', 'Medium', 'High')),
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  location_label text not null default '' check (char_length(location_label) <= 120),
  note text not null default '' check (char_length(note) <= 280),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_crowd_reports_created_at on public.crowd_reports(created_at desc);

alter table public.crowd_reports enable row level security;

drop policy if exists "Anyone can read community crowd reports" on public.crowd_reports;
create policy "Anyone can read community crowd reports"
  on public.crowd_reports for select
  using (true);

drop policy if exists "Authenticated users can create own crowd reports" on public.crowd_reports;
create policy "Authenticated users can create own crowd reports"
  on public.crowd_reports for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can update own crowd reports" on public.crowd_reports;
create policy "Users can update own crowd reports"
  on public.crowd_reports for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own crowd reports" on public.crowd_reports;
create policy "Users can delete own crowd reports"
  on public.crowd_reports for delete
  using (auth.uid() = user_id);

-- 4. User-Created Safety Alerts (Strictly labeled source_type = 'user')
create table if not exists public.safety_alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 100),
  message text not null check (char_length(trim(message)) between 1 and 500),
  location_text text not null default '' check (char_length(location_text) <= 140),
  lat double precision,
  lng double precision,
  source_type text not null default 'user' check (source_type = 'user'),
  created_at timestamptz not null default now()
);

create index if not exists idx_safety_alerts_created_at on public.safety_alerts(created_at desc);

alter table public.safety_alerts enable row level security;

drop policy if exists "Anyone can read user safety alerts" on public.safety_alerts;
create policy "Anyone can read user safety alerts"
  on public.safety_alerts for select
  using (true);

drop policy if exists "Authenticated users can create own safety alerts" on public.safety_alerts;
create policy "Authenticated users can create own safety alerts"
  on public.safety_alerts for insert
  with check (auth.uid() = user_id and source_type = 'user');

drop policy if exists "Users can delete own safety alerts" on public.safety_alerts;
create policy "Users can delete own safety alerts"
  on public.safety_alerts for delete
  using (auth.uid() = user_id);

-- 5. Alert Read Receipts (Per-User Private Read State)
create table if not exists public.alert_reads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  alert_id uuid not null references public.safety_alerts(id) on delete cascade,
  read_at timestamptz not null default now(),
  unique (user_id, alert_id)
);

alter table public.alert_reads enable row level security;

drop policy if exists "Users can view own alert reads" on public.alert_reads;
create policy "Users can view own alert reads"
  on public.alert_reads for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own alert reads" on public.alert_reads;
create policy "Users can insert own alert reads"
  on public.alert_reads for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own alert reads" on public.alert_reads;
create policy "Users can delete own alert reads"
  on public.alert_reads for delete
  using (auth.uid() = user_id);

-- 6. My Safety Journey Activity Logs (Strictly Private — Visible Only to Signed-In Owner)
create table if not exists public.safety_journey_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null check (activity_type in ('sos', 'location_share', 'safety_alert', 'crowd_report')),
  title text not null check (char_length(trim(title)) between 1 and 120),
  status text not null check (char_length(trim(status)) between 1 and 120),
  details text not null default '' check (char_length(details) <= 280),
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);

create index if not exists idx_safety_journey_logs_user_created
  on public.safety_journey_logs(user_id, created_at desc);

alter table public.safety_journey_logs enable row level security;

drop policy if exists "Users can view own journey logs" on public.safety_journey_logs;
create policy "Users can view own journey logs"
  on public.safety_journey_logs for select
  using (auth.uid() = user_id);

drop policy if exists "Users can insert own journey logs" on public.safety_journey_logs;
create policy "Users can insert own journey logs"
  on public.safety_journey_logs for insert
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete own journey logs" on public.safety_journey_logs;
create policy "Users can delete own journey logs"
  on public.safety_journey_logs for delete
  using (auth.uid() = user_id);
