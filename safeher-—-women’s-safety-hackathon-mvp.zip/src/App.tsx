import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Copy,
  Database,
  ExternalLink,
  EyeOff,
  Grid,
  Heart,
  HeartHandshake,
  HeartPulse,
  History,
  Home,
  Info,
  Loader2,
  Lock,
  LogIn,
  LogOut,
  Mail,
  MapPin,
  MessageSquare,
  Navigation,
  Pencil,
  Phone,
  PhoneCall,
  Plus,
  RefreshCw,
  Send,
  Settings,
  Share2,
  Shield,
  ShieldCheck,
  Sparkles,
  Trash2,
  UserCheck,
  WifiOff,
  X,
  XCircle,
} from 'lucide-react';
import CrowdMapView from './components/CrowdMapView';
import SupabaseSetupModal from './components/SupabaseSetupModal';
import {
  extractSupabaseErrorMessage,
  formatSupabaseAuthError,
  getStoredSupabaseConfig,
  getSupabaseClient,
} from './lib/supabase';

const AUTH_GUARD_STORAGE_KEY = 'safeher_auth_guard_v2';

function readStoredAuthGuard(): {
  pendingEmail: string;
  rateLimitUntil: number;
  emailCooldowns: Record<string, number>;
  signedUpEmails: Record<string, number>;
  resendUsedEmails: Record<string, boolean>;
} {
  const empty = {
    pendingEmail: '',
    rateLimitUntil: 0,
    emailCooldowns: {},
    signedUpEmails: {},
    resendUsedEmails: {},
  };
  if (typeof window === 'undefined') return empty;

  try {
    const raw = localStorage.getItem(AUTH_GUARD_STORAGE_KEY);
    if (!raw) return empty;
    const parsed = JSON.parse(raw) as {
      pendingEmail?: string;
      rateLimitUntil?: number;
      emailCooldowns?: Record<string, number>;
      signedUpEmails?: Record<string, number>;
      resendUsedEmails?: Record<string, boolean>;
    };
    const now = Date.now();
    const cleanedCooldowns: Record<string, number> = {};
    if (parsed.emailCooldowns && typeof parsed.emailCooldowns === 'object') {
      for (const [email, until] of Object.entries(parsed.emailCooldowns)) {
        if (typeof until === 'number' && until > now) {
          cleanedCooldowns[email] = until;
        }
      }
    }
    const cleanedSignedUp: Record<string, number> = {};
    if (parsed.signedUpEmails && typeof parsed.signedUpEmails === 'object') {
      for (const [email, ts] of Object.entries(parsed.signedUpEmails)) {
        // Remember registered emails for 24h to block accidental duplicate signUp() calls
        if (typeof ts === 'number' && now - ts < 24 * 60 * 60 * 1000) {
          cleanedSignedUp[email] = ts;
        }
      }
    }
    const cleanedResends: Record<string, boolean> = {};
    if (parsed.resendUsedEmails && typeof parsed.resendUsedEmails === 'object') {
      for (const [email, used] of Object.entries(parsed.resendUsedEmails)) {
        if (used === true && cleanedSignedUp[email]) {
          cleanedResends[email] = true;
        }
      }
    }
    return {
      pendingEmail:
        typeof parsed.pendingEmail === 'string' ? parsed.pendingEmail : '',
      rateLimitUntil:
        typeof parsed.rateLimitUntil === 'number' && parsed.rateLimitUntil > now
          ? parsed.rateLimitUntil
          : 0,
      emailCooldowns: cleanedCooldowns,
      signedUpEmails: cleanedSignedUp,
      resendUsedEmails: cleanedResends,
    };
  } catch {
    return empty;
  }
}

function formatCooldownDuration(seconds: number): string {
  const safe = Math.max(0, Math.ceil(seconds));
  if (safe < 60) return `${safe}s`;
  const mins = Math.floor(safe / 60);
  const rem = safe % 60;
  return rem === 0 ? `${mins}m` : `${mins}m ${rem}s`;
}
import {
  buildMapLink,
  buildSmsHref,
  fetchLocationWithFastFallback,
  formatActivityDateTime,
  formatRelativeAge,
  getLastKnownLocation,
  LAST_KNOWN_LOCATION_KEY,
  launchSmsUri,
  LOCAL_CONTACTS_KEY,
  LOCAL_READ_ALERTS_KEY,
  LOCAL_SETTINGS_KEY,
  requestBackgroundLocationRefresh,
  requestBrowserLocation,
  SAMPLE_ALERTS,
  SAMPLE_CROWD_REPORTS,
  sanitizeDialNumber,
  SUPPORTIVE_SAFETY_TIPS,
  validateEmail,
  validatePhoneNumber,
} from './lib/utils';
import {
  ActiveShareSession,
  Coordinates,
  CrowdLevel,
  CrowdReport,
  FeedbackState,
  JourneyActivityType,
  ModuleId,
  SafetyAlert,
  SafetyJourneyLog,
  SectionId,
  SosAlertState,
  SosStatus,
  TrustedContact,
} from './types/safeher';
import type { User } from '@supabase/supabase-js';

const SECTIONS: { id: SectionId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'modules', label: 'Modules', icon: Grid },
  { id: 'about', label: 'About', icon: Info },
  { id: 'contact', label: 'Contact', icon: Mail },
  { id: 'journey', label: 'Journey', icon: HeartHandshake },
];

const MODULE_TABS: { id: ModuleId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'sos', label: 'SOS', icon: AlertTriangle },
  { id: 'crowd', label: 'Crowd Map', icon: MapPin },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'share', label: 'Live Share', icon: Share2 },
  { id: 'dial', label: 'Speed Dial', icon: PhoneCall },
];

function FeedbackBanner({
  feedback,
  onDismiss,
}: {
  feedback: FeedbackState | null;
  onDismiss?: () => void;
}) {
  if (!feedback || !feedback.message) return null;
  const styles =
    feedback.type === 'error'
      ? 'border-red-200 bg-red-50 text-red-900'
      : feedback.type === 'success'
        ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
        : 'border-pink-200 bg-pink-50 text-[#24101B]';

  return (
    <div
      role="status"
      className={`flex items-start justify-between gap-2 rounded-2xl border p-3 text-xs ${styles}`}
    >
      <div className="flex items-start gap-2">
        {feedback.type === 'loading' && (
          <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin text-[#E11D74]" />
        )}
        {feedback.type === 'success' && (
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
        )}
        {feedback.type === 'error' && (
          <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
        )}
        {feedback.type === 'info' && (
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#9D174D]" />
        )}
        <p className="leading-relaxed">{feedback.message}</p>
      </div>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss message"
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg hover:bg-black/5"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState<SectionId>('home');
  const [activeModule, setActiveModule] = useState<ModuleId>('sos');
  const [showSettings, setShowSettings] = useState(false);
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Supabase & Auth state
  const [supabaseRevision, setSupabaseRevision] = useState(0);
  const supabase = useMemo(() => getSupabaseClient(), [supabaseRevision]);
  const supabaseConfigured = Boolean(supabase);
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authFeedback, setAuthFeedback] = useState<FeedbackState | null>(null);
  const initialAuthGuard = useMemo(() => readStoredAuthGuard(), []);
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState(
    initialAuthGuard.pendingEmail
  );
  const [rateLimitUntil, setRateLimitUntil] = useState(
    initialAuthGuard.rateLimitUntil
  );
  const [emailCooldowns, setEmailCooldowns] = useState<Record<string, number>>(
    initialAuthGuard.emailCooldowns
  );
  const [signedUpEmails, setSignedUpEmails] = useState<Record<string, number>>(
    initialAuthGuard.signedUpEmails
  );
  const [resendUsedEmails, setResendUsedEmails] = useState<
    Record<string, boolean>
  >(initialAuthGuard.resendUsedEmails);
  const [authNowMs, setAuthNowMs] = useState(() => Date.now());
  const authInFlightRef = useRef(false);

  // Trusted Contacts & Emergency Settings
  const [contacts, setContacts] = useState<TrustedContact[]>([]);
  const [policeNumber, setPoliceNumber] = useState('');
  const [ambulanceNumber, setAmbulanceNumber] = useState('');
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsFeedback, setSettingsFeedback] = useState<FeedbackState | null>(null);

  // Contact CRUD UI state (shared between Settings and Live Location Share)
  const [contactForm, setContactForm] = useState({ name: '', phone: '' });
  const [editingContactId, setEditingContactId] = useState<string | null>(null);
  const [contactFeedback, setContactFeedback] = useState<FeedbackState | null>(null);

  // Delete all data modal
  const [confirmDeleteData, setConfirmDeleteData] = useState(false);
  const [deleteDataLoading, setDeleteDataLoading] = useState(false);

  // My Safety Journey & Consent State (Private to signed-in user)
  const [saveProfileConsent, setSaveProfileConsent] = useState(false);
  const [saveActivityConsent, setSaveActivityConsent] = useState(false);
  const [saveLocationHistoryConsent, setSaveLocationHistoryConsent] =
    useState(false);
  const [journeyLogs, setJourneyLogs] = useState<SafetyJourneyLog[]>([]);
  const [journeyLoading, setJourneyLoading] = useState(false);
  const [journeyFeedback, setJourneyFeedback] = useState<FeedbackState | null>(
    null
  );
  const [confirmClearJourney, setConfirmClearJourney] = useState(false);
  const [journeySchemaWarning, setJourneySchemaWarning] = useState(false);

  // 1. SOS State (Instant Activation + Non-blocking Background Location)
  const [sosModalOpen, setSosModalOpen] = useState(false);
  const [sosSelectedIds, setSosSelectedIds] = useState<string[]>([]);
  const [sosState, setSosState] = useState<SosAlertState | null>(null);
  const [sosCopied, setSosCopied] = useState(false);
  const [sosDuplicateNotice, setSosDuplicateNotice] = useState('');
  const sosKnownContactIdsRef = useRef<Set<string>>(new Set());
  const sosDispatchRef = useRef<{
    eventId: string;
    status: SosStatus;
    signature: string;
    lastTriggeredAt: number;
    cancelBgLocation?: () => void;
  } | null>(null);
  const sosLoggedEventsRef = useRef<Set<string>>(new Set());
  const sosStatusTimerRef = useRef<number | null>(null);

  // 2. Crowd Map State
  const [crowdReports, setCrowdReports] = useState<CrowdReport[]>([]);
  const [crowdLoading, setCrowdLoading] = useState(false);
  const [crowdFeedback, setCrowdFeedback] = useState<FeedbackState | null>(null);
  const [crowdFilter, setCrowdFilter] = useState<'All' | CrowdLevel>('All');
  const [mapCenter, setMapCenter] = useState({ lat: 28.6139, lng: 77.209 });
  const [userMapLocation, setUserMapLocation] = useState<Coordinates | null>(null);
  const [pickedLocation, setPickedLocation] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [reportForm, setReportForm] = useState<{
    level: CrowdLevel;
    locationLabel: string;
    note: string;
  }>({
    level: 'Medium',
    locationLabel: '',
    note: '',
  });
  const [reportSubmitting, setReportSubmitting] = useState(false);
  const [editingReportId, setEditingReportId] = useState<string | null>(null);
  const [editReportDraft, setEditReportDraft] = useState<{
    level: CrowdLevel;
    note: string;
  }>({
    level: 'Medium',
    note: '',
  });
  const [showSampleCrowd, setShowSampleCrowd] = useState(false);

  // 3. Safety Alerts State
  const [alerts, setAlerts] = useState<SafetyAlert[]>([]);
  const [readAlertIds, setReadAlertIds] = useState<string[]>([]);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [alertsFeedback, setAlertsFeedback] = useState<FeedbackState | null>(null);
  const [alertForm, setAlertForm] = useState<{
    title: string;
    message: string;
    locationText: string;
    coords: Coordinates | null;
  }>({
    title: '',
    message: '',
    locationText: '',
    coords: null,
  });
  const [alertSubmitting, setAlertSubmitting] = useState(false);
  const [showSampleAlerts, setShowSampleAlerts] = useState(false);

  // 4. Live Location Share State
  const [shareContactId, setShareContactId] = useState('');
  const [shareDurationMin, setShareDurationMin] = useState(30);
  const [shareLoading, setShareLoading] = useState(false);
  const [shareFeedback, setShareFeedback] = useState<FeedbackState | null>(null);
  const [activeShareSession, setActiveShareSession] =
    useState<ActiveShareSession | null>(null);
  const [shareSecondsLeft, setShareSecondsLeft] = useState(0);

  // 5. Speed Dial State
  const [dialConfirmTarget, setDialConfirmTarget] = useState<{
    label: string;
    number: string;
  } | null>(null);
  const [dialOutcome, setDialOutcome] = useState<{
    label: string;
    number: string;
    telHref: string;
  } | null>(null);
  const [dialCopied, setDialCopied] = useState(false);

  // 6. Contact Form State
  const [publicContactTopic, setPublicContactTopic] = useState('Feedback');
  const [publicContactForm, setPublicContactForm] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [publicContactStatus, setPublicContactStatus] =
    useState<FeedbackState | null>(null);
  const [publicContactPreview, setPublicContactPreview] = useState<{
    name: string;
    email: string;
    topic: string;
    message: string;
  } | null>(null);
  const [publicContactCopied, setPublicContactCopied] = useState(false);

  // Monitor browser online/offline state
  useEffect(() => {
    const goOnline = () => setIsOnline(true);
    const goOffline = () => setIsOnline(false);
    window.addEventListener('online', goOnline);
    window.addEventListener('offline', goOffline);
    return () => {
      window.removeEventListener('online', goOnline);
      window.removeEventListener('offline', goOffline);
    };
  }, []);

  // Dismiss SOS or Speed Dial confirmation dialogs with Escape key
  useEffect(() => {
    if (!sosModalOpen && !dialConfirmTarget) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        if (sosModalOpen) setSosModalOpen(false);
        if (dialConfirmTarget) setDialConfirmTarget(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [sosModalOpen, dialConfirmTarget]);

  // Load local fallback settings/contacts/read-alerts on init
  const loadLocalPreferences = useCallback(() => {
    try {
      const savedContacts = JSON.parse(
        localStorage.getItem(LOCAL_CONTACTS_KEY) || '[]'
      );
      if (Array.isArray(savedContacts)) {
        setContacts(savedContacts);
      }
      const savedSettings = JSON.parse(
        localStorage.getItem(LOCAL_SETTINGS_KEY) || '{}'
      );
      setPoliceNumber(savedSettings.police_number || '');
      setAmbulanceNumber(savedSettings.ambulance_number || '');
      setSaveProfileConsent(Boolean(savedSettings.save_profile_consent));
      setSaveActivityConsent(false);
      setSaveLocationHistoryConsent(false);
      setJourneyLogs([]);

      const savedReads = JSON.parse(
        localStorage.getItem(LOCAL_READ_ALERTS_KEY) || '[]'
      );
      if (Array.isArray(savedReads)) {
        setReadAlertIds(savedReads);
      }
    } catch {
      // Ignore malformed localStorage
    }
  }, []);

  useEffect(() => {
    loadLocalPreferences();
  }, [loadLocalPreferences]);

  // Persist non-sensitive auth cooldown/pending-verification state in localStorage
  useEffect(() => {
    try {
      const now = Date.now();
      const activeCooldowns: Record<string, number> = {};
      for (const [email, until] of Object.entries(emailCooldowns)) {
        if (until > now) activeCooldowns[email] = until;
      }
      const activeSignedUp: Record<string, number> = {};
      for (const [email, ts] of Object.entries(signedUpEmails)) {
        if (now - ts < 24 * 60 * 60 * 1000) activeSignedUp[email] = ts;
      }
      localStorage.setItem(
        AUTH_GUARD_STORAGE_KEY,
        JSON.stringify({
          pendingEmail: pendingVerificationEmail,
          rateLimitUntil: rateLimitUntil > now ? rateLimitUntil : 0,
          emailCooldowns: activeCooldowns,
          signedUpEmails: activeSignedUp,
          resendUsedEmails,
        })
      );
    } catch {
      // Ignore storage errors
    }
  }, [
    pendingVerificationEmail,
    rateLimitUntil,
    emailCooldowns,
    signedUpEmails,
    resendUsedEmails,
  ]);

  // Run a 1-second timer only while an active rate-limit or verification cooldown exists
  useEffect(() => {
    const now = Date.now();
    const maxCooldown = Math.max(
      rateLimitUntil,
      ...Object.values(emailCooldowns),
      0
    );
    if (maxCooldown <= now) return;

    setAuthNowMs(now);
    const intervalId = window.setInterval(() => {
      const current = Date.now();
      setAuthNowMs(current);
      if (current >= maxCooldown) {
        window.clearInterval(intervalId);
      }
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, [rateLimitUntil, emailCooldowns]);

  // Listen to Supabase auth changes (deduplicated to avoid repeat API calls)
  useEffect(() => {
    if (!supabase) {
      setUser(null);
      setJourneyLogs([]);
      return;
    }

    let mounted = true;
    const syncUser = (nextUser: User | null) => {
      setUser((prev) => {
        if (
          (prev?.id ?? null) === (nextUser?.id ?? null) &&
          (prev?.email ?? null) === (nextUser?.email ?? null)
        ) {
          return prev;
        }
        return nextUser;
      });
    };

    supabase.auth.getSession().then(({ data, error }) => {
      if (!mounted) return;
      if (error) {
        syncUser(null);
        setAuthFeedback({
          type: 'error',
          message: extractSupabaseErrorMessage(
            error,
            'Could not verify current session.'
          ),
        });
        return;
      }
      syncUser(data?.session?.user || null);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!mounted) return;
      const nextUser = session?.user || null;
      syncUser(nextUser);
      if (nextUser && event === 'SIGNED_IN') {
        setPendingVerificationEmail('');
      }
      if (!nextUser) {
        setJourneyLogs([]);
        setSaveActivityConsent(false);
        setSaveLocationHistoryConsent(false);
      }
    });

    return () => {
      mounted = false;
      sub?.subscription?.unsubscribe();
    };
  }, [supabase]);

  // Load cloud user settings, contacts & private journey logs when signed in
  const currentUserId = user?.id ?? null;
  const fetchUserPrivateData = useCallback(async () => {
    if (!supabase || !currentUserId) {
      loadLocalPreferences();
      return;
    }

    setSettingsLoading(true);
    setJourneyLoading(true);
    setJourneySchemaWarning(false);
    try {
      const [contactsRes, settingsRes, readsRes] = await Promise.all([
        supabase
          .from('trusted_contacts')
          .select('id, name, phone, created_at')
          .eq('user_id', currentUserId)
          .order('created_at', { ascending: true }),
        supabase
          .from('user_settings')
          .select(
            'police_number, ambulance_number, save_activity_consent, save_location_history_consent, save_profile_consent'
          )
          .eq('user_id', currentUserId)
          .maybeSingle(),
        supabase
          .from('alert_reads')
          .select('alert_id')
          .eq('user_id', currentUserId),
      ]);

      if (contactsRes.error) throw contactsRes.error;
      if (readsRes.error) throw readsRes.error;

      // Fallback if user has not yet re-run updated schema.sql for consent columns
      let settingsData = settingsRes.data;
      if (settingsRes.error) {
        const fallbackSettings = await supabase
          .from('user_settings')
          .select('police_number, ambulance_number')
          .eq('user_id', currentUserId)
          .maybeSingle();
        if (fallbackSettings.error) throw fallbackSettings.error;
        settingsData = fallbackSettings.data
          ? {
              ...fallbackSettings.data,
              save_activity_consent: false,
              save_location_history_consent: false,
              save_profile_consent: true,
            }
          : null;
        setJourneySchemaWarning(true);
      }

      setContacts((contactsRes.data as TrustedContact[]) || []);
      setPoliceNumber(settingsData?.police_number || '');
      setAmbulanceNumber(settingsData?.ambulance_number || '');
      setSaveActivityConsent(Boolean(settingsData?.save_activity_consent));
      setSaveLocationHistoryConsent(
        Boolean(settingsData?.save_location_history_consent)
      );
      setSaveProfileConsent(
        settingsData
          ? Boolean(settingsData.save_profile_consent) ||
              (contactsRes.data?.length ?? 0) > 0 ||
              Boolean(settingsData.police_number) ||
              Boolean(settingsData.ambulance_number)
          : false
      );
      setReadAlertIds(
        (readsRes.data || []).map((r: { alert_id: string }) => r.alert_id)
      );

      // Load private journey history (visible only to signed-in owner via RLS)
      const journeyRes = await supabase
        .from('safety_journey_logs')
        .select(
          'id, user_id, activity_type, title, status, details, lat, lng, created_at'
        )
        .eq('user_id', currentUserId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (journeyRes.error) {
        setJourneySchemaWarning(true);
        setJourneyLogs([]);
      } else {
        setJourneyLogs((journeyRes.data as SafetyJourneyLog[]) || []);
      }
    } catch (err) {
      setSettingsFeedback({
        type: 'error',
        message: `Could not load cloud settings: ${extractSupabaseErrorMessage(
          err,
          'Unknown error'
        )}`,
      });
    } finally {
      setSettingsLoading(false);
      setJourneyLoading(false);
    }
  }, [supabase, currentUserId, loadLocalPreferences]);

  useEffect(() => {
    fetchUserPrivateData();
  }, [fetchUserPrivateData]);

  // Keep shareContactId valid & auto-select new trusted contacts for instant SOS
  useEffect(() => {
    if (contacts.length > 0 && !contacts.some((c) => c.id === shareContactId)) {
      setShareContactId(contacts[0].id);
    } else if (contacts.length === 0) {
      setShareContactId('');
    }

    const currentIds = new Set(contacts.map((c) => c.id));
    setSosSelectedIds((prev) => {
      const kept = prev.filter((id) => currentIds.has(id));
      const newlyAdded = contacts
        .filter((c) => !sosKnownContactIdsRef.current.has(c.id))
        .map((c) => c.id);
      sosKnownContactIdsRef.current = currentIds;
      return Array.from(new Set([...kept, ...newlyAdded]));
    });
  }, [contacts, shareContactId]);

  // Cleanup SOS timers and background location listeners on unmount
  useEffect(() => {
    return () => {
      if (sosStatusTimerRef.current !== null) {
        window.clearTimeout(sosStatusTimerRef.current);
      }
      sosDispatchRef.current?.cancelBgLocation?.();
    };
  }, []);

  // Fetch Crowd Reports from Supabase
  const fetchCrowdReports = useCallback(async () => {
    if (!supabase) {
      setCrowdReports([]);
      return;
    }

    setCrowdLoading(true);
    setCrowdFeedback(null);
    try {
      const { data, error } = await supabase
        .from('crowd_reports')
        .select('id, user_id, level, lat, lng, location_label, note, created_at')
        .order('created_at', { ascending: false })
        .limit(60);

      if (error) throw error;
      setCrowdReports((data as CrowdReport[]) || []);
    } catch (err) {
      const msg = extractSupabaseErrorMessage(err, 'Unknown error');
      setCrowdFeedback({
        type: 'error',
        message: `Unable to load crowd reports: ${msg}`,
      });
    } finally {
      setCrowdLoading(false);
    }
  }, [supabase]);

  // Fetch Safety Alerts from Supabase
  const fetchSafetyAlerts = useCallback(async () => {
    if (!supabase) {
      setAlerts([]);
      return;
    }

    setAlertsLoading(true);
    setAlertsFeedback(null);
    try {
      const { data, error } = await supabase
        .from('safety_alerts')
        .select(
          'id, user_id, title, message, location_text, lat, lng, source_type, created_at'
        )
        .order('created_at', { ascending: false })
        .limit(40);

      if (error) throw error;
      setAlerts((data as SafetyAlert[]) || []);
    } catch (err) {
      const msg = extractSupabaseErrorMessage(err, 'Unknown error');
      setAlertsFeedback({
        type: 'error',
        message: `Unable to load safety alerts: ${msg}`,
      });
    } finally {
      setAlertsLoading(false);
    }
  }, [supabase]);

  useEffect(() => {
    fetchCrowdReports();
    fetchSafetyAlerts();
  }, [fetchCrowdReports, fetchSafetyAlerts]);

  // Active Live Share countdown timer (foreground only)
  useEffect(() => {
    if (!activeShareSession) {
      setShareSecondsLeft(0);
      return;
    }

    const updateTick = () => {
      const remaining = Math.max(
        0,
        Math.floor((activeShareSession.expiresAt - Date.now()) / 1000)
      );
      setShareSecondsLeft(remaining);
      if (remaining === 0) {
        setActiveShareSession(null);
        setShareFeedback({
          type: 'info',
          message: 'Sharing session timer ended.',
        });
      }
    };

    updateTick();
    const timer = window.setInterval(updateTick, 1000);
    return () => window.clearInterval(timer);
  }, [activeShareSession]);

  function openModule(moduleId: ModuleId) {
    setActiveSection('modules');
    setActiveModule(moduleId);
    setShowSettings(false);
  }

  function navigateSection(sectionId: SectionId) {
    setActiveSection(sectionId);
    setShowSettings(false);
  }

  // ---------------- AUTH HANDLERS ----------------
  const globalRateLimitRemainingSec = Math.max(
    0,
    Math.ceil((rateLimitUntil - authNowMs) / 1000)
  );
  const normalizedAuthEmail = authEmail.trim().toLowerCase();
  const activeEmailCooldownUntil = Math.max(
    rateLimitUntil,
    (normalizedAuthEmail && emailCooldowns[normalizedAuthEmail]) || 0,
    (pendingVerificationEmail && emailCooldowns[pendingVerificationEmail]) || 0
  );
  const verificationCooldownRemainingSec = Math.max(
    0,
    Math.ceil((activeEmailCooldownUntil - authNowMs) / 1000)
  );
  const resendAlreadyUsedForPending = Boolean(
    pendingVerificationEmail && resendUsedEmails[pendingVerificationEmail]
  );

  async function executeSignUp(normalizedEmail: string) {
    if (!supabase) return;
    const now = Date.now();

    // 1. Block signUp() while a Supabase email rate limit cooldown is active
    if (rateLimitUntil > now) {
      const waitSec = Math.ceil((rateLimitUntil - now) / 1000);
      setAuthFeedback({
        type: 'error',
        message: `[over_email_send_rate_limit · HTTP 429] Email rate limit active. Wait ${formatCooldownDuration(
          waitSec
        )} before creating another account, or use Sign In if your account is already confirmed.`,
      });
      return;
    }

    // 2. Never call signUp() more than once for an email that already registered
    const emailWaitUntil = emailCooldowns[normalizedEmail] || 0;
    if (
      Boolean(signedUpEmails[normalizedEmail]) ||
      pendingVerificationEmail === normalizedEmail ||
      emailWaitUntil > now
    ) {
      setAuthMode('signin');
      setAuthFeedback({
        type: 'info',
        message: `Account registration for ${normalizedEmail} was already submitted. Check your inbox (and spam folder) for the verification link, then use Sign In.`,
      });
      return;
    }

    authInFlightRef.current = true;
    setAuthLoading(true);
    setAuthFeedback({
      type: 'loading',
      message: 'Creating your account...',
    });

    try {
      const { data, error } = await supabase.auth.signUp({
        email: normalizedEmail,
        password: authPassword,
      });

      if (error) {
        const parsed = formatSupabaseAuthError(error, 'signup');
        if (parsed.isRateLimit) {
          const until = Date.now() + parsed.cooldownSeconds * 1000;
          setRateLimitUntil(until);
          setEmailCooldowns((prev) => ({ ...prev, [normalizedEmail]: until }));
        }
        if (parsed.isExistingUser) {
          setSignedUpEmails((prev) => ({ ...prev, [normalizedEmail]: Date.now() }));
          setAuthMode('signin');
        }
        setAuthFeedback({ type: 'error', message: parsed.message });
        return;
      }

      if (!data?.user) {
        setAuthFeedback({
          type: 'error',
          message:
            'Account creation did not return a user record. Check your Supabase Auth configuration.',
        });
        return;
      }

      if (
        Array.isArray(data.user.identities) &&
        data.user.identities.length === 0
      ) {
        setSignedUpEmails((prev) => ({ ...prev, [normalizedEmail]: Date.now() }));
        setAuthMode('signin');
        setAuthFeedback({
          type: 'error',
          message:
            '[user_already_exists] An account with this email already exists. Switched to Sign In — enter your password to log in.',
        });
        return;
      }

      setSignedUpEmails((prev) => ({ ...prev, [normalizedEmail]: Date.now() }));

      if (!data.session) {
        const cooldownUntil = Date.now() + 120_000;
        setPendingVerificationEmail(normalizedEmail);
        setEmailCooldowns((prev) => ({
          ...prev,
          [normalizedEmail]: cooldownUntil,
        }));
        setAuthPassword('');
        // Automatically switch to Sign In so the user cannot accidentally re-submit Create Account
        setAuthMode('signin');
        setAuthFeedback({
          type: 'success',
          message: `Account created. Check your inbox (and spam folder) to verify ${normalizedEmail}, then sign in below.`,
        });
      } else {
        setPendingVerificationEmail('');
        setAuthPassword('');
        setAuthFeedback({
          type: 'success',
          message: 'Account created and signed in.',
        });
      }
    } catch (err) {
      const parsed = formatSupabaseAuthError(err, 'signup');
      if (parsed.isRateLimit) {
        const until = Date.now() + parsed.cooldownSeconds * 1000;
        setRateLimitUntil(until);
        setEmailCooldowns((prev) => ({ ...prev, [normalizedEmail]: until }));
      }
      setAuthFeedback({ type: 'error', message: parsed.message });
    } finally {
      authInFlightRef.current = false;
      setAuthLoading(false);
    }
  }

  async function executeSignInWithPassword(normalizedEmail: string) {
    if (!supabase) return;

    authInFlightRef.current = true;
    setAuthLoading(true);
    setAuthFeedback({
      type: 'loading',
      message: 'Signing in...',
    });

    try {
      // Existing users ALWAYS authenticate with signInWithPassword() — never signUp()
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: authPassword,
      });

      if (error) {
        const parsed = formatSupabaseAuthError(error, 'signin');
        if (parsed.isRateLimit) {
          setRateLimitUntil(Date.now() + parsed.cooldownSeconds * 1000);
        }
        if (parsed.isEmailNotConfirmed) {
          setPendingVerificationEmail(normalizedEmail);
          setSignedUpEmails((prev) => ({
            ...prev,
            [normalizedEmail]: prev[normalizedEmail] || Date.now(),
          }));
        }
        setAuthFeedback({ type: 'error', message: parsed.message });
        return;
      }

      if (!data?.user || !data?.session) {
        setAuthFeedback({
          type: 'error',
          message:
            'Sign in did not return an active session. Please verify your email confirmation status and try again.',
        });
        return;
      }

      setPendingVerificationEmail('');
      setAuthPassword('');
      setAuthFeedback({
        type: 'success',
        message: 'Signed in successfully.',
      });
    } catch (err) {
      const parsed = formatSupabaseAuthError(err, 'signin');
      if (parsed.isRateLimit) {
        setRateLimitUntil(Date.now() + parsed.cooldownSeconds * 1000);
      }
      setAuthFeedback({ type: 'error', message: parsed.message });
    } finally {
      authInFlightRef.current = false;
      setAuthLoading(false);
    }
  }

  async function handleAuthSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (authInFlightRef.current) return;

    if (!supabase) {
      setShowSetupModal(true);
      return;
    }

    const normalizedEmail = authEmail.trim().toLowerCase();
    if (!validateEmail(normalizedEmail)) {
      setAuthFeedback({ type: 'error', message: 'Enter a valid email address.' });
      return;
    }
    if (authPassword.length < 6) {
      setAuthFeedback({
        type: 'error',
        message: 'Password must be at least 6 characters.',
      });
      return;
    }

    if (authMode === 'signup') {
      await executeSignUp(normalizedEmail);
    } else {
      await executeSignInWithPassword(normalizedEmail);
    }
  }

  async function handleResendVerification() {
    if (authInFlightRef.current || !supabase || !pendingVerificationEmail) {
      return;
    }

    const now = Date.now();
    const targetEmail = pendingVerificationEmail.trim().toLowerCase();

    // Prevent repeated confirmation email resends
    if (resendUsedEmails[targetEmail]) {
      setAuthFeedback({
        type: 'info',
        message: `A confirmation email was already resent to ${targetEmail}. Check your inbox and spam folder instead of sending another request.`,
      });
      return;
    }

    const cooldownUntil = Math.max(
      rateLimitUntil,
      emailCooldowns[targetEmail] || 0
    );

    if (cooldownUntil > now) {
      const waitSec = Math.ceil((cooldownUntil - now) / 1000);
      setAuthFeedback({
        type: 'info',
        message: `Please wait ${formatCooldownDuration(
          waitSec
        )} before requesting a verification email.`,
      });
      return;
    }

    authInFlightRef.current = true;
    setAuthLoading(true);
    setAuthFeedback({
      type: 'loading',
      message: `Sending verification email to ${targetEmail}...`,
    });

    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: targetEmail,
      });
      if (error) {
        const parsed = formatSupabaseAuthError(error, 'resend');
        if (parsed.isRateLimit) {
          const until = Date.now() + parsed.cooldownSeconds * 1000;
          setRateLimitUntil(until);
          setEmailCooldowns((prev) => ({ ...prev, [targetEmail]: until }));
        }
        setAuthFeedback({ type: 'error', message: parsed.message });
        return;
      }

      const nextCooldown = Date.now() + 180_000;
      setResendUsedEmails((prev) => ({ ...prev, [targetEmail]: true }));
      setEmailCooldowns((prev) => ({ ...prev, [targetEmail]: nextCooldown }));
      setAuthFeedback({
        type: 'success',
        message: `Verification email sent once to ${targetEmail}. Check your inbox and spam folder, then sign in.`,
      });
    } catch (err) {
      const parsed = formatSupabaseAuthError(err, 'resend');
      if (parsed.isRateLimit) {
        const until = Date.now() + parsed.cooldownSeconds * 1000;
        setRateLimitUntil(until);
        setEmailCooldowns((prev) => ({ ...prev, [targetEmail]: until }));
      }
      setAuthFeedback({ type: 'error', message: parsed.message });
    } finally {
      authInFlightRef.current = false;
      setAuthLoading(false);
    }
  }

  async function handleSignOut() {
    if (!supabase || authInFlightRef.current) return;
    authInFlightRef.current = true;
    setAuthLoading(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setAuthFeedback({ type: 'success', message: 'Signed out.' });
    } catch (err) {
      setAuthFeedback({
        type: 'error',
        message: extractSupabaseErrorMessage(err, 'Sign out failed.'),
      });
    } finally {
      authInFlightRef.current = false;
      setAuthLoading(false);
    }
  }

  // ---------------- CONTACTS & SETTINGS CRUD ----------------
  async function handleSaveContact(e: React.FormEvent) {
    e.preventDefault();
    const trimmedName = contactForm.name.trim();
    if (!trimmedName) {
      setContactFeedback({
        type: 'error',
        message: 'Contact name is required.',
      });
      return;
    }
    const phoneCheck = validatePhoneNumber(contactForm.phone);
    if (!phoneCheck.valid || !phoneCheck.normalized) {
      setContactFeedback({
        type: 'error',
        message: phoneCheck.error || 'Invalid phone number.',
      });
      return;
    }
    if (!saveProfileConsent) {
      setContactFeedback({
        type: 'error',
        message:
          'Please check the consent box above before saving personal contact details.',
      });
      return;
    }

    setContactFeedback({ type: 'loading', message: 'Saving contact...' });

    if (supabase && user) {
      try {
        if (editingContactId) {
          const { error } = await supabase
            .from('trusted_contacts')
            .update({
              name: trimmedName,
              phone: phoneCheck.normalized,
              updated_at: new Date().toISOString(),
            })
            .eq('id', editingContactId)
            .eq('user_id', user.id);

          if (error) throw error;
        } else {
          const { error } = await supabase.from('trusted_contacts').insert({
            user_id: user.id,
            name: trimmedName,
            phone: phoneCheck.normalized,
          });
          if (error) throw error;
        }

        await fetchUserPrivateData();
        setContactForm({ name: '', phone: '' });
        setEditingContactId(null);
        setContactFeedback({
          type: 'success',
          message: 'Contact saved securely to your Supabase account.',
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error';
        setContactFeedback({
          type: 'error',
          message: `Failed to save contact: ${msg}`,
        });
      }
    } else {
      const next: TrustedContact[] = editingContactId
        ? contacts.map((c) =>
            c.id === editingContactId
              ? { ...c, name: trimmedName, phone: phoneCheck.normalized! }
              : c
          )
        : [
            ...contacts,
            {
              id: `local-${Date.now()}`,
              name: trimmedName,
              phone: phoneCheck.normalized!,
              isLocal: true,
            },
          ];

      setContacts(next);
      localStorage.setItem(LOCAL_CONTACTS_KEY, JSON.stringify(next));
      setContactForm({ name: '', phone: '' });
      setEditingContactId(null);
      setContactFeedback({
        type: 'success',
        message:
          'Saved on this device only. Sign in with Supabase to sync across devices.',
      });
    }
  }

  async function handleDeleteContact(contactId: string) {
    setContactFeedback({ type: 'loading', message: 'Removing contact...' });
    if (supabase && user) {
      try {
        const { error } = await supabase
          .from('trusted_contacts')
          .delete()
          .eq('id', contactId)
          .eq('user_id', user.id);
        if (error) throw error;
        await fetchUserPrivateData();
        setContactFeedback({ type: 'success', message: 'Contact removed.' });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error';
        setContactFeedback({
          type: 'error',
          message: `Could not delete contact: ${msg}`,
        });
      }
    } else {
      const next = contacts.filter((c) => c.id !== contactId);
      setContacts(next);
      localStorage.setItem(LOCAL_CONTACTS_KEY, JSON.stringify(next));
      setContactFeedback({
        type: 'success',
        message: 'Contact removed from this device.',
      });
    }
  }

  async function handleSaveEmergencyNumbers(e: React.FormEvent) {
    e.preventDefault();
    const pTrim = policeNumber.trim();
    const aTrim = ambulanceNumber.trim();

    if (pTrim) {
      const check = validatePhoneNumber(pTrim);
      if (!check.valid) {
        setSettingsFeedback({
          type: 'error',
          message: `Police number: ${check.error}`,
        });
        return;
      }
    }

    if (aTrim) {
      const check = validatePhoneNumber(aTrim);
      if (!check.valid) {
        setSettingsFeedback({
          type: 'error',
          message: `Ambulance number: ${check.error}`,
        });
        return;
      }
    }

    if (!saveProfileConsent) {
      setSettingsFeedback({
        type: 'error',
        message:
          'Please confirm consent to save your personal safety preferences first.',
      });
      return;
    }

    setSettingsFeedback({
      type: 'loading',
      message: 'Saving emergency numbers...',
    });

    if (supabase && user) {
      try {
        const { error } = await supabase.from('user_settings').upsert(
          {
            user_id: user.id,
            police_number: pTrim,
            ambulance_number: aTrim,
            save_activity_consent: saveActivityConsent,
            save_location_history_consent: saveLocationHistoryConsent,
            save_profile_consent: saveProfileConsent,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id' }
        );
        if (error) throw error;
        setSettingsFeedback({
          type: 'success',
          message: 'Emergency numbers saved to your Supabase account.',
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error';
        setSettingsFeedback({
          type: 'error',
          message: `Could not save settings: ${msg}`,
        });
      }
    } else {
      localStorage.setItem(
        LOCAL_SETTINGS_KEY,
        JSON.stringify({
          police_number: pTrim,
          ambulance_number: aTrim,
          save_profile_consent: saveProfileConsent,
        })
      );
      setSettingsFeedback({
        type: 'success',
        message:
          'Saved on this device only. Sign in with Supabase to store in the cloud.',
      });
    }
  }

  // Helper: record private activity ONLY when signed in AND user explicitly consented
  const logJourneyActivity = useCallback(
    async (entry: {
      activityType: JourneyActivityType;
      title: string;
      status: string;
      details?: string;
      coords?: { lat: number; lng: number } | null;
    }) => {
      if (!supabase || !user || !saveActivityConsent) return;
      if (typeof navigator !== 'undefined' && !navigator.onLine) return;

      try {
        const includeCoords = Boolean(
          saveLocationHistoryConsent && entry.coords
        );
        const { data, error } = await supabase
          .from('safety_journey_logs')
          .insert({
            user_id: user.id,
            activity_type: entry.activityType,
            title: entry.title,
            status: entry.status,
            details: (entry.details || '').slice(0, 280),
            lat: includeCoords ? entry.coords!.lat : null,
            lng: includeCoords ? entry.coords!.lng : null,
          })
          .select(
            'id, user_id, activity_type, title, status, details, lat, lng, created_at'
          )
          .single();

        if (!error && data) {
          setJourneyLogs((prev) => [data as SafetyJourneyLog, ...prev]);
        }
      } catch {
        // Never block primary safety actions if logging fails
      }
    },
    [supabase, user, saveActivityConsent, saveLocationHistoryConsent]
  );

  async function handleUpdateJourneyConsents(updates: {
    activity?: boolean;
    locationHistory?: boolean;
    profile?: boolean;
  }) {
    const nextActivity =
      updates.activity !== undefined ? updates.activity : saveActivityConsent;
    const nextLocation =
      updates.locationHistory !== undefined
        ? updates.locationHistory
        : saveLocationHistoryConsent;
    const nextProfile =
      updates.profile !== undefined ? updates.profile : saveProfileConsent;

    // Turning off activity history also turns off precise location history
    const resolvedLocation = nextActivity ? nextLocation : false;

    setSaveActivityConsent(nextActivity);
    setSaveLocationHistoryConsent(resolvedLocation);
    setSaveProfileConsent(nextProfile);

    if (!supabase || !user) {
      localStorage.setItem(
        LOCAL_SETTINGS_KEY,
        JSON.stringify({
          police_number: policeNumber,
          ambulance_number: ambulanceNumber,
          save_profile_consent: nextProfile,
        })
      );
      return;
    }

    setJourneyFeedback({
      type: 'loading',
      message: 'Saving your privacy preference...',
    });

    try {
      const { error } = await supabase.from('user_settings').upsert(
        {
          user_id: user.id,
          police_number: policeNumber.trim(),
          ambulance_number: ambulanceNumber.trim(),
          save_activity_consent: nextActivity,
          save_location_history_consent: resolvedLocation,
          save_profile_consent: nextProfile,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'user_id' }
      );
      if (error) throw error;

      setJourneyFeedback({
        type: 'success',
        message: nextActivity
          ? 'Privacy preferences saved. Only you can view your Safety Journey.'
          : 'Activity recording is paused. Nothing new will be logged.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setJourneyFeedback({
        type: 'error',
        message: `Could not update consent preferences (make sure the latest schema.sql has been run): ${msg}`,
      });
    }
  }

  async function handleDeleteJourneyItem(logId: string) {
    if (!supabase || !user) return;
    setJourneyFeedback({
      type: 'loading',
      message: 'Removing item from your history...',
    });
    try {
      const { error } = await supabase
        .from('safety_journey_logs')
        .delete()
        .eq('id', logId)
        .eq('user_id', user.id);

      if (error) throw error;
      setJourneyLogs((prev) => prev.filter((item) => item.id !== logId));
      setJourneyFeedback({
        type: 'success',
        message: 'History item removed.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setJourneyFeedback({
        type: 'error',
        message: `Could not delete history item: ${msg}`,
      });
    }
  }

  async function handleClearAllJourneyHistory() {
    if (!supabase || !user) return;
    setJourneyLoading(true);
    setJourneyFeedback({
      type: 'loading',
      message: 'Clearing your full activity history...',
    });
    try {
      const { error } = await supabase
        .from('safety_journey_logs')
        .delete()
        .eq('user_id', user.id);

      if (error) throw error;
      setJourneyLogs([]);
      setConfirmClearJourney(false);
      setJourneyFeedback({
        type: 'success',
        message: 'Your activity history has been cleared.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setJourneyFeedback({
        type: 'error',
        message: `Could not clear history: ${msg}`,
      });
    } finally {
      setJourneyLoading(false);
    }
  }

  async function handleDeleteAllMyData() {
    setDeleteDataLoading(true);
    setSettingsFeedback(null);

    try {
      if (supabase && user) {
        const deletions = await Promise.all([
          supabase.from('safety_journey_logs').delete().eq('user_id', user.id),
          supabase.from('alert_reads').delete().eq('user_id', user.id),
          supabase.from('safety_alerts').delete().eq('user_id', user.id),
          supabase.from('crowd_reports').delete().eq('user_id', user.id),
          supabase.from('trusted_contacts').delete().eq('user_id', user.id),
          supabase.from('user_settings').delete().eq('user_id', user.id),
        ]);

        const failed = deletions.find((r) => r.error);
        if (failed?.error) throw failed.error;

        await supabase.auth.signOut();
      }

      localStorage.removeItem(LOCAL_CONTACTS_KEY);
      localStorage.removeItem(LOCAL_SETTINGS_KEY);
      localStorage.removeItem(LOCAL_READ_ALERTS_KEY);
      localStorage.removeItem(LAST_KNOWN_LOCATION_KEY);

      setContacts([]);
      setPoliceNumber('');
      setAmbulanceNumber('');
      setReadAlertIds([]);
      setJourneyLogs([]);
      setSaveProfileConsent(false);
      setSaveActivityConsent(false);
      setSaveLocationHistoryConsent(false);
      setActiveShareSession(null);
      setConfirmDeleteData(false);

      await Promise.all([fetchCrowdReports(), fetchSafetyAlerts()]);

      setSettingsFeedback({
        type: 'success',
        message:
          'All your stored data (contacts, settings, journey logs, reports, alerts, and local browser data) has been deleted.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setSettingsFeedback({
        type: 'error',
        message: `Error deleting data: ${msg}`,
      });
    } finally {
      setDeleteDataLoading(false);
    }
  }

  // ---------------- 1. SOS HANDLERS (INSTANT ACTIVATION) ----------------
  function getSosStatusLabel(status: SosStatus): string {
    switch (status) {
      case 'activated':
        return 'SOS Activated';
      case 'sending':
        return 'Sending Alert';
      case 'sent':
        return 'SMS Sent';
      case 'failed':
        return 'SMS Failed';
      default:
        return 'SOS Ready';
    }
  }

  function buildSosPayload(
    locationObj: Coordinates | null,
    selectedContacts: TrustedContact[]
  ) {
    const selectedPhones = selectedContacts.map((c) => c.phone);
    const mapLink = locationObj
      ? buildMapLink(locationObj.lat, locationObj.lng)
      : '';
    const message = locationObj
      ? `SOS ALERT from SafeHer: I need help right now. My location: ${mapLink}`
      : 'SOS ALERT from SafeHer: I need help right now. (Checking GPS in background — please call or text me.)';
    const smsHref = buildSmsHref(selectedPhones, message);
    return {
      selectedPhones,
      mapLink,
      message,
      smsHref,
    };
  }

  function toggleSosContact(id: string) {
    setSosSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  }

  function scheduleSmsSentConfirmation(eventId: string) {
    if (sosStatusTimerRef.current !== null) {
      window.clearTimeout(sosStatusTimerRef.current);
    }

    const markSent = () => {
      if (sosDispatchRef.current?.eventId !== eventId) return;
      if (sosDispatchRef.current.status === 'failed') return;
      sosDispatchRef.current.status = 'sent';
      setSosState((prev) =>
        prev && prev.eventId === eventId && prev.status === 'sending'
          ? { ...prev, status: 'sent' }
          : prev
      );
    };

    const onVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        document.removeEventListener('visibilitychange', onVisibilityChange);
        markSent();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);

    sosStatusTimerRef.current = window.setTimeout(() => {
      document.removeEventListener('visibilitychange', onVisibilityChange);
      markSent();
    }, 260);
  }

  function triggerInstantSos() {
    const selectedContacts = contacts.filter((c) =>
      sosSelectedIds.includes(c.id)
    );
    const recipientSignature = selectedContacts
      .map((c) => sanitizeDialNumber(c.phone))
      .filter(Boolean)
      .sort()
      .join(',');

    const now = Date.now();
    const activeDispatch = sosDispatchRef.current;

    // Prevent accidental double-tap / duplicate SMS triggers
    if (
      activeDispatch &&
      (activeDispatch.status === 'activated' ||
        activeDispatch.status === 'sending' ||
        (activeDispatch.status === 'sent' &&
          activeDispatch.signature === recipientSignature &&
          now - activeDispatch.lastTriggeredAt < 4000))
    ) {
      setSosDuplicateNotice(
        'Duplicate SOS prevented — your active emergency alert is already in progress.'
      );
      setSosModalOpen(true);
      return;
    }

    // Cancel any previous background GPS listener or timer
    if (sosStatusTimerRef.current !== null) {
      window.clearTimeout(sosStatusTimerRef.current);
      sosStatusTimerRef.current = null;
    }
    activeDispatch?.cancelBgLocation?.();

    const eventId =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `sos-${now}-${Math.random().toString(36).slice(2, 7)}`;

    // 1. Grab last known location synchronously (0ms) — never block SMS on GPS!
    const cachedStorageLocation = getLastKnownLocation();
    const immediateCoords = userMapLocation || cachedStorageLocation;
    const isRecentMemoryLocation = Boolean(
      userMapLocation &&
        userMapLocation.timestamp &&
        now - userMapLocation.timestamp < 60_000
    );
    const immediateLocationSource: 'none' | 'cached' | 'fresh' = immediateCoords
      ? isRecentMemoryLocation
        ? 'fresh'
        : 'cached'
      : 'none';

    const { mapLink, message, smsHref } = buildSosPayload(
      immediateCoords,
      selectedContacts
    );
    const offlineNow =
      typeof navigator !== 'undefined' ? !navigator.onLine : !isOnline;

    setSosCopied(false);
    setSosDuplicateNotice('');

    // 2. Activate SOS immediately (zero loading/AI/network delay)
    const initialState: SosAlertState = {
      eventId,
      status: 'activated',
      smsHref,
      message,
      hasLocation: Boolean(immediateCoords),
      locationSource: immediateLocationSource,
      coords: immediateCoords,
      mapLink,
      recipientCount: selectedContacts.length,
      recipientNames: selectedContacts.map((c) => c.name),
      isOffline: offlineNow,
      locatingInBackground: true,
      retryCount: 0,
      updatedAfterSend: false,
      triggeredAt: now,
    };

    sosDispatchRef.current = {
      eventId,
      status: 'activated',
      signature: recipientSignature,
      lastTriggeredAt: now,
    };

    setSosState(initialState);
    setSosModalOpen(true);

    // 3. Launch native device SMS synchronously inside the user tap gesture
    const launchResult = launchSmsUri(smsHref);

    if (!launchResult.launched) {
      if (sosDispatchRef.current?.eventId === eventId) {
        sosDispatchRef.current.status = 'failed';
      }
      setSosState((prev) =>
        prev && prev.eventId === eventId
          ? {
              ...prev,
              status: 'failed',
              errorMessage:
                launchResult.error ||
                'Could not open your messaging app. Tap Retry SMS or copy the emergency text.',
            }
          : prev
      );
    } else {
      if (sosDispatchRef.current?.eventId === eventId) {
        sosDispatchRef.current.status = 'sending';
      }
      setSosState((prev) =>
        prev && prev.eventId === eventId
          ? { ...prev, status: 'sending', errorMessage: undefined }
          : prev
      );
      scheduleSmsSentConfirmation(eventId);
    }

    // 4. Fetch fresh GPS location asynchronously in background (never blocks SMS)
    const cancelBg = requestBackgroundLocationRefresh(
      (freshCoords) => {
        setUserMapLocation(freshCoords);
        setMapCenter({ lat: freshCoords.lat, lng: freshCoords.lng });
        setPickedLocation({ lat: freshCoords.lat, lng: freshCoords.lng });

        if (sosDispatchRef.current?.eventId !== eventId) return;
        const updated = buildSosPayload(freshCoords, selectedContacts);

        setSosState((prev) => {
          if (!prev || prev.eventId !== eventId) return prev;
          return {
            ...prev,
            coords: freshCoords,
            hasLocation: true,
            locationSource: 'fresh',
            mapLink: updated.mapLink,
            message: updated.message,
            smsHref: updated.smsHref,
            locationError: undefined,
            updatedAfterSend: true,
          };
        });
      },
      (errMessage) => {
        if (sosDispatchRef.current?.eventId !== eventId) return;
        setSosState((prev) => {
          if (!prev || prev.eventId !== eventId) return prev;
          return {
            ...prev,
            locatingInBackground: false,
            locationError: prev.locationSource === 'fresh' ? undefined : errMessage,
          };
        });
      }
    );

    if (sosDispatchRef.current?.eventId === eventId) {
      sosDispatchRef.current.cancelBgLocation = cancelBg;
    } else {
      cancelBg();
    }

    // 5. Log SOS activity asynchronously ONLY if online & consented (no duplicate log)
    if (!offlineNow && !sosLoggedEventsRef.current.has(eventId)) {
      sosLoggedEventsRef.current.add(eventId);
      void logJourneyActivity({
        activityType: 'sos',
        title: 'SOS Activated',
        status: launchResult.launched
          ? immediateCoords
            ? 'Emergency SMS opened with cached location'
            : 'Emergency SMS opened immediately'
          : 'Emergency SMS launch failed',
        details:
          selectedContacts.length > 0
            ? `Targeted ${selectedContacts.length} trusted contact${selectedContacts.length === 1 ? '' : 's'}`
            : 'Opened native SMS composer for manual recipient selection',
        coords: immediateCoords,
      });
    }
  }

  function handleRetrySosSms() {
    if (!sosState) return;
    if (sosState.status === 'sending') return;

    const eventId = sosState.eventId;
    setSosDuplicateNotice('');

    if (sosDispatchRef.current?.eventId === eventId) {
      sosDispatchRef.current.status = 'sending';
      sosDispatchRef.current.lastTriggeredAt = Date.now();
    }

    setSosState((prev) =>
      prev && prev.eventId === eventId
        ? {
            ...prev,
            status: 'sending',
            errorMessage: undefined,
            retryCount: prev.retryCount + 1,
          }
        : prev
    );

    const launchResult = launchSmsUri(sosState.smsHref);
    if (!launchResult.launched) {
      if (sosDispatchRef.current?.eventId === eventId) {
        sosDispatchRef.current.status = 'failed';
      }
      setSosState((prev) =>
        prev && prev.eventId === eventId
          ? {
              ...prev,
              status: 'failed',
              errorMessage:
                launchResult.error ||
                'Retry could not open your device SMS app. Use Copy Message as fallback.',
            }
          : prev
      );
      return;
    }

    scheduleSmsSentConfirmation(eventId);
  }

  function handleSendUpdatedLocationSms() {
    if (!sosState) return;
    const eventId = sosState.eventId;
    setSosDuplicateNotice('');

    const launchResult = launchSmsUri(sosState.smsHref);
    if (!launchResult.launched) {
      if (sosDispatchRef.current?.eventId === eventId) {
        sosDispatchRef.current.status = 'failed';
      }
      setSosState((prev) =>
        prev && prev.eventId === eventId
          ? {
              ...prev,
              status: 'failed',
              errorMessage:
                launchResult.error || 'Could not open SMS app for updated location.',
            }
          : prev
      );
      return;
    }

    if (sosDispatchRef.current?.eventId === eventId) {
      sosDispatchRef.current.status = 'sending';
      sosDispatchRef.current.lastTriggeredAt = Date.now();
    }
    setSosState((prev) =>
      prev && prev.eventId === eventId
        ? {
            ...prev,
            status: 'sending',
            updatedAfterSend: false,
            errorMessage: undefined,
          }
        : prev
    );
    scheduleSmsSentConfirmation(eventId);
  }

  function handleResetSos() {
    if (sosStatusTimerRef.current !== null) {
      window.clearTimeout(sosStatusTimerRef.current);
      sosStatusTimerRef.current = null;
    }
    sosDispatchRef.current?.cancelBgLocation?.();
    sosDispatchRef.current = null;
    setSosDuplicateNotice('');
    setSosState(null);
    setSosModalOpen(false);
  }

  async function handleCopySosMessage() {
    if (!sosState?.message) return;
    try {
      await navigator.clipboard.writeText(sosState.message);
      setSosCopied(true);
      window.setTimeout(() => setSosCopied(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  }

  // ---------------- 2. CROWD MAP HANDLERS ----------------
  async function handleFindMyLocationOnMap() {
    setCrowdFeedback({
      type: 'loading',
      message: 'Finding your location...',
    });
    try {
      const { coords, isCachedFallback } = await fetchLocationWithFastFallback(
        (freshCoords) => {
          setUserMapLocation(freshCoords);
          setMapCenter({ lat: freshCoords.lat, lng: freshCoords.lng });
          setPickedLocation({ lat: freshCoords.lat, lng: freshCoords.lng });
          setCrowdFeedback({
            type: 'success',
            message: `Updated to fresh GPS location (±${freshCoords.accuracy ?? 0}m).`,
          });
        }
      );
      setUserMapLocation(coords);
      setMapCenter({ lat: coords.lat, lng: coords.lng });
      setPickedLocation({ lat: coords.lat, lng: coords.lng });
      setCrowdFeedback({
        type: 'success',
        message: isCachedFallback
          ? 'Centered on last known location while GPS refines in background.'
          : `Centered on your location (±${coords.accuracy ?? 0}m).`,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Location unavailable.';
      setCrowdFeedback({ type: 'error', message: msg });
    }
  }

  async function handleUseMyLocationForReport() {
    setCrowdFeedback({
      type: 'loading',
      message: 'Getting coordinates for report...',
    });
    try {
      const { coords, isCachedFallback } = await fetchLocationWithFastFallback(
        (freshCoords) => {
          setUserMapLocation(freshCoords);
          setPickedLocation({ lat: freshCoords.lat, lng: freshCoords.lng });
          setMapCenter({ lat: freshCoords.lat, lng: freshCoords.lng });
        }
      );
      setUserMapLocation(coords);
      setPickedLocation({ lat: coords.lat, lng: coords.lng });
      setMapCenter({ lat: coords.lat, lng: coords.lng });
      setCrowdFeedback({
        type: 'success',
        message: isCachedFallback
          ? 'Report pin set to last known location (updating GPS in background).'
          : 'Report pin set to your current location.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Location unavailable.';
      setCrowdFeedback({ type: 'error', message: msg });
    }
  }

  async function handleSubmitCrowdReport(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) {
      setShowSetupModal(true);
      return;
    }
    if (!user) {
      setCrowdFeedback({
        type: 'error',
        message: 'Sign in under Settings before submitting community reports.',
      });
      return;
    }
    if (!pickedLocation) {
      setCrowdFeedback({
        type: 'error',
        message:
          'Select a map location first by tapping the map or tapping “Use My Location”.',
      });
      return;
    }

    setReportSubmitting(true);
    setCrowdFeedback({
      type: 'loading',
      message: 'Saving report to Supabase...',
    });

    try {
      const { error } = await supabase.from('crowd_reports').insert({
        user_id: user.id,
        level: reportForm.level,
        lat: pickedLocation.lat,
        lng: pickedLocation.lng,
        location_label: reportForm.locationLabel.trim(),
        note: reportForm.note.trim(),
      });

      if (error) throw error;

      void logJourneyActivity({
        activityType: 'crowd_report',
        title: 'Crowd Report Submitted',
        status: `${reportForm.level} crowd reported`,
        details: reportForm.locationLabel.trim() || 'Community map check-in',
        coords: pickedLocation,
      });

      setReportForm({ level: 'Medium', locationLabel: '', note: '' });
      await fetchCrowdReports();
      setCrowdFeedback({
        type: 'success',
        message: 'Crowd report shared with the community.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setCrowdFeedback({
        type: 'error',
        message: `Failed to save report: ${msg}`,
      });
    } finally {
      setReportSubmitting(false);
    }
  }

  async function handleUpdateCrowdReport(reportId: string) {
    if (!supabase || !user) return;
    setCrowdFeedback({ type: 'loading', message: 'Updating report...' });
    try {
      const { error } = await supabase
        .from('crowd_reports')
        .update({
          level: editReportDraft.level,
          note: editReportDraft.note.trim(),
          updated_at: new Date().toISOString(),
        })
        .eq('id', reportId)
        .eq('user_id', user.id);

      if (error) throw error;
      setEditingReportId(null);
      await fetchCrowdReports();
      setCrowdFeedback({ type: 'success', message: 'Report updated.' });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setCrowdFeedback({
        type: 'error',
        message: `Could not update report: ${msg}`,
      });
    }
  }

  async function handleDeleteCrowdReport(reportId: string) {
    if (!supabase || !user) return;
    setCrowdFeedback({ type: 'loading', message: 'Deleting report...' });
    try {
      const { error } = await supabase
        .from('crowd_reports')
        .delete()
        .eq('id', reportId)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchCrowdReports();
      setCrowdFeedback({ type: 'success', message: 'Report deleted.' });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setCrowdFeedback({
        type: 'error',
        message: `Could not delete report: ${msg}`,
      });
    }
  }

  // ---------------- 3. SAFETY ALERTS HANDLERS ----------------
  async function handleAttachLocationToAlert() {
    setAlertsFeedback({
      type: 'loading',
      message: 'Requesting location permission...',
    });
    try {
      const coords = await requestBrowserLocation();
      setAlertForm((prev) => ({
        ...prev,
        coords,
        locationText:
          prev.locationText.trim() ||
          `GPS (${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)})`,
      }));
      setAlertsFeedback({
        type: 'success',
        message: 'Coordinates attached to alert draft.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Location unavailable.';
      setAlertsFeedback({ type: 'error', message: msg });
    }
  }

  async function handleCreateAlert(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) {
      setShowSetupModal(true);
      return;
    }
    if (!user) {
      setAlertsFeedback({
        type: 'error',
        message: 'Sign in under Settings to publish a community alert.',
      });
      return;
    }

    const title = alertForm.title.trim();
    const message = alertForm.message.trim();
    if (!title || !message) {
      setAlertsFeedback({
        type: 'error',
        message: 'Alert title and message are both required.',
      });
      return;
    }

    setAlertSubmitting(true);
    setAlertsFeedback({ type: 'loading', message: 'Publishing alert...' });

    try {
      const { error } = await supabase.from('safety_alerts').insert({
        user_id: user.id,
        title,
        message,
        location_text: alertForm.locationText.trim(),
        lat: alertForm.coords?.lat ?? null,
        lng: alertForm.coords?.lng ?? null,
        source_type: 'user',
      });

      if (error) throw error;

      void logJourneyActivity({
        activityType: 'safety_alert',
        title: 'Safety Alert Created',
        status: 'Published to community',
        details: title,
        coords: alertForm.coords,
      });

      setAlertForm({ title: '', message: '', locationText: '', coords: null });
      await fetchSafetyAlerts();
      setAlertsFeedback({
        type: 'success',
        message: 'User-created safety alert saved.',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setAlertsFeedback({
        type: 'error',
        message: `Could not publish alert: ${msg}`,
      });
    } finally {
      setAlertSubmitting(false);
    }
  }

  async function handleToggleReadAlert(alertId: string) {
    const currentlyRead = readAlertIds.includes(alertId);

    if (supabase && user && !String(alertId).startsWith('sample-')) {
      try {
        if (currentlyRead) {
          const { error } = await supabase
            .from('alert_reads')
            .delete()
            .eq('user_id', user.id)
            .eq('alert_id', alertId);
          if (error) throw error;
          setReadAlertIds((prev) => prev.filter((id) => id !== alertId));
        } else {
          const { error } = await supabase
            .from('alert_reads')
            .upsert(
              { user_id: user.id, alert_id: alertId },
              { onConflict: 'user_id,alert_id' }
            );
          if (error) throw error;
          setReadAlertIds((prev) => [...prev, alertId]);
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unknown error';
        setAlertsFeedback({
          type: 'error',
          message: `Failed to update read status: ${msg}`,
        });
      }
    } else {
      const next = currentlyRead
        ? readAlertIds.filter((id) => id !== alertId)
        : [...readAlertIds, alertId];
      setReadAlertIds(next);
      localStorage.setItem(LOCAL_READ_ALERTS_KEY, JSON.stringify(next));
    }
  }

  async function handleDeleteAlert(alertId: string) {
    if (!supabase || !user) return;
    setAlertsFeedback({ type: 'loading', message: 'Deleting alert...' });
    try {
      const { error } = await supabase
        .from('safety_alerts')
        .delete()
        .eq('id', alertId)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchSafetyAlerts();
      setAlertsFeedback({ type: 'success', message: 'Alert deleted.' });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setAlertsFeedback({
        type: 'error',
        message: `Could not delete alert: ${msg}`,
      });
    }
  }

  // ---------------- 4. LIVE LOCATION SHARE HANDLERS ----------------
  async function handleStartLocationShare() {
    const selectedContact = contacts.find((c) => c.id === shareContactId);
    if (!selectedContact) {
      setShareFeedback({
        type: 'error',
        message: 'Add and select a trusted contact before sharing.',
      });
      return;
    }

    setShareLoading(true);
    setShareFeedback({
      type: 'loading',
      message: 'Requesting your current location...',
    });

    try {
      const { coords } = await fetchLocationWithFastFallback((freshCoords) => {
        setUserMapLocation(freshCoords);
        const freshMapLink = buildMapLink(freshCoords.lat, freshCoords.lng);
        const freshMsg = `Hi ${selectedContact.name}, I'm sharing my current location via SafeHer for the next ${shareDurationMin} minutes: ${freshMapLink}`;
        const freshSmsHref = buildSmsHref([selectedContact.phone], freshMsg);
        setActiveShareSession((prev) =>
          prev
            ? {
                ...prev,
                mapLink: freshMapLink,
                message: freshMsg,
                smsHref: freshSmsHref,
              }
            : prev
        );
      });
      setUserMapLocation(coords);
      const mapLink = buildMapLink(coords.lat, coords.lng);
      const message = `Hi ${selectedContact.name}, I'm sharing my current location via SafeHer for the next ${shareDurationMin} minutes: ${mapLink}`;
      const smsHref = buildSmsHref([selectedContact.phone], message);

      const session: ActiveShareSession = {
        contactName: selectedContact.name,
        contactPhone: selectedContact.phone,
        mapLink,
        message,
        smsHref,
        startedAt: Date.now(),
        expiresAt: Date.now() + shareDurationMin * 60 * 1000,
      };
      setActiveShareSession(session);

      void logJourneyActivity({
        activityType: 'location_share',
        title: 'Location-Share Session',
        status: `Started (${shareDurationMin} min)`,
        details: `Prepared for ${selectedContact.name}`,
        coords,
      });

      if (typeof navigator !== 'undefined' && navigator.share) {
        try {
          await navigator.share({
            title: 'SafeHer Location Share',
            text: message,
            url: mapLink,
          });
          setShareFeedback({
            type: 'success',
            message:
              'Share sheet opened. Remember: closing this browser tab stops the in-app session.',
          });
        } catch (shareErr) {
          if (shareErr instanceof Error && shareErr.name === 'AbortError') {
            setShareFeedback({
              type: 'info',
              message:
                'Share sheet was dismissed. You can still send via SMS or copy the link below.',
            });
          } else {
            setShareFeedback({
              type: 'success',
              message:
                'Location link ready below. Tap “Open Messaging App” to send to your contact.',
            });
          }
        }
      } else {
        setShareFeedback({
          type: 'success',
          message:
            'Location link ready. Tap “Open Messaging App” or copy the link below.',
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Location unavailable.';
      setShareFeedback({ type: 'error', message: msg });
    } finally {
      setShareLoading(false);
    }
  }

  function handleStopSharing() {
    const contactName = activeShareSession?.contactName;
    setActiveShareSession(null);
    setShareSecondsLeft(0);
    setShareFeedback({
      type: 'success',
      message: 'In-app sharing session stopped.',
    });
    void logJourneyActivity({
      activityType: 'location_share',
      title: 'Location-Share Session',
      status: 'Stopped by user',
      details: contactName
        ? `Ended session for ${contactName}`
        : 'In-app sharing session ended',
      coords: null,
    });
  }

  // ---------------- 5. SPEED DIAL HANDLERS ----------------
  function handleRequestSpeedDial(label: string, number: string) {
    const trimmed = String(number || '').trim();
    if (!trimmed) {
      setShowSettings(true);
      setSettingsFeedback({
        type: 'info',
        message: `Configure your local ${label} phone number below first.`,
      });
      return;
    }

    const validation = validatePhoneNumber(trimmed);
    if (!validation.valid) {
      setShowSettings(true);
      setSettingsFeedback({
        type: 'error',
        message: `${label} number is invalid: ${validation.error}`,
      });
      return;
    }

    setDialOutcome(null);
    setDialCopied(false);
    setDialConfirmTarget({ label, number: trimmed });
  }

  function handleConfirmSpeedDial() {
    if (!dialConfirmTarget) return;
    const telNumber = sanitizeDialNumber(dialConfirmTarget.number);
    const telHref = `tel:${telNumber}`;
    setDialOutcome({
      label: dialConfirmTarget.label,
      number: dialConfirmTarget.number,
      telHref,
    });
    setDialConfirmTarget(null);

    try {
      window.location.href = telHref;
    } catch {
      // Fallback display stays visible
    }
  }

  // ---------------- 6. PUBLIC CONTACT FORM ----------------
  function handlePublicContactSubmit(e: React.FormEvent) {
    e.preventDefault();
    const name = publicContactForm.name.trim();
    const email = publicContactForm.email.trim();
    const message = publicContactForm.message.trim();

    if (!name) {
      setPublicContactPreview(null);
      setPublicContactStatus({
        type: 'error',
        message: 'Please enter your name.',
      });
      return;
    }
    if (!validateEmail(email)) {
      setPublicContactPreview(null);
      setPublicContactStatus({
        type: 'error',
        message: 'Please enter a valid email address.',
      });
      return;
    }
    if (message.length < 10) {
      setPublicContactPreview(null);
      setPublicContactStatus({
        type: 'error',
        message: 'Message must be at least 10 characters.',
      });
      return;
    }

    setPublicContactPreview({
      name,
      email,
      topic: publicContactTopic,
      message,
    });
    setPublicContactCopied(false);
    setPublicContactStatus({
      type: 'info',
      message:
        'Local Preview Only: All fields passed validation, and your message is previewed below. Because no email delivery service is connected, nothing was sent.',
    });
  }

  // Filtered reports for Crowd Map
  const visibleReports = useMemo(() => {
    const source =
      crowdReports.length > 0
        ? crowdReports
        : !supabaseConfigured && showSampleCrowd
          ? SAMPLE_CROWD_REPORTS
          : [];

    if (crowdFilter === 'All') return source;
    return source.filter((r) => r.level === crowdFilter);
  }, [crowdReports, crowdFilter, supabaseConfigured, showSampleCrowd]);

  const visibleAlerts = useMemo(() => {
    if (alerts.length > 0) return alerts;
    if (!supabaseConfigured && showSampleAlerts) return SAMPLE_ALERTS;
    return [];
  }, [alerts, supabaseConfigured, showSampleAlerts]);

  const unreadCount = useMemo(
    () => visibleAlerts.filter((a) => !readAlertIds.includes(a.id)).length,
    [visibleAlerts, readAlertIds]
  );

  const storageModeLabel =
    supabase && user
      ? 'Synced to Supabase'
      : 'Saved locally on this device only';

  // Reusable Trusted Contacts Manager block (used in Settings and Live Location Share)
  function renderTrustedContactsCard(compactTitle?: string) {
    return (
      <div className="space-y-3 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-base font-bold text-[#24101B]">
            {compactTitle || 'Trusted Contacts'} ({contacts.length})
          </h2>
          <span className="text-xs font-medium text-[#9D174D]">
            {storageModeLabel}
          </span>
        </div>

        <form onSubmit={handleSaveContact} className="space-y-2.5">
          <div className="grid gap-2.5 sm:grid-cols-2">
            <input
              type="text"
              aria-label="Trusted contact name"
              placeholder="Contact name (e.g., Sister, Mom)"
              value={contactForm.name}
              onChange={(e) =>
                setContactForm((p) => ({ ...p, name: e.target.value }))
              }
              className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
            />
            <input
              type="tel"
              aria-label="Trusted contact phone number"
              placeholder="Phone number with country code"
              value={contactForm.phone}
              onChange={(e) =>
                setContactForm((p) => ({ ...p, phone: e.target.value }))
              }
              className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
            />
          </div>

          <label className="flex cursor-pointer items-start gap-2.5 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-3 text-xs leading-relaxed text-[#3E1F30]">
            <input
              type="checkbox"
              checked={saveProfileConsent}
              onChange={(e) =>
                void handleUpdateJourneyConsents({ profile: e.target.checked })
              }
              className="mt-0.5 h-5 w-5 shrink-0 accent-[#E11D74]"
            />
            <span>
              I agree to let SafeHer store my trusted contacts privately (
              {supabase && user
                ? 'in my signed-in Supabase account'
                : 'locally on this device'}
              ).
            </span>
          </label>

          <div className="flex gap-2">
            <button
              type="submit"
              className="btn-rose-glow flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-2xl bg-[#E11D74] px-4 py-2 text-sm font-bold text-white hover:bg-[#9D174D]"
            >
              <Plus className="h-4 w-4" />
              {editingContactId ? 'Update Contact' : 'Add Contact'}
            </button>
            {editingContactId && (
              <button
                type="button"
                onClick={() => {
                  setEditingContactId(null);
                  setContactForm({ name: '', phone: '' });
                }}
                className="min-h-[44px] rounded-2xl border border-pink-200 px-4 py-2 text-sm font-semibold text-[#24101B] hover:bg-pink-50"
              >
                Cancel
              </button>
            )}
          </div>
        </form>

        {contactFeedback && (
          <FeedbackBanner
            feedback={contactFeedback}
            onDismiss={() => setContactFeedback(null)}
          />
        )}

        {contacts.length === 0 ? (
          <p className="rounded-2xl bg-[#FFF5F8] p-3.5 text-center text-xs text-[#5C3D4E]">
            No trusted contacts added yet. Add at least one contact to prefill SOS and Location Share messages.
          </p>
        ) : (
          <ul className="divide-y divide-pink-100 rounded-2xl border border-pink-100 bg-[#FFF5F8]">
            {contacts.map((c) => (
              <li
                key={c.id}
                className="flex items-center justify-between gap-2 px-3.5 py-3"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-[#24101B]">
                    {c.name}
                  </p>
                  <p className="font-mono text-xs tabular-nums text-[#5C3D4E]">
                    {c.phone}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    aria-label={`Edit ${c.name}`}
                    onClick={() => {
                      setEditingContactId(c.id);
                      setContactForm({ name: c.name, phone: c.phone });
                    }}
                    className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-[#24101B] shadow-sm hover:bg-pink-50"
                  >
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete ${c.name}`}
                    onClick={() => handleDeleteContact(c.id)}
                    className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-red-600 shadow-sm hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }

  return (
    <div className="relative min-h-screen text-[#24101B]">
      {/* Soft Self-Moving Pink Ambient Background */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      >
        <div className="ambient-orb-1 absolute -left-24 -top-24 h-[26rem] w-[26rem] rounded-full blur-2xl sm:h-[34rem] sm:w-[34rem]" />
        <div className="ambient-orb-2 absolute -right-28 top-1/4 h-[24rem] w-[24rem] rounded-full blur-2xl sm:h-[32rem] sm:w-[32rem]" />
        <div className="ambient-orb-3 absolute -bottom-28 left-1/4 h-[24rem] w-[24rem] rounded-full blur-2xl sm:h-[30rem] sm:w-[30rem]" />
      </div>

      {/* Sticky Top Header (Mobile compact + Desktop 3-zone) */}
      <header className="sticky top-0 z-30 border-b border-pink-100/90 bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex h-12 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6 md:h-14 md:gap-8">
          <button
            type="button"
            onClick={() => navigateSection('home')}
            className="flex shrink-0 items-center gap-2.5 text-left whitespace-nowrap rounded-xl py-1 transition-opacity hover:opacity-90"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-[#FB4F9B] to-[#E11D74] text-white shadow-[0_6px_14px_-4px_rgba(225,29,116,0.5)] md:h-9 md:w-9">
              <Heart className="h-4 w-4 fill-current" />
            </span>
            <span className="font-display text-lg font-extrabold tracking-tight text-[#24101B]">
              SafeHer
            </span>
          </button>

          {/* Desktop Section Navigation */}
          <nav
            aria-label="Desktop Navigation"
            className="hidden items-center gap-7 md:flex"
          >
            {SECTIONS.map((sec) => {
              const isActive = !showSettings && activeSection === sec.id;
              return (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => navigateSection(sec.id)}
                  aria-current={isActive ? 'page' : undefined}
                  className={`relative flex min-h-[44px] items-center whitespace-nowrap shrink-0 text-sm font-semibold transition-colors ${
                    isActive
                      ? 'text-[#E11D74]'
                      : 'text-[#5C3D4E] hover:text-[#24101B]'
                  }`}
                >
                  <span>{sec.label}</span>
                  {isActive && (
                    <span
                      aria-hidden="true"
                      className="absolute inset-x-0 bottom-1.5 h-0.5 rounded-full bg-[#E11D74]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          <div className="flex shrink-0 items-center gap-2.5">
            <button
              type="button"
              onClick={() => setShowSettings((prev) => !prev)}
              aria-label="Open Settings and Privacy"
              aria-pressed={showSettings}
              className={`flex h-10 min-w-[44px] items-center justify-center gap-1.5 rounded-2xl border px-3 text-xs font-bold whitespace-nowrap transition md:h-11 ${
                showSettings
                  ? 'btn-rose-glow border-[#E11D74] bg-[#E11D74] text-white'
                  : 'border-pink-200 bg-white text-[#24101B] hover:border-pink-300 hover:bg-pink-50/70'
              }`}
            >
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Settings</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="relative z-10 mx-auto w-full max-w-6xl space-y-6 px-4 pb-24 pt-5 sm:px-6 md:pb-14 md:pt-7">
        {!isOnline && (
          <div
            role="status"
            className="flex items-center gap-2.5 rounded-2xl border border-amber-300 bg-amber-50 px-4 py-3 text-xs font-medium text-amber-950"
          >
            <WifiOff className="h-4 w-4 shrink-0 text-amber-700" />
            <span>
              You are offline. Cloud sync, alerts, and map tiles are unavailable. SMS &amp; Speed Dial still work via your phone network.
            </span>
          </div>
        )}

        {showSettings ? (
          /* ==================== SETTINGS & PRIVACY VIEW ==================== */
          <section className="view-enter space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
              <div>
                <p className="text-xs font-semibold text-[#9D174D]">
                  Personal Preferences &amp; Cloud Sync
                </p>
                <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight text-[#24101B]">
                  Settings &amp; Privacy
                </h1>
                <p className="mt-0.5 text-xs text-[#5C3D4E]">
                  Configure trusted contacts, local emergency numbers, and your Supabase account.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowSettings(false)}
                className="min-h-[44px] rounded-2xl border border-pink-200 bg-[#FFF5F8] px-5 py-2 text-xs font-bold text-[#9D174D] transition hover:bg-pink-100"
              >
                Done
              </button>
            </div>

            <div className="grid gap-5 lg:grid-cols-2">
              <div className="space-y-5">
                {/* Supabase Connection Card */}
                <div className="rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <Database className="h-5 w-5 shrink-0 text-[#E11D74]" />
                      <div>
                        <h2 className="text-sm font-bold text-[#24101B]">
                          Supabase Backend
                        </h2>
                        <p className="text-xs text-[#5C3D4E]">
                          {supabaseConfigured
                            ? `Connected (${getStoredSupabaseConfig().source === 'env' ? '.env' : 'browser config'})`
                            : 'Not configured yet'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowSetupModal(true)}
                      className="min-h-[44px] rounded-2xl bg-pink-50 px-4 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                    >
                      {supabaseConfigured ? 'Manage' : 'Connect'}
                    </button>
                  </div>
                </div>

                {/* Supabase Authentication Card */}
                <div className="rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                  <div className="flex items-center gap-2">
                    <UserCheck className="h-5 w-5 text-[#E11D74]" />
                    <h2 className="text-base font-bold text-[#24101B]">
                      Account &amp; Cloud Sync
                    </h2>
                  </div>

                  {!supabaseConfigured ? (
                    <p className="mt-2 text-xs leading-relaxed text-[#5C3D4E]">
                      Connect Supabase first to sign in and securely sync your private contacts and emergency numbers across devices.
                    </p>
                  ) : user ? (
                    <div className="mt-3 space-y-3">
                      <div className="rounded-2xl bg-[#FFF5F8] p-3.5 text-xs">
                        <p className="font-semibold text-[#24101B]">
                          Signed in as:
                        </p>
                        <p className="mt-0.5 font-mono text-[#9D174D]">
                          {user.email}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={handleSignOut}
                        disabled={authLoading}
                        className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-2xl border border-pink-200 bg-white px-4 py-2 text-sm font-bold text-[#9D174D] hover:bg-pink-50 disabled:opacity-50"
                      >
                        {authLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <LogOut className="h-4 w-4" />
                        )}
                        Sign Out
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleAuthSubmit} className="mt-3 space-y-3">
                      <div className="flex rounded-2xl bg-[#FFF5F8] p-1 text-xs font-bold">
                        <button
                          type="button"
                          disabled={authLoading}
                          onClick={() => {
                            setAuthMode('signin');
                            setAuthFeedback(null);
                          }}
                          className={`min-h-[40px] flex-1 rounded-xl py-2 disabled:opacity-60 ${
                            authMode === 'signin'
                              ? 'bg-white text-[#9D174D] shadow-sm'
                              : 'text-[#5C3D4E]'
                          }`}
                        >
                          Sign In
                        </button>
                        <button
                          type="button"
                          disabled={authLoading}
                          onClick={() => {
                            setAuthMode('signup');
                            setAuthFeedback(null);
                          }}
                          className={`min-h-[40px] flex-1 rounded-xl py-2 disabled:opacity-60 ${
                            authMode === 'signup'
                              ? 'bg-white text-[#9D174D] shadow-sm'
                              : 'text-[#5C3D4E]'
                          }`}
                        >
                          Create Account
                        </button>
                      </div>

                      <input
                        type="email"
                        required
                        disabled={authLoading}
                        aria-label="Account email address"
                        placeholder="Email address"
                        value={authEmail}
                        onChange={(e) => setAuthEmail(e.target.value)}
                        className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74] disabled:bg-pink-50/40"
                      />
                      <input
                        type="password"
                        required
                        minLength={6}
                        disabled={authLoading}
                        aria-label="Account password"
                        placeholder="Password (min 6 characters)"
                        value={authPassword}
                        onChange={(e) => setAuthPassword(e.target.value)}
                        className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74] disabled:bg-pink-50/40"
                      />
                      <button
                        type="submit"
                        disabled={
                          authLoading ||
                          (authMode === 'signup' &&
                            globalRateLimitRemainingSec > 0)
                        }
                        className="btn-rose-glow flex min-h-[46px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
                      >
                        {authLoading ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <LogIn className="h-4 w-4" />
                        )}
                        {authLoading
                          ? authMode === 'signin'
                            ? 'Signing In...'
                            : 'Creating Account...'
                          : authMode === 'signup' &&
                              globalRateLimitRemainingSec > 0
                            ? `Rate limit active (${formatCooldownDuration(
                                globalRateLimitRemainingSec
                              )})`
                            : authMode === 'signin'
                              ? 'Sign In'
                              : 'Create Account'}
                      </button>

                      {pendingVerificationEmail && (
                        <div className="space-y-2 rounded-2xl border border-pink-200 bg-[#FFF5F8] p-3 text-xs text-[#3E1F30]">
                          <p className="font-bold text-[#9D174D]">
                            Email verification pending for{' '}
                            <span className="font-mono">
                              {pendingVerificationEmail}
                            </span>
                          </p>
                          <p className="leading-relaxed text-[#5C3D4E]">
                            Open the verification link in your inbox or spam folder, then use Sign In. SafeHer prevents repeated verification emails to avoid rate limits.
                          </p>
                          <div className="flex flex-wrap items-center gap-2">
                            {!resendAlreadyUsedForPending &&
                              globalRateLimitRemainingSec === 0 && (
                                <button
                                  type="button"
                                  disabled={
                                    authLoading ||
                                    verificationCooldownRemainingSec > 0
                                  }
                                  onClick={handleResendVerification}
                                  className="min-h-[38px] rounded-xl border border-pink-200 bg-white px-3 py-1.5 font-bold text-[#9D174D] hover:bg-pink-50 disabled:opacity-50"
                                >
                                  {verificationCooldownRemainingSec > 0
                                    ? `Resend available in ${formatCooldownDuration(
                                        verificationCooldownRemainingSec
                                      )}`
                                    : 'Resend Verification Email (Once)'}
                                </button>
                              )}
                            {resendAlreadyUsedForPending && (
                              <span className="text-[11px] font-semibold text-[#5C3D4E]">
                                Verification email already resent once. Check inbox &amp; spam.
                              </span>
                            )}
                            {authMode === 'signup' && (
                              <button
                                type="button"
                                disabled={authLoading}
                                onClick={() => {
                                  setAuthMode('signin');
                                  setAuthEmail(pendingVerificationEmail);
                                  setAuthFeedback(null);
                                }}
                                className="min-h-[38px] rounded-xl bg-white px-3 py-1.5 font-bold text-[#24101B] hover:bg-pink-50"
                              >
                                Switch to Sign In
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </form>
                  )}

                  {authFeedback && (
                    <div className="mt-3">
                      <FeedbackBanner
                        feedback={authFeedback}
                        onDismiss={() => setAuthFeedback(null)}
                      />
                    </div>
                  )}
                </div>

                {/* Emergency Speed Dial Numbers */}
                <form
                  onSubmit={handleSaveEmergencyNumbers}
                  className="space-y-3 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft"
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <PhoneCall className="h-5 w-5 text-[#E11D74]" />
                      <h2 className="text-base font-bold text-[#24101B]">
                        Speed Dial Numbers
                      </h2>
                    </div>
                    <span className="text-xs font-medium text-[#9D174D]">
                      {storageModeLabel}
                    </span>
                  </div>

                  <p className="text-xs leading-relaxed text-[#5C3D4E]">
                    SafeHer never guesses or hardcodes emergency numbers. Enter your verified local Police and Ambulance numbers below.
                  </p>

                  <div>
                    <label
                      htmlFor="settings-police-number"
                      className="mb-1 block text-xs font-semibold text-[#24101B]"
                    >
                      Police Number
                    </label>
                    <input
                      id="settings-police-number"
                      type="tel"
                      placeholder="Enter local police number"
                      value={policeNumber}
                      onChange={(e) => setPoliceNumber(e.target.value)}
                      className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="settings-ambulance-number"
                      className="mb-1 block text-xs font-semibold text-[#24101B]"
                    >
                      Ambulance Number
                    </label>
                    <input
                      id="settings-ambulance-number"
                      type="tel"
                      placeholder="Enter local ambulance number"
                      value={ambulanceNumber}
                      onChange={(e) => setAmbulanceNumber(e.target.value)}
                      className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                    />
                  </div>

                  {settingsFeedback && (
                    <FeedbackBanner
                      feedback={settingsFeedback}
                      onDismiss={() => setSettingsFeedback(null)}
                    />
                  )}

                  <label className="flex cursor-pointer items-start gap-2.5 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-3 text-xs leading-relaxed text-[#3E1F30]">
                    <input
                      type="checkbox"
                      checked={saveProfileConsent}
                      onChange={(e) =>
                        void handleUpdateJourneyConsents({
                          profile: e.target.checked,
                        })
                      }
                      className="mt-0.5 h-5 w-5 shrink-0 accent-[#E11D74]"
                    />
                    <span>
                      I agree to let SafeHer store my personal safety numbers privately.
                    </span>
                  </label>

                  <button
                    type="submit"
                    disabled={settingsLoading}
                    className="btn-rose-glow flex min-h-[46px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
                  >
                    {settingsLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      'Save Emergency Numbers'
                    )}
                  </button>
                </form>
              </div>

              <div className="space-y-5">
                {renderTrustedContactsCard()}

                {/* Privacy Notice & Delete My Data */}
                <div className="space-y-3 rounded-3xl border border-pink-200 bg-white p-5 shadow-soft">
                  <div className="flex items-center gap-2">
                    <Lock className="h-5 w-5 text-[#E11D74]" />
                    <h2 className="text-base font-bold text-[#24101B]">
                      Privacy &amp; Data Controls
                    </h2>
                  </div>
                  <p className="text-xs leading-relaxed text-[#3E1F30]">
                    <strong>When location is requested:</strong> SafeHer never requests your GPS location on page load. Browser location permission is requested only when you tap SOS, tap “My Location” on the Crowd Map, attach coordinates to an alert, or tap “Share my location”.
                  </p>
                  <p className="text-xs leading-relaxed text-[#3E1F30]">
                    <strong>What gets shared:</strong> Trusted contacts and emergency numbers remain private to your account (or browser) and are never included in community Crowd Map reports or Safety Alerts.
                  </p>

                  {!confirmDeleteData ? (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteData(true)}
                      className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-2 text-sm font-bold text-red-700 hover:bg-red-100"
                    >
                      <Trash2 className="h-4 w-4" /> Delete My Data
                    </button>
                  ) : (
                    <div className="space-y-2.5 rounded-2xl border border-red-300 bg-red-50 p-3.5">
                      <p className="text-xs font-bold text-red-900">
                        Confirm permanent deletion:
                      </p>
                      <p className="text-xs leading-relaxed text-red-800">
                        This deletes all your saved contacts, emergency numbers, community crowd reports, safety alerts, and read receipts from Supabase (if signed in) and clears local browser storage.
                      </p>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          disabled={deleteDataLoading}
                          onClick={handleDeleteAllMyData}
                          className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-red-600 px-3 py-2 text-xs font-bold text-white hover:bg-red-700 disabled:opacity-50"
                        >
                          {deleteDataLoading && (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          )}
                          Yes, Delete Everything
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteData(false)}
                          className="min-h-[44px] rounded-xl bg-white px-4 py-2 text-xs font-bold text-[#24101B]"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>
        ) : activeSection === 'home' ? (
          /* ==================== 1. HOME / INTRO ==================== */
          <section className="view-enter space-y-6">
            <div className="grid gap-5 lg:grid-cols-12 lg:items-stretch">
              <div className="relative flex flex-col justify-between overflow-hidden rounded-3xl bg-gradient-to-br from-[#FFDCEB] via-[#FFF6FA] to-white p-6 shadow-soft ring-1 ring-pink-200/80 sm:p-8 lg:col-span-7">
                <div
                  aria-hidden="true"
                  className="hero-aurora-glow pointer-events-none absolute -right-16 -top-16 h-72 w-72 rounded-full blur-2xl"
                />
                <div
                  aria-hidden="true"
                  className="hero-bokeh-1 pointer-events-none absolute left-10 top-8 h-14 w-14 rounded-full bg-pink-300/25 blur-md"
                />
                <div
                  aria-hidden="true"
                  className="hero-bokeh-2 pointer-events-none absolute bottom-20 right-16 h-20 w-20 rounded-full bg-[#FB4F9B]/15 blur-lg"
                />
                <div
                  aria-hidden="true"
                  className="hero-bokeh-3 pointer-events-none absolute left-1/2 top-1/3 h-10 w-10 rounded-full bg-rose-300/30 blur-md"
                />
                <div
                  aria-hidden="true"
                  className="hero-heart-float pointer-events-none absolute right-6 top-6 hidden text-pink-200/75 sm:block"
                >
                  <Heart className="h-24 w-24 stroke-[1.25]" />
                </div>

                <div className="relative">
                  <p className="text-xs font-bold tracking-wide text-[#9D174D]">
                    Everyday Women’s Safety Companion
                  </p>
                  <h1 className="mt-2.5 max-w-xl text-balance text-3xl font-extrabold tracking-tight text-[#24101B] sm:text-4xl">
                    SafeHer — thoughtful safety tools, ready in one tap
                  </h1>
                  <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#3E1F30] sm:text-base">
                    Quick tools to reach the people you trust — fast, simple, and on your terms.
                  </p>

                  <div className="mt-5 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => openModule('sos')}
                      className="btn-rose-glow inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-6 py-3 text-sm font-bold text-white hover:bg-[#9D174D]"
                    >
                      <span>Get Started</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowSettings(true)}
                      className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl border border-pink-200 bg-white/95 px-5 py-3 text-sm font-bold text-[#24101B] transition hover:border-pink-300 hover:bg-pink-50"
                    >
                      <Settings className="h-4 w-4 text-[#E11D74]" />
                      <span>Setup Contacts &amp; Numbers</span>
                    </button>
                  </div>
                </div>

                <div className="relative mt-6 space-y-3">
                  {!supabaseConfigured && (
                    <div className="flex flex-wrap items-center justify-between gap-2.5 rounded-2xl border border-amber-300 bg-amber-50/95 px-4 py-3 text-xs text-amber-950">
                      <span>
                        <strong>Cloud features paused:</strong> Connect Supabase to enable sign-in, shared Crowd Map, and Safety Alerts.
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowSetupModal(true)}
                        className="min-h-[40px] shrink-0 rounded-xl bg-amber-900 px-3.5 py-2 font-bold text-white transition hover:bg-amber-950"
                      >
                        Setup Supabase
                      </button>
                    </div>
                  )}

                  <div className="flex items-start gap-2.5 rounded-2xl border border-pink-200/80 bg-white/90 p-3.5 text-xs leading-relaxed text-[#5C3D4E]">
                    <Info className="mt-0.5 h-4 w-4 shrink-0 text-[#9D174D]" />
                    <p>
                      <strong className="text-[#9D174D]">Important notice:</strong>{' '}
                      SafeHer helps you access safety tools faster, but{' '}
                      <strong>does not guarantee safety</strong>. In an immediate emergency, contact local authorities directly.
                    </p>
                  </div>
                </div>
              </div>

              {/* Prominent Home SOS Card with Tasteful Pink Glow */}
              <div className="bg-blush-mesh relative flex flex-col items-center justify-between overflow-hidden rounded-3xl border border-pink-100 p-7 text-center shadow-soft lg:col-span-5">
                <div
                  aria-hidden="true"
                  className="sos-stage-aura pointer-events-none absolute left-1/2 top-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full blur-xl"
                />
                <div className="relative w-full text-center">
                  <p className="text-xs font-bold tracking-wide text-[#9D174D]">
                    Instant Emergency SOS
                  </p>
                  <p className="mt-0.5 text-xs text-[#5C3D4E]">
                    Activates &amp; opens SMS immediately — offline ready
                  </p>
                </div>

                <div className="sos-glow-stage my-6">
                  <span aria-hidden="true" className="sos-ripple-ring" />
                  <button
                    type="button"
                    onClick={triggerInstantSos}
                    aria-label="Activate SOS and send emergency SMS immediately"
                    className="flex h-40 w-40 flex-col items-center justify-center rounded-full bg-gradient-to-br from-[#FF4D9D] via-[#E11D74] to-[#BE185D] text-white shadow-sos"
                  >
                    <AlertTriangle className="sos-icon-float h-9 w-9 drop-shadow-sm" />
                    <span className="mt-1 text-2xl font-black tracking-wider">
                      SOS
                    </span>
                    <span className="text-[11px] font-semibold opacity-95">
                      Tap for Instant SOS
                    </span>
                  </button>
                </div>

                <div className="relative w-full space-y-2 rounded-2xl border border-pink-100 bg-white/90 p-3.5 text-xs text-[#5C3D4E]">
                  {sosState ? (
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span
                        className={`inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1 text-[11px] font-extrabold ${
                          sosState.status === 'failed'
                            ? 'bg-red-100 text-red-800'
                            : sosState.status === 'sent'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-pink-100 text-[#9D174D]'
                        }`}
                      >
                        {getSosStatusLabel(sosState.status)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setSosModalOpen(true)}
                        className="font-bold text-[#E11D74] hover:underline"
                      >
                        View SOS Status
                      </button>
                    </div>
                  ) : (
                    <p className="leading-relaxed">
                      Triggers SOS immediately with your last known location while GPS &amp; alerts update in the background.
                    </p>
                  )}
                  <p className="font-semibold text-[#9D174D] tabular-nums">
                    {contacts.length > 0
                      ? `${sosSelectedIds.length} of ${contacts.length} trusted contact${contacts.length === 1 ? '' : 's'} ready`
                      : 'No trusted contacts saved yet'}
                  </p>
                </div>
              </div>
            </div>

            {/* Five Safety Feature Cards */}
            <div className="space-y-3.5">
              <div className="flex flex-wrap items-center justify-between gap-2 px-1">
                <h2 className="text-base font-extrabold tracking-tight text-[#24101B]">
                  Safety Modules
                </h2>
                <button
                  type="button"
                  onClick={() => openModule('sos')}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl px-3 text-xs font-bold text-[#E11D74] transition hover:bg-pink-50"
                >
                  <span>Open Workspace</span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              <div className="grid gap-3.5 md:grid-cols-6">
                {[
                  {
                    id: 'sos' as ModuleId,
                    spanClass: 'md:col-span-3',
                    title: 'SOS Alert',
                    desc: 'Prepare an emergency SMS with your map link.',
                    icon: AlertTriangle,
                    meta: `${contacts.length} contact${contacts.length === 1 ? '' : 's'} saved`,
                  },
                  {
                    id: 'crowd' as ModuleId,
                    spanClass: 'md:col-span-3',
                    title: 'Crowd Map',
                    desc: 'View and post crowd activity pins on OpenStreetMap.',
                    icon: MapPin,
                    meta: supabaseConfigured
                      ? `${crowdReports.length} reports`
                      : 'Setup Supabase to share',
                  },
                  {
                    id: 'alerts' as ModuleId,
                    spanClass: 'md:col-span-2',
                    title: 'Safety Alerts',
                    desc: 'Read and share local community notices.',
                    icon: Bell,
                    meta:
                      unreadCount > 0
                        ? `${unreadCount} unread`
                        : 'Community feed',
                  },
                  {
                    id: 'share' as ModuleId,
                    spanClass: 'md:col-span-2',
                    title: 'Live Location Share',
                    desc: 'Send your map link with an active session timer.',
                    icon: Share2,
                    meta: activeShareSession ? 'Session active' : 'On demand',
                  },
                  {
                    id: 'dial' as ModuleId,
                    spanClass: 'md:col-span-2',
                    title: 'Speed Dial',
                    desc: 'Confirm and dial your Police or Ambulance number.',
                    icon: PhoneCall,
                    meta:
                      policeNumber || ambulanceNumber
                        ? 'Configured'
                        : 'Set in Settings',
                  },
                ].map((mod) => {
                  const Icon = mod.icon;
                  return (
                    <button
                      key={mod.id}
                      type="button"
                      onClick={() => openModule(mod.id)}
                      className={`card-interactive group flex min-h-[104px] w-full items-start justify-between gap-3.5 rounded-3xl border border-pink-100 bg-white/95 p-5 text-left ${mod.spanClass}`}
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74] shadow-[0_4px_12px_-4px_rgba(225,29,116,0.28)] transition-transform duration-200 group-hover:scale-105">
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-[#9D174D]">
                            {mod.meta}
                          </p>
                          <h3 className="mt-0.5 text-sm font-extrabold text-[#24101B]">
                            {mod.title}
                          </h3>
                          <p className="mt-1 text-xs leading-relaxed text-[#5C3D4E]">
                            {mod.desc}
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="mt-1 h-5 w-5 shrink-0 text-pink-400 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:text-[#E11D74]" />
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        ) : activeSection === 'modules' ? (
          /* ==================== 2. MODULES WORKSPACE ==================== */
          <section className="view-enter space-y-5">
            {/* Module Switcher Controls */}
            <div
              role="tablist"
              aria-label="Safety modules"
              className="flex gap-2 overflow-x-auto rounded-3xl border border-pink-100 bg-white/90 p-2 shadow-soft"
            >
              {MODULE_TABS.map((tab) => {
                const Icon = tab.icon;
                const active = activeModule === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setActiveModule(tab.id)}
                    className={`flex min-h-[44px] flex-1 shrink-0 items-center justify-center gap-1.5 rounded-2xl px-4 py-2 text-xs font-bold whitespace-nowrap transition ${
                      active
                        ? 'btn-rose-glow bg-[#E11D74] text-white'
                        : 'text-[#5C3D4E] hover:bg-[#FFF5F8] hover:text-[#24101B]'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* ---------- MODULE 1: SOS ---------- */}
            {activeModule === 'sos' && (
              <div className="view-enter mx-auto max-w-2xl space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <AlertTriangle className="h-6 w-6" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#24101B]">
                        Instant SOS Alert
                      </h1>
                      <p className="mt-1 max-w-md text-xs leading-relaxed text-[#5C3D4E]">
                        One tap activates SOS and opens emergency SMS right away. GPS and logs run in the background.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={triggerInstantSos}
                    className="btn-rose-glow flex min-h-[46px] shrink-0 items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D]"
                  >
                    <AlertTriangle className="h-4 w-4" />
                    <span>Trigger SOS Now</span>
                  </button>
                </div>

                {sosState && (
                  <div
                    role="status"
                    className={`flex flex-wrap items-center justify-between gap-3 rounded-3xl border p-4 text-xs shadow-soft ${
                      sosState.status === 'failed'
                        ? 'border-red-200 bg-red-50 text-red-950'
                        : sosState.status === 'sent'
                          ? 'border-emerald-200 bg-emerald-50 text-emerald-950'
                          : 'border-pink-200 bg-[#FFF5F8] text-[#24101B]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {sosState.status === 'failed' ? (
                        <XCircle className="h-5 w-5 shrink-0 text-red-600" />
                      ) : sosState.status === 'sent' ? (
                        <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
                      ) : (
                        <Loader2 className="h-5 w-5 shrink-0 animate-spin text-[#E11D74]" />
                      )}
                      <div>
                        <p className="font-extrabold">
                          Status: {getSosStatusLabel(sosState.status)}
                        </p>
                        <p className="mt-0.5 text-[11px] opacity-90">
                          {sosState.locationSource === 'fresh'
                            ? 'Fresh GPS coordinates attached.'
                            : sosState.locationSource === 'cached'
                              ? 'Last known location attached; refining GPS in background.'
                              : sosState.locatingInBackground
                                ? 'SMS opened immediately; checking GPS in background.'
                                : 'Emergency SMS ready without coordinates.'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {sosState.status === 'failed' && (
                        <button
                          type="button"
                          onClick={handleRetrySosSms}
                          className="min-h-[38px] rounded-xl bg-red-600 px-3.5 py-1.5 font-bold text-white hover:bg-red-700"
                        >
                          Retry SMS
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setSosModalOpen(true)}
                        className="min-h-[38px] rounded-xl border border-pink-200 bg-white px-3.5 py-1.5 font-bold text-[#9D174D] hover:bg-pink-50"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                )}

                <div className="bg-blush-mesh rounded-3xl border border-pink-100 p-6 text-center shadow-soft sm:p-8">
                  <div className="my-4 flex justify-center">
                    <div className="sos-glow-stage">
                      <span aria-hidden="true" className="sos-ripple-ring" />
                      <button
                        type="button"
                        onClick={triggerInstantSos}
                        aria-label="Trigger SOS alert and open emergency SMS immediately"
                        className="flex h-44 w-44 flex-col items-center justify-center rounded-full bg-gradient-to-br from-[#FF4D9D] via-[#E11D74] to-[#BE185D] text-white shadow-sos"
                      >
                        <AlertTriangle className="sos-icon-float h-10 w-10 drop-shadow-sm" />
                        <span className="mt-1.5 text-2xl font-black tracking-wider">
                          SOS
                        </span>
                        <span className="mt-0.5 text-[11px] font-semibold opacity-95">
                          Instant Send
                        </span>
                      </button>
                    </div>
                  </div>

                  <div className="mt-6 grid gap-2.5 text-left sm:grid-cols-3">
                    {[
                      {
                        step: '1. Instant Trigger',
                        text: 'No wait screens — opens SMS right away.',
                      },
                      {
                        step: '2. Smart Location',
                        text: 'Uses last known GPS immediately, refines async.',
                      },
                      {
                        step: '3. Offline Ready',
                        text: 'Works via device SMS without internet.',
                      },
                    ].map((s) => (
                      <div
                        key={s.step}
                        className="rounded-2xl border border-pink-100 bg-white/90 p-3.5 text-xs"
                      >
                        <p className="font-bold text-[#9D174D]">{s.step}</p>
                        <p className="mt-1 leading-relaxed text-[#5C3D4E]">
                          {s.text}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 rounded-2xl border border-pink-100 bg-white p-4 text-left text-xs text-[#3E1F30]">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold text-[#9D174D]">
                        Trusted recipients ({sosSelectedIds.length}/{contacts.length} selected)
                      </p>
                      <button
                        type="button"
                        onClick={() => setShowSettings(true)}
                        className="min-h-[36px] rounded-xl bg-[#FFF5F8] px-3 py-1.5 font-bold text-[#9D174D] hover:bg-pink-100"
                      >
                        {contacts.length === 0 ? 'Add Contacts' : 'Manage'}
                      </button>
                    </div>
                    {contacts.length === 0 ? (
                      <p className="mt-1.5 leading-relaxed text-[#5C3D4E]">
                        No contacts saved yet. Add them in Settings or choose recipients in your SMS app.
                      </p>
                    ) : (
                      <div className="mt-2.5 flex flex-wrap gap-2">
                        {contacts.map((c) => {
                          const checked = sosSelectedIds.includes(c.id);
                          return (
                            <label
                              key={c.id}
                              className={`flex min-h-[38px] cursor-pointer items-center gap-2 rounded-xl border px-3 py-1.5 text-xs transition ${
                                checked
                                  ? 'border-pink-300 bg-[#FFF5F8] text-[#24101B]'
                                  : 'border-pink-100 bg-white text-[#5C3D4E] opacity-75'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => toggleSosContact(c.id)}
                                className="h-4 w-4 accent-[#E11D74]"
                              />
                              <span className="font-bold">{c.name}</span>
                              <span className="font-mono text-[11px] opacity-80">
                                {c.phone}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ---------- MODULE 2: CROWD MAP ---------- */}
            {activeModule === 'crowd' && (
              <div className="view-enter space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <MapPin className="h-6 w-6" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#24101B]">
                        Community Crowd Map
                      </h1>
                      <p className="mt-1 max-w-xl text-xs leading-relaxed text-[#5C3D4E]">
                        View and share crowd activity pins. GPS is only requested on tap.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={handleFindMyLocationOnMap}
                    className="btn-rose-glow flex min-h-[46px] shrink-0 items-center gap-2 rounded-2xl bg-[#E11D74] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#9D174D]"
                  >
                    <Navigation className="h-4 w-4" />
                    <span>My Location</span>
                  </button>
                </div>

                <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
                  <div className="space-y-5 lg:col-span-7">
                    <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                      {/* Clear Low / Medium / High Legend */}
                      <div className="grid gap-2 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-3.5 text-xs sm:grid-cols-3">
                        <div className="flex items-start gap-2">
                          <span className="mt-1 h-3 w-3 shrink-0 rounded-full bg-emerald-600" />
                          <div>
                            <p className="font-bold text-emerald-800">
                              Low Crowd
                            </p>
                            <p className="text-[11px] text-[#5C3D4E]">
                              Quiet street or few people around
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="mt-1 h-3 w-3 shrink-0 rounded-full bg-amber-600" />
                          <div>
                            <p className="font-bold text-amber-800">
                              Medium Crowd
                            </p>
                            <p className="text-[11px] text-[#5C3D4E]">
                              Moderate steady foot traffic
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <span className="mt-1 h-3 w-3 shrink-0 rounded-full bg-[#E11D74]" />
                          <div>
                            <p className="font-bold text-[#9D174D]">
                              High Crowd
                            </p>
                            <p className="text-[11px] text-[#5C3D4E]">
                              Busy gathering or crowded transit
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-2xl border border-pink-200/80 bg-white p-3 text-xs leading-relaxed text-[#3E1F30]">
                        <strong>Note:</strong> Reports are{' '}
                        <strong>user-submitted and may be outdated</strong>. SafeHer does not auto-detect crowds, and{' '}
                        <strong>crowd size alone does not mean a place is safe or unsafe</strong>.
                      </div>

                      {!supabaseConfigured && (
                        <div className="space-y-2.5 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-950">
                          <p className="font-bold">
                            Supabase is not connected yet.
                          </p>
                          <p className="leading-relaxed">
                            Community reports cannot be loaded or shared across users until you connect Supabase.
                          </p>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => setShowSetupModal(true)}
                              className="min-h-[44px] rounded-xl bg-amber-900 px-4 py-2 font-bold text-white hover:bg-amber-950"
                            >
                              Open Supabase Setup
                            </button>
                            <button
                              type="button"
                              onClick={() => setShowSampleCrowd((p) => !p)}
                              className="min-h-[44px] rounded-xl border border-amber-300 bg-white px-4 py-2 font-bold text-amber-950 hover:bg-amber-100/50"
                            >
                              {showSampleCrowd
                                ? 'Hide Sample Preview'
                                : 'Preview Sample Report'}
                            </button>
                          </div>
                        </div>
                      )}

                      <CrowdMapView
                        reports={visibleReports}
                        center={mapCenter}
                        userLocation={userMapLocation}
                        pickedLocation={pickedLocation}
                        onPickLocation={(lat, lng) =>
                          setPickedLocation({ lat, lng })
                        }
                        isOnline={isOnline}
                      />

                      {crowdFeedback && (
                        <FeedbackBanner
                          feedback={crowdFeedback}
                          onDismiss={() => setCrowdFeedback(null)}
                        />
                      )}
                    </div>

                    {/* Submit Crowd Report Card */}
                    <form
                      onSubmit={handleSubmitCrowdReport}
                      className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft"
                    >
                      <h2 className="text-base font-extrabold text-[#24101B]">
                        Submit a Crowd Report
                      </h2>

                      {supabaseConfigured && !user && (
                        <div className="flex items-center justify-between gap-2 rounded-2xl bg-[#FFF5F8] p-3.5 text-xs">
                          <span>Sign in to publish or edit reports.</span>
                          <button
                            type="button"
                            onClick={() => setShowSettings(true)}
                            className="min-h-[40px] shrink-0 rounded-xl bg-[#E11D74] px-4 py-2 font-bold text-white"
                          >
                            Sign In
                          </button>
                        </div>
                      )}

                      <div>
                        <label className="mb-1.5 block text-xs font-semibold text-[#24101B]">
                          Crowd Activity Level
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {(['Low', 'Medium', 'High'] as CrowdLevel[]).map(
                            (lvl) => (
                              <button
                                key={lvl}
                                type="button"
                                onClick={() =>
                                  setReportForm((p) => ({ ...p, level: lvl }))
                                }
                                className={`min-h-[44px] rounded-2xl border text-xs font-bold transition ${
                                  reportForm.level === lvl
                                    ? 'border-[#E11D74] bg-[#E11D74] text-white shadow-sm'
                                    : 'border-pink-200 bg-[#FFF5F8] text-[#24101B] hover:bg-pink-100/60'
                                }`}
                              >
                                {lvl}
                              </button>
                            )
                          )}
                        </div>
                      </div>

                      <div className="space-y-2 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-3.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold text-[#24101B]">
                            Location Pin
                          </span>
                          <button
                            type="button"
                            onClick={handleUseMyLocationForReport}
                            className="min-h-[40px] rounded-xl bg-white px-3.5 py-1.5 text-xs font-bold text-[#9D174D] shadow-sm hover:bg-pink-50"
                          >
                            Use My Location
                          </button>
                        </div>
                        <p className="font-mono text-[11px] tabular-nums text-[#5C3D4E]">
                          {pickedLocation
                            ? `Selected: ${pickedLocation.lat.toFixed(5)}, ${pickedLocation.lng.toFixed(5)}`
                            : 'Tap anywhere on the map above or tap “Use My Location”.'}
                        </p>
                      </div>

                      <input
                        type="text"
                        maxLength={120}
                        aria-label="Optional landmark or area name"
                        placeholder="Optional landmark / area name"
                        value={reportForm.locationLabel}
                        onChange={(e) =>
                          setReportForm((p) => ({
                            ...p,
                            locationLabel: e.target.value,
                          }))
                        }
                        className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                      />

                      <textarea
                        rows={2}
                        maxLength={280}
                        aria-label="Optional short crowd report note"
                        placeholder="Optional short note (do not enter phone numbers or private info)"
                        value={reportForm.note}
                        onChange={(e) =>
                          setReportForm((p) => ({ ...p, note: e.target.value }))
                        }
                        className="w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                      />

                      <button
                        type="submit"
                        disabled={reportSubmitting || !supabaseConfigured}
                        className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
                      >
                        {reportSubmitting && (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        )}
                        <span>Submit Crowd Report</span>
                      </button>
                    </form>
                  </div>

                  {/* Filterable Reports List (and Offline/Map Fallback) */}
                  <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft lg:col-span-5">
                    <div className="flex items-center justify-between gap-2">
                      <h2 className="text-base font-extrabold text-[#24101B]">
                        Nearby Reports ({visibleReports.length})
                      </h2>
                      {supabaseConfigured && (
                        <button
                          type="button"
                          onClick={fetchCrowdReports}
                          disabled={crowdLoading}
                          aria-label="Refresh reports"
                          className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#FFF5F8] text-[#9D174D] hover:bg-pink-100"
                        >
                          <RefreshCw
                            className={`h-4 w-4 ${crowdLoading ? 'animate-spin' : ''}`}
                          />
                        </button>
                      )}
                    </div>

                    <div className="flex gap-1.5 rounded-2xl bg-[#FFF5F8] p-1">
                      {(['All', 'Low', 'Medium', 'High'] as const).map((f) => (
                        <button
                          key={f}
                          type="button"
                          onClick={() => setCrowdFilter(f)}
                          className={`min-h-[40px] flex-1 rounded-xl py-2 text-xs font-bold transition ${
                            crowdFilter === f
                              ? 'bg-[#E11D74] text-white shadow-sm'
                              : 'text-[#24101B] hover:bg-white/80'
                          }`}
                        >
                          {f}
                        </button>
                      ))}
                    </div>

                    {crowdLoading ? (
                      <div className="flex items-center justify-center gap-2 rounded-2xl bg-[#FFF5F8] p-6 text-xs text-[#5C3D4E]">
                        <Loader2 className="h-4 w-4 animate-spin text-[#E11D74]" />
                        Loading community reports...
                      </div>
                    ) : visibleReports.length === 0 ? (
                      <p className="rounded-2xl bg-[#FFF5F8] p-5 text-center text-xs leading-relaxed text-[#5C3D4E]">
                        {supabaseConfigured
                          ? 'No reports match this filter yet.'
                          : 'Connect Supabase to view shared community reports.'}
                      </p>
                    ) : (
                      <ul className="space-y-3">
                        {visibleReports.map((r) => {
                          const age = formatRelativeAge(r.created_at);
                          const isOwner =
                            user && r.user_id === user.id && !r.isSample;
                          const isEditing = editingReportId === r.id;

                          return (
                            <li
                              key={r.id}
                              className="rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4"
                            >
                              <div className="flex flex-wrap items-baseline justify-between gap-2 text-xs">
                                <span
                                  className={`inline-flex items-center gap-1.5 font-bold ${
                                    r.level === 'Low'
                                      ? 'text-emerald-700'
                                      : r.level === 'Medium'
                                        ? 'text-amber-700'
                                        : 'text-[#E11D74]'
                                  }`}
                                >
                                  <span
                                    aria-hidden="true"
                                    className={`h-2.5 w-2.5 rounded-full ${
                                      r.level === 'Low'
                                        ? 'bg-emerald-600'
                                        : r.level === 'Medium'
                                          ? 'bg-amber-600'
                                          : 'bg-[#E11D74]'
                                    }`}
                                  />
                                  <span>
                                    {r.level} Crowd
                                    {r.isSample && ' · Sample (Not Live)'}
                                    {age.isOld && ' · Older report'}
                                  </span>
                                </span>
                                <span className="tabular-nums text-[11px] text-[#5C3D4E]">
                                  {age.label}
                                </span>
                              </div>

                              {r.location_label && (
                                <p className="mt-1.5 text-sm font-bold text-[#24101B]">
                                  {r.location_label}
                                </p>
                              )}

                              {!isEditing ? (
                                <>
                                  {r.note && (
                                    <p className="mt-1 text-xs leading-relaxed text-[#3E1F30]">
                                      {r.note}
                                    </p>
                                  )}
                                  <p className="mt-2 font-mono text-[11px] tabular-nums text-[#5C3D4E]">
                                    User-submitted · {Number(r.lat).toFixed(4)},{' '}
                                    {Number(r.lng).toFixed(4)}
                                  </p>
                                </>
                              ) : (
                                <div className="mt-2.5 space-y-2 rounded-2xl border border-pink-100 bg-white p-3">
                                  <div className="grid grid-cols-3 gap-1.5">
                                    {(['Low', 'Medium', 'High'] as CrowdLevel[]).map(
                                      (lvl) => (
                                        <button
                                          key={lvl}
                                          type="button"
                                          onClick={() =>
                                            setEditReportDraft((d) => ({
                                              ...d,
                                              level: lvl,
                                            }))
                                          }
                                          className={`min-h-[40px] rounded-xl py-1.5 text-xs font-bold ${
                                            editReportDraft.level === lvl
                                              ? 'bg-[#E11D74] text-white'
                                              : 'bg-[#FFF5F8] text-[#24101B]'
                                          }`}
                                        >
                                          {lvl}
                                        </button>
                                      )
                                    )}
                                  </div>
                                  <textarea
                                    rows={2}
                                    value={editReportDraft.note}
                                    onChange={(e) =>
                                      setEditReportDraft((d) => ({
                                        ...d,
                                        note: e.target.value,
                                      }))
                                    }
                                    className="w-full rounded-xl border border-pink-200 p-2.5 text-xs"
                                  />
                                  <div className="flex gap-2">
                                    <button
                                      type="button"
                                      onClick={() => handleUpdateCrowdReport(r.id)}
                                      className="min-h-[40px] rounded-xl bg-[#E11D74] px-4 py-1.5 text-xs font-bold text-white"
                                    >
                                      Save
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setEditingReportId(null)}
                                      className="min-h-[40px] rounded-xl bg-pink-50 px-4 py-1.5 text-xs font-bold text-[#24101B]"
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                </div>
                              )}

                              {isOwner && !isEditing && (
                                <div className="mt-3 flex gap-2">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setEditingReportId(r.id);
                                      setEditReportDraft({
                                        level: r.level,
                                        note: r.note || '',
                                      });
                                    }}
                                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-pink-100 bg-white px-3.5 py-1.5 text-xs font-bold text-[#24101B] shadow-sm hover:bg-pink-50"
                                  >
                                    <Pencil className="h-3.5 w-3.5" /> Edit
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteCrowdReport(r.id)}
                                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-red-100 bg-white px-3.5 py-1.5 text-xs font-bold text-red-600 shadow-sm hover:bg-red-50"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" /> Delete
                                  </button>
                                </div>
                              )}
                            </li>
                          );
                        })}
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ---------- MODULE 3: SAFETY ALERTS ---------- */}
            {activeModule === 'alerts' && (
              <div className="view-enter space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <Bell className="h-6 w-6" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#24101B]">
                        Safety Alerts
                      </h1>
                      <p className="mt-1 max-w-xl text-xs leading-relaxed text-[#5C3D4E]">
                        Community notices alongside recent crowd check-ins.
                      </p>
                    </div>
                  </div>
                  {supabaseConfigured && (
                    <button
                      type="button"
                      onClick={fetchSafetyAlerts}
                      disabled={alertsLoading}
                      className="inline-flex min-h-[46px] shrink-0 items-center gap-2 rounded-2xl border border-pink-200 bg-[#FFF5F8] px-4 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                    >
                      <RefreshCw
                        className={`h-4 w-4 ${alertsLoading ? 'animate-spin' : ''}`}
                      />
                      <span>Refresh Feed</span>
                    </button>
                  )}
                </div>

                <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
                  <div className="space-y-4 lg:col-span-5">
                    <div className="rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                      <div className="rounded-2xl border border-pink-200/80 bg-[#FFF5F8] p-3.5 text-xs leading-relaxed text-[#3E1F30]">
                        <strong className="text-[#9D174D]">
                          Community alerts only:
                        </strong>{' '}
                        Written by SafeHer users —{' '}
                        <strong>not connected</strong> to official police or government feeds.
                      </div>

                      {!supabaseConfigured && (
                        <div className="mt-3 space-y-2.5 rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-950">
                          <p className="font-bold">
                            Supabase is required for shared Safety Alerts.
                          </p>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => setShowSetupModal(true)}
                              className="min-h-[44px] rounded-xl bg-amber-900 px-4 py-2 font-bold text-white"
                            >
                              Connect Supabase
                            </button>
                            <button
                              type="button"
                              onClick={() => setShowSampleAlerts((p) => !p)}
                              className="min-h-[44px] rounded-xl border border-amber-300 bg-white px-4 py-2 font-bold text-amber-950"
                            >
                              {showSampleAlerts
                                ? 'Hide Sample Alert'
                                : 'Preview Sample Alert'}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Create User Alert Form */}
                    <form
                      onSubmit={handleCreateAlert}
                      className="space-y-3 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft"
                    >
                      <h2 className="text-base font-extrabold text-[#24101B]">
                        Post a Community Alert
                      </h2>

                      {supabaseConfigured && !user && (
                        <div className="flex items-center justify-between gap-2 rounded-2xl bg-[#FFF5F8] p-3.5 text-xs">
                          <span>Sign in to publish alerts.</span>
                          <button
                            type="button"
                            onClick={() => setShowSettings(true)}
                            className="min-h-[40px] rounded-xl bg-[#E11D74] px-4 py-2 font-bold text-white"
                          >
                            Sign In
                          </button>
                        </div>
                      )}

                      <input
                        type="text"
                        maxLength={100}
                        aria-label="Alert title"
                        placeholder="Alert title (e.g., Dark walkway near Gate 2)"
                        value={alertForm.title}
                        onChange={(e) =>
                          setAlertForm((p) => ({ ...p, title: e.target.value }))
                        }
                        className="min-h-[44px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                      />

                      <textarea
                        rows={3}
                        maxLength={500}
                        aria-label="Alert description"
                        placeholder="Describe what others nearby should be aware of..."
                        value={alertForm.message}
                        onChange={(e) =>
                          setAlertForm((p) => ({
                            ...p,
                            message: e.target.value,
                          }))
                        }
                        className="w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                      />

                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={140}
                          aria-label="Optional location or street name"
                          placeholder="Optional location / street name"
                          value={alertForm.locationText}
                          onChange={(e) =>
                            setAlertForm((p) => ({
                              ...p,
                              locationText: e.target.value,
                            }))
                          }
                          className="min-h-[44px] flex-1 rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                        />
                        <button
                          type="button"
                          onClick={handleAttachLocationToAlert}
                          className="min-h-[44px] shrink-0 rounded-2xl border border-pink-200 bg-[#FFF5F8] px-4 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                        >
                          + GPS
                        </button>
                      </div>

                      {alertsFeedback && (
                        <FeedbackBanner
                          feedback={alertsFeedback}
                          onDismiss={() => setAlertsFeedback(null)}
                        />
                      )}

                      <button
                        type="submit"
                        disabled={alertSubmitting || !supabaseConfigured}
                        className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
                      >
                        {alertSubmitting && (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        )}
                        <span>Publish User Alert</span>
                      </button>
                    </form>
                  </div>

                  <div className="space-y-4 lg:col-span-7">
                    {/* User-Created Alerts List */}
                    <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                      <div className="flex items-center justify-between gap-2">
                        <h2 className="text-base font-extrabold text-[#24101B]">
                          Community Notifications ({visibleAlerts.length})
                        </h2>
                        <span className="tabular-nums text-xs font-semibold text-[#9D174D]">
                          {unreadCount} unread
                        </span>
                      </div>

                      {alertsLoading ? (
                        <div className="flex items-center justify-center gap-2 rounded-2xl bg-[#FFF5F8] p-6 text-xs text-[#5C3D4E]">
                          <Loader2 className="h-4 w-4 animate-spin text-[#E11D74]" />
                          Loading alerts...
                        </div>
                      ) : visibleAlerts.length === 0 ? (
                        <p className="rounded-2xl bg-[#FFF5F8] p-5 text-center text-xs leading-relaxed text-[#5C3D4E]">
                          {supabaseConfigured
                            ? 'No user safety alerts posted yet.'
                            : 'Connect Supabase to load and post real alerts.'}
                        </p>
                      ) : (
                        <ul className="space-y-3">
                          {visibleAlerts.map((a) => {
                            const isRead = readAlertIds.includes(a.id);
                            const isOwner =
                              user && a.user_id === user.id && !a.isSample;
                            const age = formatRelativeAge(a.created_at);

                            return (
                              <li
                                key={a.id}
                                className={`rounded-2xl border p-4 transition ${
                                  isRead
                                    ? 'border-pink-100 bg-white/80 opacity-85'
                                    : 'border-pink-200 bg-[#FFF5F8]'
                                }`}
                              >
                                <div className="flex flex-wrap items-baseline justify-between gap-2 text-xs">
                                  <span
                                    className={`font-bold ${
                                      a.isSample
                                        ? 'text-amber-800'
                                        : 'text-[#9D174D]'
                                    }`}
                                  >
                                    {a.isSample
                                      ? 'Sample — Not Live'
                                      : 'User-Created Alert (Not Official)'}
                                    {isRead ? ' · Read' : ' · Unread'}
                                  </span>
                                  <span className="tabular-nums text-[11px] text-[#5C3D4E]">
                                    {age.label}
                                  </span>
                                </div>

                                <h3 className="mt-1.5 text-sm font-extrabold text-[#24101B]">
                                  {a.title}
                                </h3>
                                <p className="mt-1 text-xs leading-relaxed text-[#3E1F30]">
                                  {a.message}
                                </p>
                                {a.location_text && (
                                  <p className="mt-2 flex items-center gap-1.5 text-xs font-semibold text-[#9D174D]">
                                    <MapPin className="h-3.5 w-3.5 shrink-0" />
                                    <span>{a.location_text}</span>
                                  </p>
                                )}

                                <div className="mt-3.5 flex flex-wrap gap-2">
                                  <button
                                    type="button"
                                    onClick={() => handleToggleReadAlert(a.id)}
                                    className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-bold text-[#24101B] shadow-sm ring-1 ring-pink-100 hover:bg-pink-50"
                                  >
                                    <Check className="h-3.5 w-3.5 text-[#E11D74]" />
                                    {isRead ? 'Mark Unread' : 'Mark as Read'}
                                  </button>

                                  {isOwner && (
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteAlert(a.id)}
                                      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 text-xs font-bold text-red-600 shadow-sm ring-1 ring-red-100 hover:bg-red-50"
                                    >
                                      <Trash2 className="h-3.5 w-3.5" /> Delete
                                    </button>
                                  )}
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    </div>

                    {/* Recent Crowd Reports Summary */}
                    <div className="space-y-3 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                      <div className="flex items-center justify-between gap-2">
                        <h2 className="text-base font-extrabold text-[#24101B]">
                          Recent Crowd Reports
                        </h2>
                        <button
                          type="button"
                          onClick={() => setActiveModule('crowd')}
                          className="min-h-[40px] rounded-xl px-3 text-xs font-bold text-[#E11D74] hover:bg-pink-50"
                        >
                          View Map
                        </button>
                      </div>
                      {crowdReports.length === 0 ? (
                        <p className="rounded-2xl bg-[#FFF5F8] p-4 text-xs text-[#5C3D4E]">
                          No recent crowd reports loaded.
                        </p>
                      ) : (
                        <ul className="space-y-2">
                          {crowdReports.slice(0, 4).map((r) => (
                            <li
                              key={r.id}
                              className="flex items-center justify-between gap-2 rounded-2xl bg-[#FFF5F8] px-3.5 py-3 text-xs"
                            >
                              <div className="min-w-0">
                                <span className="font-bold text-[#9D174D]">
                                  {r.level} Crowd
                                </span>
                                {r.location_label && (
                                  <span className="text-[#3E1F30]">
                                    {' '}
                                    — {r.location_label}
                                  </span>
                                )}
                              </div>
                              <span className="shrink-0 tabular-nums text-[11px] text-[#5C3D4E]">
                                {formatRelativeAge(r.created_at).label}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ---------- MODULE 4: LIVE LOCATION SHARE ---------- */}
            {activeModule === 'share' && (
              <div className="view-enter space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <Share2 className="h-6 w-6" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#24101B]">
                        Live Location Share
                      </h1>
                      <p className="mt-1 max-w-xl text-xs leading-relaxed text-[#5C3D4E]">
                        Send your current map link to a trusted contact with a session timer.
                      </p>
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <p className="font-semibold text-[#5C3D4E]">Status</p>
                    <p className="font-extrabold text-[#9D174D]">
                      {activeShareSession
                        ? `Active · ${Math.floor(shareSecondsLeft / 60)}:${String(shareSecondsLeft % 60).padStart(2, '0')}`
                        : 'Ready when you tap Share'}
                    </p>
                  </div>
                </div>

                <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
                  <div className="space-y-4 lg:col-span-6">
                    <div className="space-y-4 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft">
                      <div className="rounded-2xl border border-pink-200/80 bg-[#FFF5F8] p-3.5 text-xs leading-relaxed text-[#3E1F30]">
                        <strong className="text-[#9D174D]">
                          Browser note:
                        </strong>{' '}
                        Sharing stops if this browser tab is closed. SafeHer sends a map link of your current location and runs the timer while open.
                      </div>

                      {contacts.length === 0 ? (
                        <div className="rounded-2xl bg-pink-50 p-4 text-xs leading-relaxed text-[#24101B]">
                          Add at least one trusted contact on the right (or below on mobile) to start sharing your location.
                        </div>
                      ) : (
                        <>
                          <div>
                            <label
                              htmlFor="share-trusted-contact"
                              className="mb-1.5 block text-xs font-semibold text-[#24101B]"
                            >
                              Choose Trusted Contact
                            </label>
                            <select
                              id="share-trusted-contact"
                              value={shareContactId}
                              onChange={(e) => setShareContactId(e.target.value)}
                              className="min-h-[44px] w-full rounded-2xl border border-pink-200 bg-white px-3.5 py-2.5 text-sm outline-none focus:border-[#E11D74]"
                            >
                              {contacts.map((c) => (
                                <option key={c.id} value={c.id}>
                                  {c.name} ({c.phone})
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="mb-1.5 block text-xs font-semibold text-[#24101B]">
                              Planned Sharing Duration
                            </label>
                            <div className="grid grid-cols-3 gap-2">
                              {[15, 30, 60].map((mins) => (
                                <button
                                  key={mins}
                                  type="button"
                                  onClick={() => setShareDurationMin(mins)}
                                  className={`min-h-[44px] rounded-2xl border text-xs font-bold transition ${
                                    shareDurationMin === mins
                                      ? 'border-[#E11D74] bg-[#E11D74] text-white shadow-sm'
                                      : 'border-pink-200 bg-[#FFF5F8] text-[#24101B] hover:bg-pink-100/60'
                                  }`}
                                >
                                  {mins} min
                                </button>
                              ))}
                            </div>
                          </div>

                          <button
                            type="button"
                            disabled={shareLoading}
                            onClick={handleStartLocationShare}
                            className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-3 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
                          >
                            {shareLoading ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Share2 className="h-4 w-4" />
                            )}
                            <span>Share My Location</span>
                          </button>
                        </>
                      )}

                      {shareFeedback && (
                        <FeedbackBanner
                          feedback={shareFeedback}
                          onDismiss={() => setShareFeedback(null)}
                        />
                      )}
                    </div>

                    {/* Active Session Card */}
                    {activeShareSession && (
                      <div className="space-y-3.5 rounded-3xl border-2 border-[#E11D74] bg-white p-5 shadow-soft">
                        <div className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#9D174D]">
                            <Clock className="h-4 w-4" />
                            In-app sharing session active
                          </span>
                          <span className="font-mono text-base font-extrabold tabular-nums text-[#E11D74]">
                            {Math.floor(shareSecondsLeft / 60)}:
                            {String(shareSecondsLeft % 60).padStart(2, '0')}
                          </span>
                        </div>

                        <p className="text-xs text-[#3E1F30]">
                          Prepared for{' '}
                          <strong>{activeShareSession.contactName}</strong> (
                          <span className="font-mono tabular-nums">
                            {activeShareSession.contactPhone}
                          </span>
                          ).
                        </p>

                        <div className="rounded-2xl border border-pink-100 bg-[#FFF5F8] p-3 font-mono text-[11px] break-all text-[#24101B]">
                          {activeShareSession.mapLink}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <a
                            href={activeShareSession.smsHref}
                            className="btn-rose-glow flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-2xl bg-[#E11D74] px-3 py-2 text-xs font-bold text-white"
                          >
                            <MessageSquare className="h-4 w-4" /> Open Messaging App
                          </a>
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await navigator.clipboard.writeText(
                                  activeShareSession.message
                                );
                                setShareFeedback({
                                  type: 'success',
                                  message:
                                    'Location message copied to clipboard.',
                                });
                              } catch {
                                // Ignore clipboard error
                              }
                            }}
                            className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-2xl border border-pink-200 bg-white px-4 py-2 text-xs font-bold text-[#24101B] hover:bg-pink-50"
                          >
                            <Copy className="h-4 w-4" /> Copy
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={handleStopSharing}
                          className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-2xl border border-red-200 bg-red-50 px-4 py-2 text-sm font-bold text-red-700 hover:bg-red-100"
                        >
                          Stop Sharing
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Inline Trusted Contacts Management inside Module 4 */}
                  <div className="lg:col-span-6">
                    {renderTrustedContactsCard('Trusted Contacts')}
                  </div>
                </div>
              </div>
            )}

            {/* ---------- MODULE 5: SPEED DIAL ---------- */}
            {activeModule === 'dial' && (
              <div className="view-enter mx-auto max-w-2xl space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft sm:p-6">
                  <div className="flex items-start gap-3.5">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <PhoneCall className="h-6 w-6" />
                    </div>
                    <div>
                      <h1 className="text-xl font-extrabold text-[#24101B]">
                        Emergency Speed Dial
                      </h1>
                      <p className="mt-1 max-w-md text-xs leading-relaxed text-[#5C3D4E]">
                        Confirm before opening your dialer for your saved numbers.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowSettings(true)}
                    className="inline-flex min-h-[46px] shrink-0 items-center gap-1.5 rounded-2xl border border-pink-200 bg-[#FFF5F8] px-4 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                  >
                    <Settings className="h-4 w-4" />
                    <span>Configure Numbers</span>
                  </button>
                </div>

                <div className="space-y-4 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft sm:p-6">
                  <div className="grid gap-3.5 sm:grid-cols-2">
                    {[
                      {
                        label: 'Police',
                        subtitle: 'Law enforcement',
                        number: policeNumber,
                        Icon: Shield,
                      },
                      {
                        label: 'Ambulance',
                        subtitle: 'Medical emergency',
                        number: ambulanceNumber,
                        Icon: HeartPulse,
                      },
                    ].map((item) => {
                      const configured = Boolean(item.number?.trim());
                      const ServiceIcon = item.Icon;
                      return (
                        <div
                          key={item.label}
                          className="flex flex-col justify-between gap-4 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-5"
                        >
                          <div className="flex items-start gap-3">
                            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white text-[#E11D74] shadow-sm">
                              <ServiceIcon className="h-5 w-5" />
                            </div>
                            <div className="min-w-0">
                              <p className="text-base font-extrabold text-[#24101B]">
                                {item.label}
                              </p>
                              <p className="text-xs text-[#5C3D4E]">
                                {item.subtitle}
                              </p>
                            </div>
                          </div>

                          <div>
                            <p className="font-mono text-lg font-extrabold tabular-nums text-[#24101B]">
                              {configured ? item.number : 'Not set'}
                            </p>
                            <p className="mt-0.5 text-[11px] text-[#5C3D4E]">
                              {configured
                                ? 'Confirms before dialing'
                                : 'Add number in Settings'}
                            </p>
                          </div>

                          <button
                            type="button"
                            onClick={() =>
                              handleRequestSpeedDial(item.label, item.number)
                            }
                            className={`flex min-h-[46px] w-full items-center justify-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition ${
                              configured
                                ? 'btn-rose-glow bg-[#E11D74] text-white hover:bg-[#9D174D]'
                                : 'border border-pink-200 bg-white text-[#9D174D] hover:bg-pink-50'
                            }`}
                          >
                            <Phone className="h-4 w-4" />
                            <span>
                              {configured
                                ? `Call ${item.label}`
                                : `Set ${item.label} Number`}
                            </span>
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  {dialOutcome && (
                    <div className="space-y-3 rounded-2xl border border-pink-200 bg-pink-50/75 p-4 text-xs text-[#24101B]">
                      <p className="font-bold text-[#9D174D]">
                        Dialer requested for {dialOutcome.label}
                      </p>
                      <p className="leading-relaxed text-[#3E1F30]">
                        SafeHer attempted to open your device dialer.{' '}
                        <strong>We cannot verify whether a call connected.</strong>{' '}
                        If the dialer did not open, dial this number manually:
                      </p>
                      <p className="rounded-xl bg-white p-3.5 text-center font-mono text-xl font-extrabold tabular-nums text-[#24101B] shadow-sm">
                        {dialOutcome.number}
                      </p>
                      <div className="flex gap-2">
                        <a
                          href={dialOutcome.telHref}
                          className="btn-rose-glow flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-[#E11D74] px-3 py-2 font-bold text-white"
                        >
                          <PhoneCall className="h-4 w-4" /> Open Dialer
                        </a>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              await navigator.clipboard.writeText(
                                dialOutcome.number
                              );
                              setDialCopied(true);
                              window.setTimeout(() => setDialCopied(false), 2000);
                            } catch {
                              // Ignore
                            }
                          }}
                          className="flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border border-pink-200 bg-white px-4 py-2 font-bold text-[#24101B] hover:bg-pink-50"
                        >
                          <Copy className="h-4 w-4" />
                          {dialCopied ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </section>
        ) : activeSection === 'about' ? (
          /* ==================== 3. ABOUT ==================== */
          <section className="view-enter mx-auto max-w-4xl space-y-5">
            <div className="rounded-3xl bg-gradient-to-br from-[#FFE0EC] via-[#FFF6FA] to-white p-6 shadow-soft ring-1 ring-pink-200/80 sm:p-8">
              <p className="text-xs font-bold text-[#9D174D]">
                Built With Transparency
              </p>
              <h1 className="mt-1.5 text-2xl font-extrabold tracking-tight text-[#24101B] sm:text-3xl">
                About SafeHer
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-[#3E1F30] sm:text-base">
                SafeHer is a mobile-first web toolkit designed to put practical personal safety shortcuts in one calm, high-contrast, honest interface without misleading automation claims.
              </p>
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <div className="rounded-3xl border border-pink-100 bg-white p-6 text-xs leading-relaxed text-[#3E1F30] shadow-soft">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <h2 className="text-base font-extrabold text-[#9D174D]">
                    What SafeHer actually does
                  </h2>
                </div>
                <ul className="mt-3.5 list-disc space-y-2 pl-4">
                  <li>
                    Prepares SOS &amp; location-share messages for your native SMS or Share apps after explicit confirmation.
                  </li>
                  <li>
                    Hosts community-submitted Crowd Map pins (OpenStreetMap + Leaflet) and user-created Safety Alerts via Supabase.
                  </li>
                  <li>
                    Protects your private contacts, emergency numbers, and My Safety Journey logs with Supabase Row Level Security.
                  </li>
                </ul>
              </div>

              <div className="rounded-3xl border border-pink-200 bg-white p-6 text-xs leading-relaxed text-[#3E1F30] shadow-soft">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#24101B]">
                    <Info className="h-5 w-5" />
                  </div>
                  <h2 className="text-base font-extrabold text-[#24101B]">
                    Honest limitations
                  </h2>
                </div>
                <ul className="mt-3.5 list-disc space-y-2 pl-4">
                  <li>
                    Web browsers cannot send SMS silently, confirm phone calls, or keep GPS tracking alive after closing the tab.
                  </li>
                  <li>
                    Community crowd reports are user-submitted and may become outdated quickly.
                  </li>
                  <li>
                    SafeHer is a supportive utility and does not guarantee personal safety.
                  </li>
                </ul>
              </div>
            </div>
          </section>
        ) : activeSection === 'contact' ? (
          /* ==================== 4. CONTACT ==================== */
          <section className="view-enter mx-auto max-w-4xl space-y-5">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#FFDCEB] via-[#FFF6FA] to-white p-6 shadow-soft ring-1 ring-pink-200/80 sm:p-8">
              <div
                aria-hidden="true"
                className="hero-aurora-glow pointer-events-none absolute -right-14 -top-14 h-64 w-64 rounded-full blur-2xl"
              />
              <div
                aria-hidden="true"
                className="hero-bokeh-1 pointer-events-none absolute bottom-4 right-24 h-12 w-12 rounded-full bg-pink-300/30 blur-md"
              />
              <div
                aria-hidden="true"
                className="hero-heart-float pointer-events-none absolute right-7 top-6 hidden text-pink-200/80 sm:block"
              >
                <Mail className="h-20 w-20 stroke-[1.3]" />
              </div>

              <div className="relative">
                <p className="inline-flex items-center gap-1.5 text-xs font-bold text-[#9D174D]">
                  <Sparkles className="h-3.5 w-3.5 text-[#E11D74]" />
                  <span>Connect With Team SafeHer</span>
                </p>
                <h1 className="mt-1.5 text-2xl font-extrabold tracking-tight text-[#24101B] sm:text-3xl">
                  Contact &amp; Feedback
                </h1>
                <p className="mt-1.5 max-w-xl text-xs leading-relaxed text-[#3E1F30] sm:text-sm">
                  Share product ideas, bug reports, or collaboration notes in a clean, distraction-free draft preview.
                </p>
              </div>
            </div>

            <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
              {/* Left Column: Topic Picker & Helpful Shortcuts */}
              <div className="space-y-4 lg:col-span-5">
                <div className="rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-[#FFE0EC] to-[#FFF5F8] text-[#E11D74]">
                      <MessageSquare className="h-5 w-5" />
                    </div>
                    <div>
                      <h2 className="text-sm font-extrabold text-[#24101B]">
                        Select a Topic
                      </h2>
                      <p className="text-[11px] text-[#5C3D4E]">
                        Tags your message preview cleanly
                      </p>
                    </div>
                  </div>

                  <div className="mt-3.5 grid grid-cols-2 gap-2">
                    {[
                      { label: 'Feedback', hint: 'Experience & UI' },
                      { label: 'Bug Report', hint: 'Issue details' },
                      { label: 'Safety Idea', hint: 'New feature' },
                      { label: 'Partnership', hint: 'Team inquiry' },
                    ].map((topic) => {
                      const active = publicContactTopic === topic.label;
                      return (
                        <button
                          key={topic.label}
                          type="button"
                          onClick={() => setPublicContactTopic(topic.label)}
                          className={`card-interactive flex min-h-[58px] flex-col items-start justify-center rounded-2xl border px-3.5 py-2.5 text-left transition ${
                            active
                              ? 'btn-rose-glow border-[#E11D74] bg-[#E11D74] text-white'
                              : 'border-pink-100 bg-[#FFF8FA] text-[#24101B] hover:border-pink-300 hover:bg-pink-50/70'
                          }`}
                        >
                          <span className="text-xs font-extrabold">
                            {topic.label}
                          </span>
                          <span
                            className={`text-[11px] ${
                              active ? 'text-pink-100' : 'text-[#5C3D4E]'
                            }`}
                          >
                            {topic.hint}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-blush-mesh space-y-3 rounded-3xl border border-pink-100 p-5 shadow-soft">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-[#E11D74] shadow-sm">
                      <Heart className="h-5 w-5 fill-current" />
                    </div>
                    <div>
                      <h2 className="text-sm font-extrabold text-[#24101B]">
                        Need Immediate Support?
                      </h2>
                      <p className="text-[11px] text-[#5C3D4E]">
                        Use live safety tools instead of this form
                      </p>
                    </div>
                  </div>

                  <p className="text-xs leading-relaxed text-[#3E1F30]">
                    This page is for product feedback only and does not reach emergency responders. For urgent moments, launch SOS or Speed Dial right away.
                  </p>

                  <div className="grid grid-cols-2 gap-2 pt-0.5">
                    <button
                      type="button"
                      onClick={() => openModule('sos')}
                      className="card-interactive flex min-h-[44px] items-center justify-center gap-1.5 rounded-2xl border border-pink-200 bg-white px-3 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-50"
                    >
                      <AlertTriangle className="h-3.5 w-3.5 text-[#E11D74]" />
                      <span>Open SOS</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => openModule('dial')}
                      className="card-interactive flex min-h-[44px] items-center justify-center gap-1.5 rounded-2xl border border-pink-200 bg-white px-3 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-50"
                    >
                      <PhoneCall className="h-3.5 w-3.5 text-[#E11D74]" />
                      <span>Speed Dial</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Fancy Contact Form & Styled Preview */}
              <div className="rounded-3xl border border-pink-100 bg-white/95 p-5 shadow-soft ring-1 ring-pink-100/70 sm:p-6 lg:col-span-7">
                <div className="rounded-2xl border border-amber-300 bg-amber-50/90 p-3.5 text-xs leading-relaxed text-amber-950">
                  <p className="font-bold">Local Preview Form</p>
                  <p className="mt-0.5">
                    Validates your fields locally and creates a styled message preview below without sending an email.
                  </p>
                </div>

                <form
                  onSubmit={handlePublicContactSubmit}
                  className="mt-4 space-y-4"
                >
                  <div className="grid gap-3.5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="mb-1.5 block text-xs font-semibold text-[#24101B]"
                      >
                        Your Name
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        placeholder="Enter your name"
                        value={publicContactForm.name}
                        onChange={(e) =>
                          setPublicContactForm((p) => ({
                            ...p,
                            name: e.target.value,
                          }))
                        }
                        className="contact-input-fancy min-h-[46px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="contact-email"
                        className="mb-1.5 block text-xs font-semibold text-[#24101B]"
                      >
                        Email Address
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        placeholder="you@example.com"
                        value={publicContactForm.email}
                        onChange={(e) =>
                          setPublicContactForm((p) => ({
                            ...p,
                            email: e.target.value,
                          }))
                        }
                        className="contact-input-fancy min-h-[46px] w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <label
                        htmlFor="contact-message"
                        className="text-xs font-semibold text-[#24101B]"
                      >
                        Message ({publicContactTopic})
                      </label>
                      <span
                        className={`font-mono text-[11px] tabular-nums ${
                          publicContactForm.message.trim().length >= 10
                            ? 'font-bold text-emerald-700'
                            : 'text-[#5C3D4E]'
                        }`}
                      >
                        {publicContactForm.message.trim().length}/10+ chars
                      </span>
                    </div>
                    <textarea
                      id="contact-message"
                      rows={4}
                      placeholder="Write your message (min 10 characters)..."
                      value={publicContactForm.message}
                      onChange={(e) =>
                        setPublicContactForm((p) => ({
                          ...p,
                          message: e.target.value,
                        }))
                      }
                      className="contact-input-fancy w-full rounded-2xl border border-pink-200 px-3.5 py-2.5 text-sm outline-none"
                    />
                  </div>

                  {publicContactStatus && (
                    <FeedbackBanner
                      feedback={publicContactStatus}
                      onDismiss={() => setPublicContactStatus(null)}
                    />
                  )}

                  {publicContactPreview && (
                    <div className="modal-enter contact-preview-card space-y-2.5 rounded-2xl border border-pink-200 p-4 text-xs text-[#24101B]">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-pink-100 pb-2.5">
                        <div className="flex items-center gap-2">
                          <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-white text-[#E11D74] shadow-sm">
                            <Mail className="h-3.5 w-3.5" />
                          </span>
                          <div>
                            <p className="font-extrabold text-[#9D174D]">
                              Message Preview (Not Sent)
                            </p>
                            <p className="text-[11px] text-[#5C3D4E]">
                              Topic: {publicContactPreview.topic}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await navigator.clipboard.writeText(
                                  `Topic: ${publicContactPreview.topic}\nFrom: ${publicContactPreview.name} (${publicContactPreview.email})\n\n${publicContactPreview.message}`
                                );
                                setPublicContactCopied(true);
                                window.setTimeout(
                                  () => setPublicContactCopied(false),
                                  2000
                                );
                              } catch {
                                // Ignore clipboard failure
                              }
                            }}
                            className="inline-flex min-h-[36px] items-center gap-1 rounded-xl border border-pink-200 bg-white px-3 font-bold text-[#9D174D] shadow-sm hover:bg-pink-50"
                          >
                            <Copy className="h-3.5 w-3.5" />
                            <span>
                              {publicContactCopied ? 'Copied!' : 'Copy'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setPublicContactPreview(null);
                              setPublicContactStatus(null);
                              setPublicContactCopied(false);
                              setPublicContactForm({
                                name: '',
                                email: '',
                                message: '',
                              });
                            }}
                            className="min-h-[36px] rounded-xl bg-white px-3 font-semibold text-[#5C3D4E] shadow-sm hover:bg-pink-50 hover:text-[#24101B]"
                          >
                            Reset
                          </button>
                        </div>
                      </div>
                      <p className="text-[#3E1F30]">
                        <strong>From:</strong> {publicContactPreview.name} (
                        <span className="font-mono">
                          {publicContactPreview.email}
                        </span>
                        )
                      </p>
                      <p className="whitespace-pre-wrap rounded-xl bg-white/85 p-3 leading-relaxed text-[#24101B]">
                        {publicContactPreview.message}
                      </p>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-3 text-sm font-bold text-white hover:bg-[#9D174D]"
                  >
                    <Send className="h-4 w-4" />
                    <span>Preview Message</span>
                  </button>
                </form>
              </div>
            </div>
          </section>
        ) : (
          /* ==================== 5. MY SAFETY JOURNEY ==================== */
          <section className="view-enter space-y-5">
            <div className="flex flex-wrap items-start justify-between gap-4 rounded-3xl bg-gradient-to-br from-[#FFE0EC] via-[#FFF6FA] to-white p-6 shadow-soft ring-1 ring-pink-200/80 sm:p-7">
              <div className="flex items-start gap-3.5">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-[#E11D74] shadow-sm">
                  <HeartHandshake className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs font-bold tracking-wide text-[#9D174D]">
                    Private &amp; Under Your Control
                  </p>
                  <h1 className="mt-0.5 text-2xl font-extrabold tracking-tight text-[#24101B] sm:text-3xl">
                    My Safety Journey
                  </h1>
                  <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-[#3E1F30]">
                    A calm, private timeline built just for you—review your saved safety circle, adjust your privacy choices, and revisit practical safety reminders at your own pace.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => navigateSection('home')}
                className="min-h-[44px] shrink-0 rounded-2xl border border-pink-200 bg-white px-4 py-2 text-xs font-bold text-[#9D174D] transition hover:bg-pink-50"
              >
                Back to Home
              </button>
            </div>

            {!supabaseConfigured || !user ? (
              <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
                <div className="space-y-4 rounded-3xl border border-pink-100 bg-white p-6 shadow-soft lg:col-span-7">
                  <div className="flex items-center gap-3">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                      <Lock className="h-5 w-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-extrabold text-[#24101B]">
                        Private to Signed-In Accounts
                      </h2>
                      <p className="text-xs text-[#5C3D4E]">
                        Your safety profile and activity timeline are never shown unless you are signed in.
                      </p>
                    </div>
                  </div>
                  <p className="text-xs leading-relaxed text-[#3E1F30]">
                    To keep your personal safety actions private and visible only to you, sign in with your SafeHer account. You decide whether any activity is saved, and precise location coordinates stay off unless you explicitly opt in.
                  </p>
                  <div className="flex flex-wrap gap-2.5 pt-1">
                    {!supabaseConfigured ? (
                      <button
                        type="button"
                        onClick={() => setShowSetupModal(true)}
                        className="btn-rose-glow flex min-h-[46px] items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D]"
                      >
                        <Database className="h-4 w-4" />
                        <span>Connect Supabase First</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setShowSettings(true)}
                        className="btn-rose-glow flex min-h-[46px] items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-5 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D]"
                      >
                        <LogIn className="h-4 w-4" />
                        <span>Sign In to View My Journey</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => openModule('sos')}
                      className="min-h-[46px] rounded-2xl border border-pink-200 bg-white px-5 py-2.5 text-sm font-bold text-[#24101B] hover:bg-pink-50"
                    >
                      Open Safety Modules
                    </button>
                  </div>
                </div>

                {/* Supportive Safety Tips always available */}
                <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-6 shadow-soft lg:col-span-5">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                      <ShieldCheck className="h-5 w-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-extrabold text-[#24101B]">
                        Safety Tips
                      </h2>
                      <p className="text-xs text-[#5C3D4E]">
                        Practical, supportive reminders for your peace of mind.
                      </p>
                    </div>
                  </div>
                  <ul className="space-y-2.5">
                    {SUPPORTIVE_SAFETY_TIPS.map((tip, idx) => (
                      <li
                        key={tip.title}
                        className="rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4"
                      >
                        <p className="text-xs font-bold text-[#9D174D]">
                          0{idx + 1}. {tip.title}
                        </p>
                        <p className="mt-1 text-xs leading-relaxed text-[#3E1F30]">
                          {tip.body}
                        </p>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="grid gap-5 lg:grid-cols-12 lg:items-start">
                <div className="space-y-5 lg:col-span-7">
                  {/* Consent & Privacy Controls Card */}
                  <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft sm:p-6">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                          <Lock className="h-5 w-5" />
                        </div>
                        <div>
                          <h2 className="text-base font-extrabold text-[#24101B]">
                            Your Consent &amp; Privacy Choices
                          </h2>
                          <p className="text-xs text-[#5C3D4E]">
                            Private to your signed-in account only
                          </p>
                        </div>
                      </div>
                    </div>

                    {journeySchemaWarning && (
                      <div className="rounded-2xl border border-amber-300 bg-amber-50 p-3.5 text-xs text-amber-950">
                        Your Supabase database needs the latest{' '}
                        <code className="font-mono">supabase/schema.sql</code>{' '}
                        script (for <code className="font-mono">safety_journey_logs</code> and consent columns) before cloud history can be saved. Open{' '}
                        <button
                          type="button"
                          onClick={() => setShowSetupModal(true)}
                          className="font-bold underline"
                        >
                          Supabase Setup
                        </button>{' '}
                        to copy the updated SQL.
                      </div>
                    )}

                    {!saveActivityConsent ? (
                      <div className="space-y-3 rounded-2xl border border-pink-200 bg-[#FFF5F8] p-4 text-xs leading-relaxed text-[#3E1F30]">
                        <p className="font-bold text-[#9D174D]">
                          Would you like to save your safety activity here?
                        </p>
                        <p>
                          With your permission, SafeHer can keep a private timeline of SOS actions started, location-share sessions, safety alerts created, and crowd reports submitted. Only your signed-in account can see this log, and you can delete items or turn it off at any time.
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              void handleUpdateJourneyConsents({
                                activity: true,
                              })
                            }
                            className="btn-rose-glow min-h-[44px] rounded-2xl bg-[#E11D74] px-5 py-2 text-xs font-bold text-white hover:bg-[#9D174D]"
                          >
                            Yes, Save My Activity
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void handleUpdateJourneyConsents({
                                activity: false,
                                locationHistory: false,
                              })
                            }
                            className="min-h-[44px] rounded-2xl border border-pink-200 bg-white px-5 py-2 text-xs font-bold text-[#24101B] hover:bg-pink-50"
                          >
                            Keep Off
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        <label className="flex min-h-[44px] cursor-pointer items-start justify-between gap-3 rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4 text-xs">
                          <div>
                            <p className="font-bold text-[#24101B]">
                              Save private activity timeline
                            </p>
                            <p className="mt-0.5 leading-relaxed text-[#5C3D4E]">
                              Records SOS starts, location shares, alerts, and crowd check-ins for your eyes only.
                            </p>
                          </div>
                          <input
                            type="checkbox"
                            checked={saveActivityConsent}
                            onChange={(e) =>
                              void handleUpdateJourneyConsents({
                                activity: e.target.checked,
                              })
                            }
                            className="mt-0.5 h-5 w-5 shrink-0 accent-[#E11D74]"
                          />
                        </label>

                        <label className="flex min-h-[44px] cursor-pointer items-start justify-between gap-3 rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4 text-xs">
                          <div>
                            <p className="font-bold text-[#24101B]">
                              Include precise location coordinates in history
                            </p>
                            <p className="mt-0.5 leading-relaxed text-[#5C3D4E]">
                              Off by default. When off, SafeHer never stores or displays exact GPS coordinates in your timeline.
                            </p>
                          </div>
                          <input
                            type="checkbox"
                            checked={saveLocationHistoryConsent}
                            onChange={(e) =>
                              void handleUpdateJourneyConsents({
                                locationHistory: e.target.checked,
                              })
                            }
                            className="mt-0.5 h-5 w-5 shrink-0 accent-[#E11D74]"
                          />
                        </label>
                      </div>
                    )}

                    {journeyFeedback && (
                      <FeedbackBanner
                        feedback={journeyFeedback}
                        onDismiss={() => setJourneyFeedback(null)}
                      />
                    )}
                  </div>

                  {/* Clean Vertical Activity Timeline Card */}
                  <div className="space-y-4 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft sm:p-6">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                          <History className="h-5 w-5" />
                        </div>
                        <div>
                          <h2 className="text-base font-extrabold text-[#24101B]">
                            Activity Timeline ({journeyLogs.length})
                          </h2>
                          <p className="text-[11px] text-[#5C3D4E]">
                            Your private record of safety actions
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={fetchUserPrivateData}
                          disabled={journeyLoading}
                          aria-label="Refresh activity history"
                          className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#FFF5F8] text-[#9D174D] hover:bg-pink-100"
                        >
                          <RefreshCw
                            className={`h-4 w-4 ${journeyLoading ? 'animate-spin' : ''}`}
                          />
                        </button>
                        {journeyLogs.length > 0 && !confirmClearJourney && (
                          <button
                            type="button"
                            onClick={() => setConfirmClearJourney(true)}
                            className="min-h-[44px] rounded-2xl border border-red-200 bg-red-50 px-4 py-2 text-xs font-bold text-red-700 hover:bg-red-100"
                          >
                            Clear History
                          </button>
                        )}
                      </div>
                    </div>

                    {confirmClearJourney && (
                      <div className="space-y-2.5 rounded-2xl border border-red-200 bg-red-50 p-4 text-xs">
                        <p className="font-bold text-red-900">
                          Clear your full activity history?
                        </p>
                        <p className="text-red-800">
                          This permanently deletes all items in your private Safety Journey timeline.
                        </p>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={handleClearAllJourneyHistory}
                            disabled={journeyLoading}
                            className="min-h-[44px] flex-1 rounded-xl bg-red-600 px-3 py-2 font-bold text-white hover:bg-red-700 disabled:opacity-50"
                          >
                            Yes, Clear All
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmClearJourney(false)}
                            className="min-h-[44px] rounded-xl bg-white px-4 py-2 font-bold text-[#24101B]"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    {journeyLoading ? (
                      <div className="flex items-center justify-center gap-2 rounded-2xl bg-[#FFF5F8] p-6 text-xs text-[#5C3D4E]">
                        <Loader2 className="h-4 w-4 animate-spin text-[#E11D74]" />
                        Loading your private timeline...
                      </div>
                    ) : journeyLogs.length === 0 ? (
                      <div className="rounded-2xl bg-[#FFF5F8] p-6 text-center text-xs leading-relaxed text-[#5C3D4E]">
                        {saveActivityConsent
                          ? 'No activity recorded yet. When you start SOS prep, share your location, post an alert, or submit a crowd check-in, each step will appear on your timeline here.'
                          : 'Activity recording is currently off. Turn it on above anytime if you would like a private timeline of your safety actions.'}
                      </div>
                    ) : (
                      <ol className="relative space-y-4 pl-6 before:absolute before:bottom-3 before:left-[15px] before:top-3 before:w-px before:bg-pink-200">
                        {journeyLogs.map((item) => {
                          const ActivityIcon =
                            item.activity_type === 'sos'
                              ? AlertTriangle
                              : item.activity_type === 'location_share'
                                ? Share2
                                : item.activity_type === 'safety_alert'
                                  ? Bell
                                  : MapPin;
                          return (
                            <li key={item.id} className="relative pl-4">
                              <span
                                aria-hidden="true"
                                className="absolute -left-[21px] top-3.5 flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-[#FFE4EE] text-[#E11D74] shadow-sm"
                              >
                                <ActivityIcon className="h-3.5 w-3.5" />
                              </span>

                              <div className="rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="min-w-0">
                                    <p className="text-sm font-extrabold text-[#24101B]">
                                      {item.title}
                                    </p>
                                    <p className="mt-0.5 text-xs font-semibold text-[#9D174D]">
                                      Status: {item.status}
                                    </p>
                                  </div>
                                  <button
                                    type="button"
                                    aria-label={`Delete ${item.title}`}
                                    onClick={() =>
                                      handleDeleteJourneyItem(item.id)
                                    }
                                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-pink-100 bg-white text-red-600 shadow-sm hover:bg-red-50"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </div>

                                {item.details && (
                                  <p className="mt-1.5 text-xs leading-relaxed text-[#3E1F30]">
                                    {item.details}
                                  </p>
                                )}

                                <div className="mt-2.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-[#5C3D4E]">
                                  <span className="font-medium tabular-nums">
                                    {formatActivityDateTime(item.created_at)}
                                  </span>
                                  <span aria-hidden="true">·</span>
                                  {saveLocationHistoryConsent &&
                                  item.lat != null &&
                                  item.lng != null ? (
                                    <span className="font-mono tabular-nums">
                                      Coords: {Number(item.lat).toFixed(4)},{' '}
                                      {Number(item.lng).toFixed(4)}
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1">
                                      <EyeOff className="h-3 w-3" />
                                      Precise location omitted
                                    </span>
                                  )}
                                </div>
                              </div>
                            </li>
                          );
                        })}
                      </ol>
                    )}
                  </div>
                </div>

                {/* Right Column: Safety Profile & Supportive Safety Tips */}
                <div className="space-y-5 lg:col-span-5">
                  <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft sm:p-6">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                          <UserCheck className="h-5 w-5" />
                        </div>
                        <h2 className="text-base font-extrabold text-[#24101B]">
                          My Safety Profile
                        </h2>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowSettings(true)}
                        className="min-h-[40px] rounded-xl bg-pink-50 px-3.5 py-1.5 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                      >
                        Edit in Settings
                      </button>
                    </div>

                    <div className="rounded-2xl bg-[#FFF8FA] p-3.5 text-xs">
                      <p className="font-semibold text-[#5C3D4E]">Account</p>
                      <p className="mt-0.5 font-mono font-bold text-[#24101B]">
                        {user.email}
                      </p>
                    </div>

                    <div className="space-y-2 rounded-2xl border border-pink-100 bg-[#FFF8FA] p-3.5 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#24101B]">
                          Trusted Contacts
                        </span>
                        <span className="tabular-nums font-semibold text-[#9D174D]">
                          {contacts.length} saved
                        </span>
                      </div>
                      {contacts.length === 0 ? (
                        <p className="text-[#5C3D4E]">
                          No trusted contacts saved yet. Add someone you trust whenever you feel ready.
                        </p>
                      ) : (
                        <ul className="space-y-1.5 text-[#3E1F30]">
                          {contacts.map((c) => (
                            <li
                              key={c.id}
                              className="flex items-center justify-between gap-2"
                            >
                              <span className="truncate font-medium">
                                {c.name}
                              </span>
                              <span className="font-mono text-[11px] tabular-nums text-[#5C3D4E]">
                                {c.phone}
                              </span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    <div className="space-y-2 rounded-2xl border border-pink-100 bg-[#FFF8FA] p-3.5 text-xs">
                      <p className="font-bold text-[#24101B]">
                        Safety Preferences
                      </p>
                      <div className="flex items-center justify-between text-[#3E1F30]">
                        <span>Police Speed Dial</span>
                        <span className="font-mono tabular-nums font-semibold">
                          {policeNumber || 'Not set'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[#3E1F30]">
                        <span>Ambulance Speed Dial</span>
                        <span className="font-mono tabular-nums font-semibold">
                          {ambulanceNumber || 'Not set'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[#3E1F30]">
                        <span>Activity History</span>
                        <span className="font-semibold text-[#9D174D]">
                          {saveActivityConsent ? 'Saving with consent' : 'Off'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[#3E1F30]">
                        <span>Location History</span>
                        <span className="font-semibold text-[#9D174D]">
                          {saveLocationHistoryConsent
                            ? 'Precise coords opted in'
                            : 'Omitted'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Supportive Safety Tips */}
                  <div className="space-y-3.5 rounded-3xl border border-pink-100 bg-white p-5 shadow-soft sm:p-6">
                    <div className="flex items-center gap-2.5">
                      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#FFF5F8] text-[#E11D74]">
                        <ShieldCheck className="h-5 w-5" />
                      </div>
                      <div>
                        <h2 className="text-base font-extrabold text-[#24101B]">
                          Safety Tips
                        </h2>
                        <p className="text-xs text-[#5C3D4E]">
                          Practical reminders—you know your surroundings best.
                        </p>
                      </div>
                    </div>
                    <ul className="space-y-2.5">
                      {SUPPORTIVE_SAFETY_TIPS.map((tip, idx) => (
                        <li
                          key={tip.title}
                          className="rounded-2xl border border-pink-100 bg-[#FFF8FA] p-4"
                        >
                          <p className="text-xs font-bold text-[#9D174D]">
                            0{idx + 1}. {tip.title}
                          </p>
                          <p className="mt-1 text-xs leading-relaxed text-[#3E1F30]">
                            {tip.body}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </section>
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (5 Main Sections) */}
      <nav
        aria-label="Primary Mobile Navigation"
        className="fixed bottom-0 left-0 right-0 z-30 border-t border-pink-100 bg-white/95 px-2 py-1 shadow-[0_-10px_28px_-14px_rgba(157,23,77,0.18)] backdrop-blur-md md:hidden"
      >
        <div className="mx-auto grid max-w-md grid-cols-5 gap-1">
          {SECTIONS.map((sec) => {
            const Icon = sec.icon;
            const isActive = !showSettings && activeSection === sec.id;
            return (
              <button
                key={sec.id}
                type="button"
                onClick={() => navigateSection(sec.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative flex min-h-[46px] flex-col items-center justify-center gap-0.5 rounded-2xl px-1 py-1 text-[11px] font-bold transition ${
                  isActive
                    ? 'bg-pink-50 text-[#E11D74]'
                    : 'text-[#5C3D4E] hover:bg-[#FFF5F8]'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="truncate">{sec.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* ==================== INSTANT SOS STATUS & SMS MODAL ==================== */}
      {sosModalOpen && sosState && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="sos-modal-title"
          onClick={() => setSosModalOpen(false)}
          className="fixed inset-0 z-50 flex items-end justify-center bg-[#24101B]/45 p-3 backdrop-blur-xs sm:items-center"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="modal-enter max-h-[90vh] w-full max-w-md overflow-y-auto rounded-3xl border border-pink-100 bg-white p-6 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div
                  className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
                    sosState.status === 'failed'
                      ? 'bg-red-100 text-red-600'
                      : sosState.status === 'sent'
                        ? 'bg-emerald-100 text-emerald-700'
                        : 'bg-pink-100 text-[#E11D74]'
                  }`}
                >
                  {sosState.status === 'failed' ? (
                    <XCircle className="h-5 w-5" />
                  ) : sosState.status === 'sent' ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : (
                    <AlertTriangle className="h-5 w-5" />
                  )}
                </div>
                <div>
                  <h2
                    id="sos-modal-title"
                    className="text-lg font-extrabold text-[#24101B]"
                  >
                    {getSosStatusLabel(sosState.status)}
                  </h2>
                  <p className="text-xs text-[#5C3D4E]">
                    {sosState.recipientCount > 0
                      ? `Alerting ${sosState.recipientCount} trusted contact${
                          sosState.recipientCount === 1 ? '' : 's'
                        }`
                      : 'Choose recipients in your messaging app'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSosModalOpen(false)}
                aria-label="Close SOS modal"
                className="flex h-11 w-11 items-center justify-center rounded-full bg-pink-50 text-[#24101B] hover:bg-pink-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {/* Clear 3-Step SOS Lifecycle Status Bar */}
              <div className="grid grid-cols-3 gap-1.5 rounded-2xl border border-pink-100 bg-[#FFF5F8] p-2 text-center text-[11px] font-bold">
                <div className="rounded-xl bg-white px-2 py-1.5 text-[#9D174D] shadow-xs">
                  SOS Activated
                </div>
                <div
                  className={`rounded-xl px-2 py-1.5 ${
                    sosState.status === 'sending'
                      ? 'bg-[#E11D74] text-white shadow-xs'
                      : sosState.status === 'sent' || sosState.status === 'failed'
                        ? 'bg-white text-[#9D174D]'
                        : 'text-[#5C3D4E]/70'
                  }`}
                >
                  Sending Alert
                </div>
                <div
                  className={`rounded-xl px-2 py-1.5 ${
                    sosState.status === 'failed'
                      ? 'bg-red-600 text-white shadow-xs'
                      : sosState.status === 'sent'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-[#5C3D4E]/70'
                  }`}
                >
                  {sosState.status === 'failed' ? 'SMS Failed' : 'SMS Sent'}
                </div>
              </div>

              {sosDuplicateNotice && (
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-950">
                  {sosDuplicateNotice}
                </div>
              )}

              {(sosState.isOffline || !isOnline) && (
                <div className="flex items-start gap-2 rounded-2xl border border-pink-200 bg-pink-50 p-3 text-xs text-[#3E1F30]">
                  <WifiOff className="mt-0.5 h-4 w-4 shrink-0 text-[#9D174D]" />
                  <p>
                    <strong>Offline mode:</strong> No internet required — emergency SMS uses your device&apos;s cellular messaging directly.
                  </p>
                </div>
              )}

              {sosState.status === 'failed' ? (
                <div className="rounded-2xl border border-red-200 bg-red-50 p-3.5 text-xs text-red-950">
                  <p className="font-bold">SMS Failed</p>
                  <p className="mt-1 leading-relaxed">
                    {sosState.errorMessage ||
                      'Could not launch the device SMS app automatically. Tap Retry SMS below or copy the message.'}
                  </p>
                </div>
              ) : (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-3.5 text-xs text-emerald-950">
                  <p className="font-bold">
                    {sosState.status === 'sending'
                      ? 'Sending Alert — Opening Device SMS...'
                      : 'SMS Sent to Messaging App'}
                  </p>
                  <p className="mt-1 leading-relaxed">
                    SafeHer launched your device SMS composer immediately. Confirm <strong>Send</strong> inside your SMS app if prompted by your phone.
                  </p>
                </div>
              )}

              {/* Non-Blocking Background Location Status */}
              <div className="rounded-2xl border border-pink-100 bg-white p-3.5 text-xs text-[#3E1F30]">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 font-bold text-[#9D174D]">
                    <MapPin className="h-4 w-4" />
                    Location Status
                  </span>
                  {sosState.locatingInBackground && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#E11D74]">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      Updating GPS...
                    </span>
                  )}
                </div>
                <p className="mt-1 leading-relaxed text-[#5C3D4E]">
                  {sosState.locationSource === 'fresh'
                    ? `Fresh GPS coordinates attached (±${sosState.coords?.accuracy ?? 0}m).`
                    : sosState.locationSource === 'cached'
                      ? 'Last known location attached immediately while searching for a fresh GPS fix in the background.'
                      : sosState.locatingInBackground
                        ? 'Emergency SMS launched without waiting for GPS. Searching for coordinates in the background...'
                        : sosState.locationError ||
                          'Emergency message prepared without GPS coordinates.'}
                </p>
                {sosState.updatedAfterSend && sosState.mapLink && (
                  <button
                    type="button"
                    onClick={handleSendUpdatedLocationSms}
                    className="mt-2.5 flex min-h-[40px] w-full items-center justify-center gap-1.5 rounded-xl bg-pink-50 px-3 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                  >
                    <Navigation className="h-3.5 w-3.5" />
                    Send Updated Location SMS
                  </button>
                )}
              </div>

              <div className="rounded-2xl bg-[#FFF5F8] p-3.5 text-xs text-[#24101B]">
                <p className="font-bold text-[#9D174D]">Emergency SMS Text:</p>
                <p className="mt-1 break-words">{sosState.message}</p>
              </div>

              {sosState.status === 'failed' ? (
                <button
                  type="button"
                  onClick={handleRetrySosSms}
                  className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-3 text-sm font-bold text-white hover:bg-[#9D174D]"
                >
                  <RefreshCw className="h-4 w-4" />
                  Retry SMS
                </button>
              ) : (
                <a
                  href={sosState.smsHref}
                  className="btn-rose-glow flex min-h-[48px] w-full items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-3 text-sm font-bold text-white hover:bg-[#9D174D]"
                >
                  <ExternalLink className="h-4 w-4" />
                  Open Messaging App
                </a>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleCopySosMessage}
                  className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-2xl border border-pink-200 bg-white px-3 py-2 text-xs font-bold text-[#24101B] hover:bg-pink-50"
                >
                  <Copy className="h-4 w-4" />
                  {sosCopied ? 'Copied!' : 'Copy Message'}
                </button>
                <button
                  type="button"
                  onClick={handleResetSos}
                  className="min-h-[44px] rounded-2xl border border-pink-200 bg-white px-4 py-2 text-xs font-bold text-[#5C3D4E] hover:bg-pink-50"
                >
                  Reset
                </button>
                <button
                  type="button"
                  onClick={() => setSosModalOpen(false)}
                  className="min-h-[44px] rounded-2xl bg-pink-50 px-4 py-2 text-xs font-bold text-[#9D174D] hover:bg-pink-100"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== SPEED DIAL CONFIRMATION MODAL ==================== */}
      {dialConfirmTarget && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="dial-modal-title"
          onClick={() => setDialConfirmTarget(null)}
          className="fixed inset-0 z-50 flex items-end justify-center bg-[#24101B]/45 p-3 backdrop-blur-xs sm:items-center"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="modal-enter w-full max-w-md rounded-3xl border border-pink-100 bg-white p-6 shadow-2xl"
          >
            <div className="flex items-start justify-between gap-2">
              <h2
                id="dial-modal-title"
                className="text-lg font-extrabold text-[#24101B]"
              >
                Confirm Emergency Call
              </h2>
              <button
                type="button"
                onClick={() => setDialConfirmTarget(null)}
                aria-label="Close call confirmation modal"
                className="flex h-11 w-11 items-center justify-center rounded-full bg-pink-50 text-[#24101B] hover:bg-pink-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-2 text-sm text-[#3E1F30]">
              Open your phone dialer to call{' '}
              <strong>{dialConfirmTarget.label}</strong> at:
            </p>
            <p className="mt-3 rounded-2xl bg-[#FFF5F8] p-3.5 text-center font-mono text-xl font-extrabold tabular-nums text-[#9D174D]">
              {dialConfirmTarget.number}
            </p>
            <p className="mt-2.5 text-xs text-[#5C3D4E]">
              SafeHer only opens your device dialer and cannot place or verify calls automatically.
            </p>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => setDialConfirmTarget(null)}
                className="min-h-[46px] flex-1 rounded-2xl border border-pink-200 bg-white px-4 py-2 text-sm font-bold text-[#24101B] hover:bg-pink-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSpeedDial}
                className="btn-rose-glow flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2 text-sm font-bold text-white hover:bg-[#9D174D]"
              >
                <PhoneCall className="h-4 w-4" /> Open Dialer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== SUPABASE SETUP MODAL ==================== */}
      <SupabaseSetupModal
        isOpen={showSetupModal}
        onClose={() => setShowSetupModal(false)}
        onConnected={() => setSupabaseRevision((r) => r + 1)}
      />
    </div>
  );
}
