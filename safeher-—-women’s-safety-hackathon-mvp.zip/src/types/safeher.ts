export type SectionId = 'home' | 'modules' | 'about' | 'contact' | 'journey';

export type ModuleId = 'sos' | 'crowd' | 'alerts' | 'share' | 'dial';

export type CrowdLevel = 'Low' | 'Medium' | 'High';

export type JourneyActivityType =
  | 'sos'
  | 'location_share'
  | 'safety_alert'
  | 'crowd_report';

export interface SafetyJourneyLog {
  id: string;
  user_id: string;
  activity_type: JourneyActivityType;
  title: string;
  status: string;
  details: string;
  lat?: number | null;
  lng?: number | null;
  created_at: string;
}

export interface FeedbackState {
  type: 'idle' | 'loading' | 'success' | 'error' | 'info';
  message: string;
}

export interface TrustedContact {
  id: string;
  name: string;
  phone: string;
  created_at?: string;
  isLocal?: boolean;
}

export interface CrowdReport {
  id: string;
  user_id?: string;
  level: CrowdLevel;
  lat: number;
  lng: number;
  location_label: string;
  note: string;
  created_at: string;
  isSample?: boolean;
}

export interface SafetyAlert {
  id: string;
  user_id?: string;
  title: string;
  message: string;
  location_text: string;
  lat?: number | null;
  lng?: number | null;
  source_type: 'user' | 'sample';
  created_at: string;
  isSample?: boolean;
}

export interface Coordinates {
  lat: number;
  lng: number;
  accuracy?: number;
  timestamp?: number;
}

export type SosStatus = 'idle' | 'activated' | 'sending' | 'sent' | 'failed';

export interface SosAlertState {
  eventId: string;
  status: SosStatus;
  smsHref: string;
  message: string;
  hasLocation: boolean;
  locationSource: 'none' | 'cached' | 'fresh';
  coords: Coordinates | null;
  mapLink: string;
  recipientCount: number;
  recipientNames: string[];
  isOffline: boolean;
  locatingInBackground: boolean;
  locationError?: string;
  errorMessage?: string;
  retryCount: number;
  updatedAfterSend: boolean;
  triggeredAt: number;
}

export interface ActiveShareSession {
  contactName: string;
  contactPhone: string;
  mapLink: string;
  message: string;
  smsHref: string;
  startedAt: number;
  expiresAt: number;
}
