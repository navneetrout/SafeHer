import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Database,
  Loader2,
  Trash2,
  X,
  XCircle,
} from 'lucide-react';
import {
  cleanSupabaseAnonKey,
  clearRuntimeSupabaseConfig,
  extractSupabaseErrorMessage,
  getStoredSupabaseConfig,
  isServiceRoleOrSecretKey,
  isValidSupabaseConfig,
  normalizeSupabaseUrl,
  saveRuntimeSupabaseConfig,
} from '../lib/supabase';

const FULL_SCHEMA_SQL = `create extension if not exists pgcrypto;

create table if not exists public.trusted_contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 80),
  phone text not null check (char_length(trim(phone)) between 3 and 24),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.trusted_contacts enable row level security;
drop policy if exists "Users can view own contacts" on public.trusted_contacts;
create policy "Users can view own contacts" on public.trusted_contacts for select using (auth.uid() = user_id);
drop policy if exists "Users can insert own contacts" on public.trusted_contacts;
create policy "Users can insert own contacts" on public.trusted_contacts for insert with check (auth.uid() = user_id);
drop policy if exists "Users can update own contacts" on public.trusted_contacts;
create policy "Users can update own contacts" on public.trusted_contacts for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own contacts" on public.trusted_contacts;
create policy "Users can delete own contacts" on public.trusted_contacts for delete using (auth.uid() = user_id);

create table if not exists public.user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  police_number text not null default '',
  ambulance_number text not null default '',
  save_activity_consent boolean not null default false,
  save_location_history_consent boolean not null default false,
  save_profile_consent boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.user_settings add column if not exists save_activity_consent boolean not null default false;
alter table public.user_settings add column if not exists save_location_history_consent boolean not null default false;
alter table public.user_settings add column if not exists save_profile_consent boolean not null default false;
alter table public.user_settings enable row level security;
drop policy if exists "Users can view own settings" on public.user_settings;
create policy "Users can view own settings" on public.user_settings for select using (auth.uid() = user_id);
drop policy if exists "Users can insert own settings" on public.user_settings;
create policy "Users can insert own settings" on public.user_settings for insert with check (auth.uid() = user_id);
drop policy if exists "Users can update own settings" on public.user_settings;
create policy "Users can update own settings" on public.user_settings for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own settings" on public.user_settings;
create policy "Users can delete own settings" on public.user_settings for delete using (auth.uid() = user_id);

create table if not exists public.crowd_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  level text not null check (level in ('Low', 'Medium', 'High')),
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  location_label text not null default '' check (char_length(location_label) <= 120),
  note text not null default '' check (char_length(note) <= 280),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.crowd_reports enable row level security;
drop policy if exists "Anyone can read community crowd reports" on public.crowd_reports;
create policy "Anyone can read community crowd reports" on public.crowd_reports for select using (true);
drop policy if exists "Authenticated users can create own crowd reports" on public.crowd_reports;
create policy "Authenticated users can create own crowd reports" on public.crowd_reports for insert with check (auth.uid() = user_id);
drop policy if exists "Users can update own crowd reports" on public.crowd_reports;
create policy "Users can update own crowd reports" on public.crowd_reports for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users can delete own crowd reports" on public.crowd_reports;
create policy "Users can delete own crowd reports" on public.crowd_reports for delete using (auth.uid() = user_id);

create table if not exists public.safety_alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 100),
  message text not null check (char_length(trim(message)) between 1 and 500),
  location_text text not null default '' check (char_length(location_text) <= 140),
  lat double precision,
  lng double precision,
  source_type text not null default 'user' check (source_type = 'user'),
  created_at timestamptz not null default now()
);
alter table public.safety_alerts enable row level security;
drop policy if exists "Anyone can read user safety alerts" on public.safety_alerts;
create policy "Anyone can read user safety alerts" on public.safety_alerts for select using (true);
drop policy if exists "Authenticated users can create own safety alerts" on public.safety_alerts;
create policy "Authenticated users can create own safety alerts" on public.safety_alerts for insert with check (auth.uid() = user_id and source_type = 'user');
drop policy if exists "Users can delete own safety alerts" on public.safety_alerts;
create policy "Users can delete own safety alerts" on public.safety_alerts for delete using (auth.uid() = user_id);

create table if not exists public.alert_reads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  alert_id uuid not null references public.safety_alerts(id) on delete cascade,
  read_at timestamptz not null default now(),
  unique (user_id, alert_id)
);
alter table public.alert_reads enable row level security;
drop policy if exists "Users can view own alert reads" on public.alert_reads;
create policy "Users can view own alert reads" on public.alert_reads for select using (auth.uid() = user_id);
drop policy if exists "Users can insert own alert reads" on public.alert_reads;
create policy "Users can insert own alert reads" on public.alert_reads for insert with check (auth.uid() = user_id);
drop policy if exists "Users can delete own alert reads" on public.alert_reads;
create policy "Users can delete own alert reads" on public.alert_reads for delete using (auth.uid() = user_id);

create table if not exists public.safety_journey_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null check (activity_type in ('sos', 'location_share', 'safety_alert', 'crowd_report')),
  title text not null check (char_length(trim(title)) between 1 and 120),
  status text not null check (char_length(trim(status)) between 1 and 120),
  details text not null default '' check (char_length(details) <= 280),
  lat double precision,
  lng double precision,
  created_at timestamptz not null default now()
);
alter table public.safety_journey_logs enable row level security;
drop policy if exists "Users can view own journey logs" on public.safety_journey_logs;
create policy "Users can view own journey logs" on public.safety_journey_logs for select using (auth.uid() = user_id);
drop policy if exists "Users can insert own journey logs" on public.safety_journey_logs;
create policy "Users can insert own journey logs" on public.safety_journey_logs for insert with check (auth.uid() = user_id);
drop policy if exists "Users can delete own journey logs" on public.safety_journey_logs;
create policy "Users can delete own journey logs" on public.safety_journey_logs for delete using (auth.uid() = user_id);`;

interface SupabaseSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnected: () => void;
}

export default function SupabaseSetupModal({
  isOpen,
  onClose,
  onConnected,
}: SupabaseSetupModalProps) {
  const existing = getStoredSupabaseConfig();
  const [url, setUrl] = useState(existing.url || '');
  const [anonKey, setAnonKey] = useState(existing.anonKey || '');
  const [status, setStatus] = useState<{
    type: 'idle' | 'loading' | 'success' | 'error';
    message: string;
  }>({ type: 'idle', message: '' });
  const [copiedSql, setCopiedSql] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const latest = getStoredSupabaseConfig();
    setUrl(latest.url || '');
    setAnonKey(latest.anonKey || '');
    setStatus({ type: 'idle', message: '' });

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  async function handleSaveAndTest(e: React.FormEvent) {
    e.preventDefault();
    const rootUrl = normalizeSupabaseUrl(url);
    const cleanKey = cleanSupabaseAnonKey(anonKey);

    if (isServiceRoleOrSecretKey(cleanKey)) {
      setStatus({
        type: 'error',
        message:
          'Security error: Do not enter a Supabase service_role or secret key here. Only use your public anon key.',
      });
      return;
    }

    if (!isValidSupabaseConfig(rootUrl, cleanKey)) {
      setStatus({
        type: 'error',
        message:
          'Enter a valid Supabase Project URL (e.g. https://xyzcompany.supabase.co) and public anon key.',
      });
      return;
    }

    // Reflect the cleaned project root URL back into the field
    setUrl(rootUrl);
    setAnonKey(cleanKey);
    setStatus({ type: 'loading', message: 'Testing connection to Supabase...' });

    try {
      const [restRes, authRes] = await Promise.all([
        fetch(`${rootUrl}/rest/v1/crowd_reports?select=id&limit=1`, {
          headers: {
            apikey: cleanKey,
            Authorization: `Bearer ${cleanKey}`,
          },
        }),
        fetch(`${rootUrl}/auth/v1/settings`, {
          headers: {
            apikey: cleanKey,
            Authorization: `Bearer ${cleanKey}`,
          },
        }),
      ]);

      if (
        restRes.status === 401 ||
        restRes.status === 403 ||
        authRes.status === 401 ||
        authRes.status === 403
      ) {
        throw new Error(
          'Authentication rejected. Check that your public anon key matches this project.'
        );
      }

      if (!authRes.ok) {
        let authErrBody: unknown = null;
        try {
          authErrBody = await authRes.json();
        } catch {
          // Ignore non-JSON error payload
        }
        throw new Error(
          extractSupabaseErrorMessage(
            authErrBody,
            `Supabase Auth check failed with status ${authRes.status}. Verify you entered only the project root URL (https://<project-ref>.supabase.co).`
          )
        );
      }

      if (restRes.status === 404) {
        saveRuntimeSupabaseConfig(rootUrl, cleanKey);
        onConnected();
        setStatus({
          type: 'error',
          message:
            'Credentials saved, but the crowd_reports table was not found. Copy and run the SQL schema above in your Supabase SQL Editor.',
        });
        return;
      }

      if (!restRes.ok) {
        let restErrBody: unknown = null;
        try {
          restErrBody = await restRes.json();
        } catch {
          // Ignore non-JSON error payload
        }
        throw new Error(
          extractSupabaseErrorMessage(
            restErrBody,
            `Supabase responded with status ${restRes.status}.`
          )
        );
      }

      saveRuntimeSupabaseConfig(rootUrl, cleanKey);
      setStatus({
        type: 'success',
        message: 'Connected to Supabase and verified Auth & database tables!',
      });
      onConnected();
    } catch (err) {
      setStatus({
        type: 'error',
        message: extractSupabaseErrorMessage(
          err,
          'Could not reach Supabase. Check URL and network.'
        ),
      });
    }
  }

  function handleDisconnect() {
    clearRuntimeSupabaseConfig();
    setUrl('');
    setAnonKey('');
    setStatus({
      type: 'success',
      message:
        existing.source === 'env'
          ? 'Local override cleared. (.env variables are still active if configured.)'
          : 'Disconnected local Supabase credentials.',
    });
    onConnected();
  }

  async function handleCopySql() {
    try {
      await navigator.clipboard.writeText(FULL_SCHEMA_SQL);
      setCopiedSql(true);
      window.setTimeout(() => setCopiedSql(false), 2200);
    } catch {
      // Ignore clipboard failure
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="supabase-setup-title"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-end justify-center bg-[#24101B]/45 p-3 backdrop-blur-xs sm:items-center"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="modal-enter max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-pink-100 bg-white p-6 shadow-2xl"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-pink-100 text-[#E11D74]">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h2
                id="supabase-setup-title"
                className="text-lg font-extrabold text-[#24101B]"
              >
                Supabase Setup
              </h2>
              <p className="text-xs text-[#5C3D4E]">
                Required for Sign-In, Cloud Sync, Crowd Map &amp; Safety Alerts
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close setup modal"
            className="flex h-11 w-11 items-center justify-center rounded-full bg-pink-50 text-[#24101B] hover:bg-pink-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-4 rounded-2xl border border-pink-200 bg-[#FFF5F8] p-4 text-xs text-[#3E1F30]">
          <p className="font-bold text-[#9D174D]">Setup steps:</p>
          <ol className="mt-1.5 list-decimal space-y-1 pl-4 leading-relaxed">
            <li>
              Create a free project at <strong>supabase.com</strong>.
            </li>
            <li>
              Open <strong>SQL Editor</strong> and run the full SQL schema
              (from <code className="font-mono">supabase/schema.sql</code> or
              copy below).
            </li>
            <li>
              In <strong>Project Settings &rarr; API</strong>, copy your{' '}
              <strong>Project URL</strong> and <strong>anon public</strong> key
              (never use <code className="font-mono">service_role</code>).
            </li>
            <li>
              Paste them below or set{' '}
              <code className="font-mono">VITE_SUPABASE_URL</code> and{' '}
              <code className="font-mono">VITE_SUPABASE_ANON_KEY</code> in{' '}
              <code className="font-mono">.env</code>.
            </li>
          </ol>
          <button
            type="button"
            onClick={handleCopySql}
            className="mt-3 inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-white px-3.5 py-2 font-semibold text-[#9D174D] shadow-sm hover:bg-pink-50"
          >
            <Copy className="h-3.5 w-3.5" />
            {copiedSql ? 'Copied Full SQL Schema!' : 'Copy Full SQL Schema'}
          </button>
        </div>

        <form onSubmit={handleSaveAndTest} className="mt-4 space-y-3">
          <div>
            <label
              htmlFor="supabase-project-url"
              className="mb-1 block text-xs font-semibold text-[#24101B]"
            >
              Supabase Project URL
            </label>
            <input
              id="supabase-project-url"
              type="url"
              required
              placeholder="https://xyzcompany.supabase.co"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={existing.source === 'env'}
              className="min-h-[44px] w-full rounded-2xl border border-pink-200 bg-white px-3.5 py-2.5 text-sm text-[#24101B] outline-none focus:border-[#E11D74] disabled:bg-gray-100"
            />
          </div>

          <div>
            <label
              htmlFor="supabase-anon-key"
              className="mb-1 block text-xs font-semibold text-[#24101B]"
            >
              Supabase Public Anon Key
            </label>
            <textarea
              id="supabase-anon-key"
              rows={3}
              required
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              value={anonKey}
              onChange={(e) => setAnonKey(e.target.value)}
              disabled={existing.source === 'env'}
              className="w-full rounded-2xl border border-pink-200 bg-white px-3.5 py-2.5 font-mono text-xs text-[#24101B] outline-none focus:border-[#E11D74] disabled:bg-gray-100"
            />
          </div>

          {existing.source === 'env' && (
            <p className="text-xs text-[#5C3D4E]">
              Credentials are currently loaded from your{' '}
              <code className="font-mono">.env</code> file.
            </p>
          )}

          {status.type !== 'idle' && (
            <div
              className={`flex items-start gap-2 rounded-2xl p-3 text-xs ${
                status.type === 'error'
                  ? 'bg-red-50 text-red-900'
                  : status.type === 'success'
                    ? 'bg-emerald-50 text-emerald-900'
                    : 'bg-pink-50 text-[#24101B]'
              }`}
            >
              {status.type === 'loading' && (
                <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin text-[#E11D74]" />
              )}
              {status.type === 'success' && (
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
              )}
              {status.type === 'error' && (
                <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
              )}
              <span>{status.message}</span>
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-1">
            <button
              type="submit"
              disabled={status.type === 'loading' || existing.source === 'env'}
              className="btn-rose-glow flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-2xl bg-[#E11D74] px-4 py-2.5 text-sm font-bold text-white hover:bg-[#9D174D] disabled:opacity-50"
            >
              {status.type === 'loading' ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Testing...
                </>
              ) : (
                'Save & Test Connection'
              )}
            </button>

            {existing.source === 'local' && (
              <button
                type="button"
                onClick={handleDisconnect}
                className="flex min-h-[46px] items-center justify-center gap-1.5 rounded-2xl border border-pink-200 bg-white px-4 py-2.5 text-sm font-semibold text-[#9D174D] hover:bg-pink-50"
              >
                <Trash2 className="h-4 w-4" /> Clear
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
