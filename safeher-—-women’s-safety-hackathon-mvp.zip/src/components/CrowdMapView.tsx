import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { AlertCircle, List, MapPin } from 'lucide-react';
import { formatRelativeAge } from '../lib/utils';
import { Coordinates, CrowdLevel, CrowdReport } from '../types/safeher';

const LEVEL_COLORS: Record<CrowdLevel, string> = {
  Low: '#059669',
  Medium: '#D97706',
  High: '#E11D74',
};

function createPinIcon(
  color: string,
  labelText: string,
  isHighlighted = false
): L.DivIcon {
  const size = isHighlighted ? 32 : 28;
  return L.divIcon({
    className: 'safeher-pin-wrapper',
    html: `<div style="
      width:${size}px;
      height:${size}px;
      border-radius:9999px;
      background:${color};
      border:3px solid #ffffff;
      box-shadow:0 4px 12px rgba(36,16,27,0.28), 0 0 0 3px ${color}33;
      display:flex;
      align-items:center;
      justify-content:center;
      color:#ffffff;
      font-family:'Plus Jakarta Sans',sans-serif;
      font-size:${isHighlighted ? '10px' : '11px'};
      font-weight:800;
      letter-spacing:0.01em;
    ">${labelText}</div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

function buildPopupElement(report: CrowdReport, color: string): HTMLElement {
  const { label: ageLabel, isOld } = formatRelativeAge(report.created_at);

  const root = document.createElement('div');
  root.style.minWidth = '185px';
  root.style.fontFamily = "'DM Sans', sans-serif";

  const title = document.createElement('div');
  title.style.fontWeight = '700';
  title.style.fontSize = '13px';
  title.style.color = color;
  title.textContent = `${report.level} Crowd${report.isSample ? ' (Sample Preview)' : ''}`;
  root.appendChild(title);

  if (report.location_label) {
    const loc = document.createElement('div');
    loc.style.fontSize = '12px';
    loc.style.fontWeight = '600';
    loc.style.color = '#24101B';
    loc.style.marginTop = '3px';
    loc.textContent = report.location_label;
    root.appendChild(loc);
  }

  if (report.note) {
    const note = document.createElement('div');
    note.style.fontSize = '12px';
    note.style.lineHeight = '1.45';
    note.style.marginTop = '4px';
    note.style.color = '#3E1F30';
    note.textContent = report.note;
    root.appendChild(note);
  }

  const meta = document.createElement('div');
  meta.style.fontSize = '11px';
  meta.style.color = '#5C3D4E';
  meta.style.marginTop = '6px';
  meta.style.borderTop = '1px solid #FCE7F3';
  meta.style.paddingTop = '5px';
  meta.textContent = `User-submitted · ${ageLabel}${isOld ? ' · Older report' : ''}`;
  root.appendChild(meta);

  return root;
}

interface CrowdMapViewProps {
  reports: CrowdReport[];
  center: { lat: number; lng: number };
  userLocation: Coordinates | null;
  pickedLocation: { lat: number; lng: number } | null;
  onPickLocation?: (lat: number, lng: number) => void;
  isOnline: boolean;
}

export default function CrowdMapView({
  reports,
  center,
  userLocation,
  pickedLocation,
  onPickLocation,
  isOnline,
}: CrowdMapViewProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const reportsLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const pickedMarkerRef = useRef<L.Marker | null>(null);
  const tileErrorsRef = useRef(0);
  const onPickRef = useRef(onPickLocation);
  onPickRef.current = onPickLocation;

  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [center.lat, center.lng],
      zoom: 14,
      zoomControl: true,
    });

    const tileLayer = L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }
    );

    tileLayer.on('tileerror', () => {
      tileErrorsRef.current += 1;
      if (tileErrorsRef.current >= 3) {
        setTileError(true);
      }
    });

    tileLayer.on('tileload', () => {
      tileErrorsRef.current = 0;
      setTileError(false);
    });

    tileLayer.addTo(map);

    const reportsLayer = L.layerGroup().addTo(map);
    reportsLayerRef.current = reportsLayer;

    map.on('click', (event: L.LeafletMouseEvent) => {
      if (onPickRef.current) {
        onPickRef.current(event.latlng.lat, event.latlng.lng);
      }
    });

    mapRef.current = map;

    const timer = window.setTimeout(() => {
      map.invalidateSize();
    }, 180);

    return () => {
      window.clearTimeout(timer);
      map.remove();
      mapRef.current = null;
      reportsLayerRef.current = null;
      userMarkerRef.current = null;
      pickedMarkerRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapRef.current || !center) return;
    mapRef.current.setView([center.lat, center.lng], mapRef.current.getZoom(), {
      animate: true,
    });
  }, [center.lat, center.lng]);

  useEffect(() => {
    const layer = reportsLayerRef.current;
    if (!layer) return;
    layer.clearLayers();

    reports.forEach((report) => {
      const color = LEVEL_COLORS[report.level] || '#E11D74';
      const initial = (report.level || 'R').charAt(0).toUpperCase();

      const marker = L.marker([report.lat, report.lng], {
        icon: createPinIcon(color, initial),
      });

      marker.bindPopup(buildPopupElement(report, color));
      marker.addTo(layer);
    });
  }, [reports]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    if (userLocation) {
      const popup = document.createElement('strong');
      popup.textContent = 'Your current location';
      userMarkerRef.current = L.marker([userLocation.lat, userLocation.lng], {
        icon: createPinIcon('#2563EB', 'YOU', true),
      })
        .bindPopup(popup)
        .addTo(map);
    }
  }, [userLocation]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (pickedMarkerRef.current) {
      pickedMarkerRef.current.remove();
      pickedMarkerRef.current = null;
    }

    if (pickedLocation) {
      const popup = document.createElement('strong');
      popup.textContent = 'Selected report pin';
      pickedMarkerRef.current = L.marker(
        [pickedLocation.lat, pickedLocation.lng],
        {
          icon: createPinIcon('#9D174D', '+', true),
        }
      )
        .bindPopup(popup)
        .addTo(map);
    }
  }, [pickedLocation]);

  return (
    <div className="space-y-3">
      {(!isOnline || tileError) && (
        <div className="flex items-start gap-2.5 rounded-2xl border border-amber-300 bg-amber-50 p-3.5 text-xs text-amber-950">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
          <div>
            <p className="font-semibold">
              Map tiles could not load ({!isOnline ? 'Offline' : 'Tile service unavailable'}).
            </p>
            <p className="mt-0.5 leading-relaxed text-amber-900">
              Use the Nearby Reports list fallback below. You can still enter a location label or tap “Use My Location” if GPS is available.
            </p>
          </div>
        </div>
      )}

      <div className="overflow-hidden rounded-2xl border border-pink-200 bg-pink-50/70 shadow-sm">
        <div ref={containerRef} className="h-64 w-full sm:h-80" />
        <div className="flex flex-wrap items-center justify-between gap-2.5 border-t border-pink-100 bg-white px-4 py-3 text-xs text-[#5C3D4E]">
          <span className="flex items-center gap-1.5 font-semibold text-[#24101B]">
            <MapPin className="h-4 w-4 text-[#E11D74]" />
            Tap map to drop report pin
          </span>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-medium">
            <span className="inline-flex items-center gap-1.5 text-emerald-800">
              <span className="h-3 w-3 rounded-full border-2 border-white bg-emerald-600 shadow-sm" />
              Low · Quiet
            </span>
            <span className="inline-flex items-center gap-1.5 text-amber-800">
              <span className="h-3 w-3 rounded-full border-2 border-white bg-amber-600 shadow-sm" />
              Medium · Moderate
            </span>
            <span className="inline-flex items-center gap-1.5 text-[#9D174D]">
              <span className="h-3 w-3 rounded-full border-2 border-white bg-[#E11D74] shadow-sm" />
              High · Busy
            </span>
          </div>
        </div>
      </div>

      {tileError && (
        <div className="flex items-center gap-1.5 text-xs font-semibold text-[#9D174D]">
          <List className="h-3.5 w-3.5" />
          Showing nearby reports list fallback below.
        </div>
      )}
    </div>
  );
}
