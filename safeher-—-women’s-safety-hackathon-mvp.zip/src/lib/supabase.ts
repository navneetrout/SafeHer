import { createClient, SupabaseClient } from '@supabase/supabase-js';

const STORAGE_URL_KEY = 'safeher_supabase_url';
const STORAGE_ANON_KEY = 'safeher_supabase_anon_key';

export interface SupabaseConfigInfo {
  url: string;
  anonKey: string;
  source: 'env' | 'local' | 'none';
}

function stripWrappingQuotes(value: string): string {
  const trimmed = String(value || '').trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1).trim();
  }
  return trimmed;
}

/**
 * Normalizes a Supabase project URL to the clean project root only
 * (e.g. "https://<project-ref>.supabase.co"), stripping accidental
 * "/rest/v1", "/auth/v1", trailing slashes, query strings, or hashes
 * that would otherwise cause "Invalid path specified in request URL".
 */
export function normalizeSupabaseUrl(rawUrl: string): string {
  const cleaned = stripWrappingQuotes(rawUrl);
  if (!cleaned) return '';

  try {
    const parsed = new URL(cleaned);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return '';
    }

    const host = parsed.hostname.toLowerCase();
    // Standard hosted Supabase projects always live at the origin root
    if (
      host.endsWith('.supabase.co') ||
      host.endsWith('.supabase.in') ||
      host.endsWith('.supabase.red')
    ) {
      return parsed.origin;
    }

    // For custom/self-hosted URLs, strip known Supabase service subpaths
    const cleanPath = parsed.pathname
      .replace(
        /\/(rest|auth|storage|realtime|functions|graphql)\/v1(\/.*)?$/i,
        ''
      )
      .replace(/\/+$/, '');

    return `${parsed.origin}${cleanPath}`;
  } catch {
    return '';
  }
}

export function cleanSupabaseAnonKey(rawKey: string): string {
  return stripWrappingQuotes(rawKey);
}

/**
 * Rejects Supabase service_role JWTs and sb_secret_ keys so sensitive credentials
 * are never accepted or stored in browser client configuration.
 */
export function isServiceRoleOrSecretKey(rawKey: string): boolean {
  const cleaned = cleanSupabaseAnonKey(rawKey);
  if (!cleaned) return false;
  if (cleaned.startsWith('sb_secret_')) return true;

  const parts = cleaned.split('.');
  if (parts.length === 3) {
    try {
      const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4);
      const decoded = JSON.parse(atob(padded)) as { role?: string };
      if (decoded?.role === 'service_role') {
        return true;
      }
    } catch {
      // Ignore non-JSON payloads
    }
  }
  return false;
}

export function extractSupabaseErrorMessage(
  err: unknown,
  fallback = 'Request failed.'
): string {
  if (!err) return fallback;
  if (typeof err === 'string') return err || fallback;

  if (typeof err === 'object') {
    const record = err as Record<string, unknown>;
    const candidates = [
      record.error_description,
      record.message,
      record.msg,
      record.error,
      record.details,
    ];
    for (const candidate of candidates) {
      if (typeof candidate === 'string' && candidate.trim()) {
        return candidate.trim();
      }
    }
  }

  if (err instanceof Error && err.message.trim()) {
    return err.message.trim();
  }
  return fallback;
}

export function extractSupabaseErrorMeta(err: unknown): {
  code: string | null;
  status: number | null;
  label: string;
} {
  if (!err || typeof err !== 'object') {
    return { code: null, status: null, label: '' };
  }
  const record = err as Record<string, unknown>;
  const rawCode =
    typeof record.code === 'string' && record.code.trim()
      ? record.code.trim()
      : typeof record.error_code === 'string' && record.error_code.trim()
        ? record.error_code.trim()
        : null;
  const rawStatus =
    typeof record.status === 'number' && Number.isFinite(record.status)
      ? record.status
      : null;

  const parts: string[] = [];
  if (rawCode) parts.push(rawCode);
  if (rawStatus !== null) parts.push(`HTTP ${rawStatus}`);

  return {
    code: rawCode,
    status: rawStatus,
    label: parts.length > 0 ? `[${parts.join(' · ')}] ` : '',
  };
}

export function isEmailRateLimitError(err: unknown): boolean {
  if (!err) return false;
  const rawMessage = extractSupabaseErrorMessage(err, '').toLowerCase();
  const { code, status } = extractSupabaseErrorMeta(err);
  const lowerCode = (code || '').toLowerCase();

  if (status === 429) return true;
  if (
    lowerCode === 'over_email_send_rate_limit' ||
    lowerCode === 'over_request_rate_limit'
  ) {
    return true;
  }

  return (
    rawMessage.includes('rate limit') ||
    rawMessage.includes('too many requests') ||
    rawMessage.includes('over_email_send_rate_limit') ||
    rawMessage.includes('you can only request this after')
  );
}

export function extractRateLimitCooldownSeconds(err: unknown): number {
  const rawMessage = extractSupabaseErrorMessage(err, '');
  const match = rawMessage.match(/after\s+(\d+)\s+second/i);
  if (match && match[1]) {
    const parsed = Number.parseInt(match[1], 10);
    if (Number.isFinite(parsed) && parsed > 0) {
      return Math.min(Math.max(parsed, 30), 3600);
    }
  }
  // Supabase's built-in SMTP enforces an hourly project-wide email quota
  return 300;
}

export function formatSupabaseAuthError(
  err: unknown,
  context: 'signin' | 'signup' | 'resend' | 'signout'
): {
  message: string;
  code: string | null;
  status: number | null;
  isRateLimit: boolean;
  cooldownSeconds: number;
  isEmailNotConfirmed: boolean;
  isExistingUser: boolean;
} {
  const rawMessage = extractSupabaseErrorMessage(err, 'Authentication failed.');
  const lower = rawMessage.toLowerCase();
  const meta = extractSupabaseErrorMeta(err);

  if (isEmailRateLimitError(err)) {
    const cooldownSeconds = extractRateLimitCooldownSeconds(err);
    const codeTag = meta.label || '[over_email_send_rate_limit · HTTP 429] ';
    return {
      message: `${codeTag}${rawMessage}. Supabase limits how many verification emails can be sent per hour across the project. Check your inbox/spam for an earlier verification link, use Sign In if your email is already confirmed, or wait before registering a new email.`,
      code: meta.code || 'over_email_send_rate_limit',
      status: meta.status ?? 429,
      isRateLimit: true,
      cooldownSeconds,
      isEmailNotConfirmed: false,
      isExistingUser: false,
    };
  }

  const isExistingUser =
    meta.code === 'user_already_exists' ||
    lower.includes('already registered') ||
    lower.includes('already been registered') ||
    lower.includes('user already exists');

  if (isExistingUser) {
    return {
      message: `${meta.label}An account with this email already exists. Switch to Sign In and log in with your password.`,
      code: meta.code,
      status: meta.status,
      isRateLimit: false,
      cooldownSeconds: 0,
      isEmailNotConfirmed: false,
      isExistingUser: true,
    };
  }

  const isEmailNotConfirmed =
    meta.code === 'email_not_confirmed' ||
    lower.includes('email not confirmed') ||
    lower.includes('not confirmed');

  if (isEmailNotConfirmed) {
    return {
      message: `${meta.label}Your email address is not verified yet. Open the confirmation link sent to your inbox (and check spam) before signing in.`,
      code: meta.code,
      status: meta.status,
      isRateLimit: false,
      cooldownSeconds: 0,
      isEmailNotConfirmed: true,
      isExistingUser: false,
    };
  }

  if (
    context === 'signin' &&
    (meta.code === 'invalid_credentials' ||
      lower.includes('invalid login credentials'))
  ) {
    return {
      message: `${meta.label}Invalid email or password. Check your details or switch to Create Account if you are a new user.`,
      code: meta.code,
      status: meta.status,
      isRateLimit: false,
      cooldownSeconds: 0,
      isEmailNotConfirmed: false,
      isExistingUser: false,
    };
  }

  return {
    message: `${meta.label}${rawMessage}`,
    code: meta.code,
    status: meta.status,
    isRateLimit: false,
    cooldownSeconds: 0,
    isEmailNotConfirmed: false,
    isExistingUser: false,
  };
}

export function getStoredSupabaseConfig(): SupabaseConfigInfo {
  const rawEnvUrl = import.meta.env.VITE_SUPABASE_URL || '';
  const rawEnvAnon = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
  const envUrl = normalizeSupabaseUrl(rawEnvUrl);
  const envAnon = cleanSupabaseAnonKey(rawEnvAnon);

  if (envUrl && envAnon && !isServiceRoleOrSecretKey(envAnon)) {
    return { url: envUrl, anonKey: envAnon, source: 'env' };
  }

  try {
    const rawLocalUrl = localStorage.getItem(STORAGE_URL_KEY) || '';
    const rawLocalAnon = localStorage.getItem(STORAGE_ANON_KEY) || '';
    const localUrl = normalizeSupabaseUrl(rawLocalUrl);
    const localAnon = cleanSupabaseAnonKey(rawLocalAnon);
    if (localUrl && localAnon && !isServiceRoleOrSecretKey(localAnon)) {
      return { url: localUrl, anonKey: localAnon, source: 'local' };
    }
  } catch {
    // Ignore storage read errors in restricted contexts
  }

  return { url: '', anonKey: '', source: 'none' };
}

export function isValidSupabaseConfig(url: string, anonKey: string): boolean {
  const normalizedUrl = normalizeSupabaseUrl(url);
  const cleanKey = cleanSupabaseAnonKey(anonKey);
  if (!normalizedUrl || !cleanKey) return false;
  if (isServiceRoleOrSecretKey(cleanKey)) return false;
  return cleanKey.length >= 20;
}

export function saveRuntimeSupabaseConfig(url: string, anonKey: string): void {
  const normalizedUrl = normalizeSupabaseUrl(url);
  const cleanKey = cleanSupabaseAnonKey(anonKey);
  localStorage.setItem(STORAGE_URL_KEY, normalizedUrl);
  localStorage.setItem(STORAGE_ANON_KEY, cleanKey);
}

export function clearRuntimeSupabaseConfig(): void {
  localStorage.removeItem(STORAGE_URL_KEY);
  localStorage.removeItem(STORAGE_ANON_KEY);
}

let cachedClient: SupabaseClient | null = null;
let cachedSignature = '';

export function getSupabaseClient(): SupabaseClient | null {
  const { url, anonKey } = getStoredSupabaseConfig();
  const rootUrl = normalizeSupabaseUrl(url);
  const cleanKey = cleanSupabaseAnonKey(anonKey);

  if (!isValidSupabaseConfig(rootUrl, cleanKey)) {
    cachedClient = null;
    cachedSignature = '';
    return null;
  }

  const signature = `${rootUrl}::${cleanKey}`;
  if (cachedClient && cachedSignature === signature) {
    return cachedClient;
  }

  cachedClient = createClient(rootUrl, cleanKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  });
  cachedSignature = signature;
  return cachedClient;
}
