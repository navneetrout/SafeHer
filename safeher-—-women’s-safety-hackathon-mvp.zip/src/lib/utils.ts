import { Coordinates, CrowdReport, SafetyAlert } from '../types/safeher';

export const LOCAL_CONTACTS_KEY = 'safeher_local_contacts_v1';
export const LOCAL_SETTINGS_KEY = 'safeher_local_settings_v1';
export const LOCAL_READ_ALERTS_KEY = 'safeher_local_read_alerts_v1';
export const LAST_KNOWN_LOCATION_KEY = 'safeher_last_known_location_v1';

export function validatePhoneNumber(phone: string): {
  valid: boolean;
  error?: string;
  normalized?: string;
} {
  const cleaned = String(phone || '').trim();
  if (!cleaned) return { valid: false, error: 'Phone number is required.' };
  if (!/^[+\d][\d\s\-()]{2,20}$/.test(cleaned)) {
    return {
      valid: false,
      error: 'Use 3 to 20 digits (optional +, spaces, dashes, or parentheses).',
    };
  }
  const digits = cleaned.replace(/\D/g, '');
  if (digits.length < 3 || digits.length > 16) {
    return {
      valid: false,
      error: 'Phone number must contain between 3 and 16 digits.',
    };
  }
  return { valid: true, normalized: cleaned };
}

export function sanitizeDialNumber(phone: string): string {
  return String(phone || '').replace(/[^\d+]/g, '');
}

export function validateEmail(email: string): boolean {
  const trimmed = String(email || '').trim();
  if (!trimmed) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed);
}

export function saveLastKnownLocation(coords: Coordinates): void {
  if (
    typeof window === 'undefined' ||
    !Number.isFinite(coords.lat) ||
    !Number.isFinite(coords.lng)
  ) {
    return;
  }
  try {
    const payload: Coordinates = {
      lat: coords.lat,
      lng: coords.lng,
      accuracy:
        typeof coords.accuracy === 'number' && Number.isFinite(coords.accuracy)
          ? Math.round(coords.accuracy)
          : undefined,
      timestamp: coords.timestamp || Date.now(),
    };
    localStorage.setItem(LAST_KNOWN_LOCATION_KEY, JSON.stringify(payload));
  } catch {
    // Ignore storage quota / privacy mode errors
  }
}

export function getLastKnownLocation(
  maxAgeMs = 24 * 60 * 60 * 1000
): Coordinates | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(LAST_KNOWN_LOCATION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Coordinates>;
    if (
      typeof parsed.lat !== 'number' ||
      !Number.isFinite(parsed.lat) ||
      typeof parsed.lng !== 'number' ||
      !Number.isFinite(parsed.lng)
    ) {
      return null;
    }
    const ts =
      typeof parsed.timestamp === 'number' && Number.isFinite(parsed.timestamp)
        ? parsed.timestamp
        : 0;
    if (maxAgeMs > 0 && ts > 0 && Date.now() - ts > maxAgeMs) {
      return null;
    }
    return {
      lat: parsed.lat,
      lng: parsed.lng,
      accuracy:
        typeof parsed.accuracy === 'number' ? Math.round(parsed.accuracy) : undefined,
      timestamp: ts || Date.now(),
    };
  } catch {
    return null;
  }
}

function mapGeolocationError(err: GeolocationPositionError): Error {
  switch (err.code) {
    case err.PERMISSION_DENIED:
      return new Error(
        'Location permission was denied. Enable location access in your browser settings to attach coordinates.'
      );
    case err.POSITION_UNAVAILABLE:
      return new Error(
        'Current location is unavailable right now. Check that GPS / Location Services are turned on.'
      );
    case err.TIMEOUT:
      return new Error(
        'Location request timed out. Move near a window or try again.'
      );
    default:
      return new Error('Could not obtain your current location.');
  }
}

export function requestBrowserLocation(options?: {
  enableHighAccuracy?: boolean;
  timeout?: number;
  maximumAge?: number;
}): Promise<Coordinates> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      reject(
        new Error('Geolocation is not supported by this browser or device.')
      );
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords: Coordinates = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          accuracy: Math.round(position.coords.accuracy || 0),
          timestamp: position.timestamp || Date.now(),
        };
        saveLastKnownLocation(coords);
        resolve(coords);
      },
      (err) => {
        reject(mapGeolocationError(err));
      },
      {
        enableHighAccuracy: options?.enableHighAccuracy ?? true,
        timeout: options?.timeout ?? 8000,
        maximumAge: options?.maximumAge ?? 30000,
      }
    );
  });
}

/**
 * Fetches a fast coarse/cached fix immediately in parallel with a high-accuracy GPS fix
 * in the background without blocking UI or SOS SMS dispatch.
 */
export function requestBackgroundLocationRefresh(
  onLocation: (coords: Coordinates, isHighAccuracy: boolean) => void,
  onFinished?: (errorMessage?: string) => void
): () => void {
  if (typeof window === 'undefined' || !('geolocation' in navigator)) {
    onFinished?.('Geolocation is not supported by this browser or device.');
    return () => {};
  }

  let cancelled = false;
  let highAccuracyResolved = false;
  let pendingRequests = 2;
  let lastError = '';

  const finishIfDone = () => {
    pendingRequests -= 1;
    if (!cancelled && pendingRequests <= 0) {
      onFinished?.(lastError || undefined);
    }
  };

  // Fast coarse/cached fix (network / cell / Wi-Fi / recent OS cache)
  navigator.geolocation.getCurrentPosition(
    (position) => {
      if (cancelled || highAccuracyResolved) {
        finishIfDone();
        return;
      }
      const coords: Coordinates = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: Math.round(position.coords.accuracy || 0),
        timestamp: position.timestamp || Date.now(),
      };
      saveLastKnownLocation(coords);
      onLocation(coords, false);
      finishIfDone();
    },
    (err) => {
      if (!lastError) lastError = mapGeolocationError(err).message;
      finishIfDone();
    },
    {
      enableHighAccuracy: false,
      timeout: 2500,
      maximumAge: 300000,
    }
  );

  // Accurate GPS fix in parallel
  navigator.geolocation.getCurrentPosition(
    (position) => {
      highAccuracyResolved = true;
      if (cancelled) {
        finishIfDone();
        return;
      }
      const coords: Coordinates = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: Math.round(position.coords.accuracy || 0),
        timestamp: position.timestamp || Date.now(),
      };
      saveLastKnownLocation(coords);
      onLocation(coords, true);
      finishIfDone();
    },
    (err) => {
      lastError = mapGeolocationError(err).message;
      finishIfDone();
    },
    {
      enableHighAccuracy: true,
      timeout: 9000,
      maximumAge: 10000,
    }
  );

  return () => {
    cancelled = true;
  };
}

/**
 * Returns fresh GPS quickly if available, or immediately falls back to last-known
 * coordinates if GPS exceeds maxWaitMs while continuing to update in the background.
 */
export function fetchLocationWithFastFallback(
  onBackgroundUpdate?: (coords: Coordinates) => void,
  maxWaitMs = 1500
): Promise<{ coords: Coordinates; isCachedFallback: boolean }> {
  const cached = getLastKnownLocation();

  return new Promise((resolve, reject) => {
    let settled = false;
    let timerId: number | null = null;

    if (cached) {
      timerId = window.setTimeout(() => {
        if (!settled) {
          settled = true;
          resolve({ coords: cached, isCachedFallback: true });
        }
      }, maxWaitMs);
    }

    requestBrowserLocation({
      enableHighAccuracy: true,
      timeout: 8000,
      maximumAge: 30000,
    })
      .then((freshCoords) => {
        if (timerId !== null) window.clearTimeout(timerId);
        if (!settled) {
          settled = true;
          resolve({ coords: freshCoords, isCachedFallback: false });
        } else {
          onBackgroundUpdate?.(freshCoords);
        }
      })
      .catch((err) => {
        if (timerId !== null) window.clearTimeout(timerId);
        if (!settled) {
          settled = true;
          if (cached) {
            resolve({ coords: cached, isCachedFallback: true });
          } else {
            reject(err);
          }
        }
      });
  });
}

export function buildMapLink(lat: number, lng: number): string {
  return `https://maps.google.com/?q=${Number(lat).toFixed(6)},${Number(lng).toFixed(6)}`;
}

export function buildSmsHref(recipients: string[], messageBody: string): string {
  const cleanedRecipients = (recipients || [])
    .map((r) => sanitizeDialNumber(r))
    .filter(Boolean)
    .join(',');

  const isIOS =
    typeof navigator !== 'undefined' &&
    /iPad|iPhone|iPod/.test(navigator.userAgent);

  const separator = isIOS ? '&' : '?';
  const encodedBody = encodeURIComponent(messageBody);

  if (!cleanedRecipients) {
    return isIOS ? `sms:&body=${encodedBody}` : `sms:?body=${encodedBody}`;
  }
  return `sms:${cleanedRecipients}${separator}body=${encodedBody}`;
}

export function launchSmsUri(smsHref: string): {
  launched: boolean;
  error?: string;
} {
  if (!smsHref || !smsHref.startsWith('sms:')) {
    return {
      launched: false,
      error: 'Invalid emergency SMS link.',
    };
  }
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return {
      launched: false,
      error: 'Device SMS launcher is unavailable in this environment.',
    };
  }

  try {
    const anchor = document.createElement('a');
    anchor.href = smsHref;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    return { launched: true };
  } catch (err) {
    try {
      window.location.assign(smsHref);
      return { launched: true };
    } catch {
      return {
        launched: false,
        error:
          err instanceof Error
            ? err.message
            : 'Could not launch the device SMS app.',
      };
    }
  }
}

export function formatRelativeAge(isoDate?: string): {
  label: string;
  isOld: boolean;
} {
  if (!isoDate) return { label: 'Unknown time', isOld: false };
  const diffMs = Date.now() - new Date(isoDate).getTime();
  const minutes = Math.max(0, Math.floor(diffMs / 60000));
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  let label = 'Just now';
  if (minutes >= 1 && minutes < 60) label = `${minutes}m ago`;
  else if (hours >= 1 && hours < 24) label = `${hours}h ago`;
  else if (days >= 1) label = `${days}d ago`;

  return {
    label,
    isOld: diffMs > 2 * 60 * 60 * 1000,
  };
}

export function formatActivityDateTime(isoDate?: string): string {
  if (!isoDate) return 'Unknown date';
  try {
    return new Intl.DateTimeFormat(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(isoDate));
  } catch {
    return isoDate;
  }
}

export const SUPPORTIVE_SAFETY_TIPS = [
  {
    title: 'Keep trusted people in your corner',
    body: 'Save one or two people you feel comfortable reaching out to in Settings. Having them ready makes checking in quicker whenever you want company or reassurance.',
  },
  {
    title: 'Verify local emergency numbers when travelling',
    body: 'Emergency numbers vary by region. Taking a moment to enter your local Police and Ambulance numbers in Settings keeps Speed Dial accurate wherever you are.',
  },
  {
    title: 'Trust what feels right for you',
    body: 'If a route, plan, or setting ever feels uncomfortable, you never owe anyone an explanation for changing plans, stepping into a well-lit public space, or calling someone you trust.',
  },
  {
    title: 'Keep SafeHer one tap away',
    body: 'Bookmark SafeHer or add it to your phone’s home screen, and try to keep your battery topped up before late commutes so your phone is ready whenever you need it.',
  },
];

export const SAMPLE_ALERTS: SafetyAlert[] = [
  {
    id: 'sample-alert-1',
    title: 'Sample: Streetlight Outage Near Bus Stop',
    message:
      'Sample community notice for local preview only. This is NOT a live alert and is not stored in Supabase.',
    location_text: 'Sample Ave & 4th Cross',
    source_type: 'sample',
    created_at: new Date(Date.now() - 45 * 60000).toISOString(),
    isSample: true,
  },
];

export const SAMPLE_CROWD_REPORTS: CrowdReport[] = [
  {
    id: 'sample-crowd-1',
    level: 'Medium',
    lat: 28.6139,
    lng: 77.209,
    location_label: 'Sample Central Transit Plaza',
    note: 'Sample report for local preview only. Connect Supabase to submit and view shared community reports.',
    created_at: new Date(Date.now() - 150 * 60000).toISOString(),
    isSample: true,
  },
];
